# Contraction sensitivity receipt

Use Python 3.12+ stdlib after extraction:

```sh
python3 scripts/bandha_contraction_sweep_summary_20261117.py --root . --frozen results/csvs/bandha_contraction_sweep_20261117 --output verification
```

All nine combinations and every failure remain. The input uses previously examined T data.
