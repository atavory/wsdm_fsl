"""Summarize the nine-point contraction replay using frozen CSVs and stdlib."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics as st
import zipfile
from collections import defaultdict
from pathlib import Path


BETAS = (0.05, 0.10, 0.20)
FLOORS = (0.90, 0.95, 0.99)
# Same family-mean interval convention as bandha_family_clustered_intervals.py.
T_975 = {9: 2.262157, 8: 2.306004, 7: 2.364624, 6: 2.446912}


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def read_csv(path):
    with path.open() as handle:
        return list(csv.DictReader(handle))


def yes(value):
    return str(value).lower() == "true"


def number(value):
    return None if value in ("", None) else float(value)


def average(values):
    return st.mean(values) if values else None


def cell(row):
    return row["dataset"] + "__" + row["seed"]


def safe(row):
    return all(
        number(row[f"group_{g}_level"]) is not None
        and number(row[f"group_{g}_baseline"]) is not None
        and float(row[f"group_{g}_level"]) <= float(row[f"group_{g}_baseline"]) + 1e-10
        for g in (0, 1)
    )


def summarize(rows):
    value = [row for row in rows if row["unit"] == "value"]
    removal = [float(row["removal"]) for row in value if row["removal"] != ""]
    capture = [
        float(row["capture_retained"]) for row in value if row["capture_retained"] != ""
    ]
    joint = [
        yes(row["capture_target_met"]) and yes(row["value_cap_met"]) and safe(row)
        for row in value
    ]
    by_case = defaultdict(list)
    for row in rows:
        by_case[cell(row)].append(row)
    return {
        "cells": len(value),
        "value_removal_defined": len(removal),
        "capture_defined": len(capture),
        "mean_value_removal_percent": None if not removal else 100 * st.mean(removal),
        "mean_capture_percent": None if not capture else 100 * st.mean(capture),
        "capture_floor_met": sum(yes(row["capture_target_met"]) for row in value),
        "capture_floor_missed": sum(
            not yes(row["capture_target_met"]) for row in value
        ),
        "value_cap_met": sum(yes(row["value_cap_met"]) for row in value),
        "value_levels_nonincreasing": sum(safe(row) for row in value),
        "joint_value": sum(joint),
        "positive_joint_value": sum(
            ok and row["removal"] != "" and float(row["removal"]) > 1e-10
            for row, ok in zip(value, joint)
        ),
        "C_resource_infeasible": sum(
            yes(row["C_resource_infeasible"]) for row in value
        ),
        "C_capture_floor_infeasible": sum(
            yes(row["C_capture_goal_infeasible"]) for row in value
        ),
        "maximum_pointwise_error": max(
            float(row["pointwise_safety_error"]) for row in rows
        ),
        "maximum_factor_error": max(float(row["factor_error"]) for row in rows),
        "defined_units_by_case": {
            key: sum(row["removal"] != "" for row in selected)
            for key, selected in by_case.items()
        },
    }


def paired_contrast(common, thinning, column):
    a = {
        cell(row): row for row in common if row["unit"] == "value" and row[column] != ""
    }
    b = {
        cell(row): row
        for row in thinning
        if row["unit"] == "value" and row[column] != ""
    }
    if set(a) != set(b):
        raise ValueError("Common/thinning defined support does not match")
    families = defaultdict(list)
    for key in sorted(a):
        if a[key]["source"] != b[key]["source"]:
            raise ValueError("Source family changed between paired policies")
        families[a[key]["source"]].append(float(a[key][column]) - float(b[key][column]))
    means = {source: st.mean(values) for source, values in families.items()}
    result = {
        "paired_cells": len(a),
        "families": len(means),
        "family_difference_points": {key: 100 * value for key, value in means.items()},
        "mean_difference_points": None if not means else 100 * st.mean(means.values()),
    }
    n = len(means)
    if n - 1 in T_975:
        se = st.stdev(means.values()) / math.sqrt(n)
        mean, critical = st.mean(means.values()), T_975[n - 1]
        result.update(
            ci95_low_points=100 * (mean - critical * se),
            ci95_high_points=100 * (mean + critical * se),
            clustered_se_points=100 * se,
        )
    else:
        result.update(
            ci95_low_points=None, ci95_high_points=None, clustered_se_points=None
        )
    return result


def grouped(rows):
    expected = {
        (beta, rho, policy)
        for beta in BETAS
        for rho in FLOORS
        for policy in ("common", "thinning")
    }
    result = defaultdict(list)
    seen = set()
    for row in rows:
        key = (float(row["design_cap"]), float(row["capture_floor"]), row["policy"])
        unique = (*key, cell(row), row["unit"])
        if unique in seen:
            raise ValueError("Duplicated sweep row")
        seen.add(unique)
        result[key].append(row)
    if set(result) != expected or any(
        len(rows) != 720 or len({cell(row) for row in rows}) != 240
        for rows in result.values()
    ):
        raise ValueError("Expected nine combinations, two policies and 240 cases")
    return result


def panel_summary(rows):
    groups = grouped(rows)
    result = []
    for beta in BETAS:
        for rho in FLOORS:
            common, thinning = (
                groups[beta, rho, "common"],
                groups[beta, rho, "thinning"],
            )
            by_source = defaultdict(list)
            for row in common:
                by_source[row["source"]].append(row)
            source_summaries = [summarize(selected) for selected in by_source.values()]
            result.append(
                {
                    "beta": beta,
                    "rho": rho,
                    "common": summarize(common),
                    "thinning": summarize(thinning),
                    "paired_removal": paired_contrast(common, thinning, "removal"),
                    "paired_capture": paired_contrast(
                        common, thinning, "capture_retained"
                    ),
                    "common_source_equal": {
                        "sources": len(source_summaries),
                        "mean_value_removal_percent": average(
                            [
                                row["mean_value_removal_percent"]
                                for row in source_summaries
                                if row["mean_value_removal_percent"] is not None
                            ]
                        ),
                        "mean_capture_percent": average(
                            [
                                row["mean_capture_percent"]
                                for row in source_summaries
                                if row["mean_capture_percent"] is not None
                            ]
                        ),
                        "joint_value_rate_percent": 100
                        * st.mean(
                            row["joint_value"] / row["cells"]
                            for row in source_summaries
                        ),
                    },
                }
            )
    return result


def baseline_curve(rows):
    result = []
    for beta in BETAS:
        selected = [
            row
            for row in rows
            if row["policy"] == "common"
            and row["unit"] == "value"
            and float(row["capture_floor"]) == 0.95
            and float(row["design_cap"]) == beta
        ]
        values = [
            float(row["baseline_capture_fraction_loss"])
            for row in selected
            if row["baseline_capture_fraction_loss"] != ""
        ]
        blocked = [
            float(row["baseline_blocked_value_fraction"])
            for row in selected
            if row["baseline_blocked_value_fraction"] != ""
        ]
        result.append(
            {
                "beta": beta,
                "cells": len(selected),
                "baseline_capture_fraction_defined": len(values),
                "mean_baseline_capture_fraction_loss_percent": 100 * st.mean(values),
                "mean_baseline_blocked_value_fraction_percent": 100 * st.mean(blocked),
            }
        )
    return result


def capacity_summary(rows, capacities, part):
    lookup = {
        (float(row["beta"]), row["cell"]): row
        for row in capacities
        if row["part"] == part
    }
    result = []
    for beta in BETAS:
        for rho in FLOORS:
            selected = [
                row
                for row in rows
                if row["policy"] == "common"
                and row["unit"] == "value"
                and float(row["design_cap"]) == beta
                and float(row["capture_floor"]) == rho
            ]
            valid, above_share, violations, slacks = [], 0, 0, []
            for row in selected:
                moment = lookup[beta, cell(row)]
                b0, bq, headroom = (float(moment[key]) for key in ("B0", "Bq", "HB"))
                if bq <= 0 or not yes(row["capture_target_met"]):
                    continue
                removal = 1 - float(row["common_factor"])
                share_limit = min(1, (1 - rho) * b0 / bq)
                bound = min(1, ((1 - rho) * b0 + headroom) / bq)
                valid.append(removal)
                above_share += removal > share_limit + 1e-8
                violations += removal > bound + 1e-8
                slacks.append(bound - removal)
            result.append(
                {
                    "beta": beta,
                    "rho": rho,
                    "floor_met_with_positive_Bq": len(valid),
                    "removal_above_share_only_ceiling": above_share,
                    "capture_bound_violations": violations,
                    "mean_removal_in_valid_subset_percent": None
                    if not valid
                    else 100 * st.mean(valid),
                    "mean_bound_slack_percent": None
                    if not slacks
                    else 100 * st.mean(slacks),
                }
            )
    return result


def slope_summary(rows, capacities, part):
    groups = grouped(rows)
    lookup = {
        (float(row["beta"]), row["cell"]): row
        for row in capacities
        if row["part"] == part
    }
    result = []
    for beta in BETAS:
        by_rho = {
            rho: {
                cell(row): row
                for row in groups[beta, rho, "common"]
                if row["unit"] == "value"
            }
            for rho in FLOORS
        }
        slopes, limits = [], []
        for key in by_rho[0.95]:
            moment = lookup[beta, key]
            if float(moment["Bq"]) <= 0 or not all(
                yes(by_rho[rho][key]["capture_target_met"]) for rho in FLOORS
            ):
                continue
            slopes.append(
                (
                    float(by_rho[0.99][key]["common_factor"])
                    - float(by_rho[0.90][key]["common_factor"])
                )
                / 0.09
            )
            limits.append(float(moment["B0"]) / float(moment["Bq"]))
        result.append(
            {
                "beta": beta,
                "same_cases_meeting_all_three_floors": len(slopes),
                "mean_removal_slope_magnitude": average(slopes),
                "mean_one_over_sigma": average(limits),
                "cases_exceeding_heuristic_one_over_sigma_slope": sum(
                    slope > limit + 1e-8 for slope, limit in zip(slopes, limits)
                ),
            }
        )
    return result


def headroom_lines(result):
    lines = [
        "",
        "## Per-cell headroom check",
        "",
        "The requested-rho capture bound applies to cases that meet that floor and have positive Bq. We evaluate its quantities per cell; combining a mean removal with a median sigma does not evaluate the bound. All T cases, including floor failures, remain in the main grid.",
        "",
        "| Cap | Floor | T floor met, Bq positive | Removal above share-only ceiling | Capture-bound violations |",
        "| ---: | ---: | ---: | ---: | ---: |",
    ]
    for point in result["capacity_T"]:
        lines.append(
            f"| {100 * point['beta']:.0f}% | {point['rho']:.2f} | {point['floor_met_with_positive_Bq']} | {point['removal_above_share_only_ceiling']} | {point['capture_bound_violations']} |"
        )
    lines.extend(
        [
            "",
            "At rho .99 on C:",
            "",
            "| Cap | Floor met, Bq positive | Mean removal | Mean headroom-bound slack | Above share-only ceiling |",
            "| ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for point in result["capacity_C"]:
        if point["rho"] == 0.99:
            lines.append(
                f"| {100 * point['beta']:.0f}% | {point['floor_met_with_positive_Bq']} | {point['mean_removal_in_valid_subset_percent']:.2f}% | {point['mean_bound_slack_percent']:.2f} points | {point['removal_above_share_only_ceiling']} |"
            )
    return lines


def slope_lines(result):
    lines = [
        "",
        "## Pre-T slope prediction",
        "",
        "The extra pre-T prediction required the fitted removal slope to be no steeper than 1/sigma. We test it on the same cases meeting all three floors. The capture inequality sets an upper bound; value-constrained replacement can make the fitted optimum vary more steeply. The failures below concern that additional slope prediction.",
        "",
        "| Split | Cap | Same cases meeting all floors | Slope exceeds 1/sigma | Mean slope | Mean 1/sigma |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for part in ("C", "T"):
        for point in result["heuristic_slope_" + part]:
            lines.append(
                f"| {part} | {100 * point['beta']:.0f}% | {point['same_cases_meeting_all_three_floors']} | {point['cases_exceeding_heuristic_one_over_sigma_slope']} | {point['mean_removal_slope_magnitude']:.3f} | {point['mean_one_over_sigma']:.3f} |"
            )
    return lines


def markdown(result):
    lines = [
        "# Contraction budget and capture-floor sweep",
        "",
        "Generator: `scripts/bandha_contraction_sweep_summary_20261117.py`.",
        "",
        "We replayed frozen XGBoost predictions over all nine cap/floor combinations and all 240 original cases. V sets each cap's baseline and two criterion cuts; C fits each common factor and replacement mixture. All 2,160 common policies froze before T. We trained no model. This sensitivity uses previously examined data.",
        "",
        "## Full T grid",
        "",
        "Means use defined ratios and retain feasibility failures. Removal and capture use each cap's own baseline and fixed criteria. Joint attainment requires both business targets and nonincrease of both original value-group levels.",
        "",
        "| Cap | Floor | Common removal | Thinning removal | Common capture | Common joint | Thinning joint | Common floor misses | C floor infeasible |",
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for point in result["T"]:
        c, t = point["common"], point["thinning"]
        lines.append(
            f"| {100 * point['beta']:.0f}% | {point['rho']:.2f} | {c['mean_value_removal_percent']:.2f}% | {t['mean_value_removal_percent']:.2f}% | {c['mean_capture_percent']:.2f}% | {c['joint_value']}/240 | {t['joint_value']}/240 | {c['capture_floor_missed']} | {c['C_capture_floor_infeasible']} |"
        )
    if "capacity_T" in result:
        lines.extend(headroom_lines(result))
        lines.extend(slope_lines(result))
    lines.extend(
        [
            "",
            "## Source-family paired removal",
            "",
            "Intervals average within each source family first, then use the same Student-t convention as the primary. They are descriptive sensitivity intervals, without a multiple-comparison selection rule.",
            "",
            "| Cap | Floor | Common minus thinning | 95% interval | Defined paired cells | Families |",
            "| ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for point in result["T"]:
        r = point["paired_removal"]
        interval = (
            "undefined"
            if r["ci95_low_points"] is None
            else f"[{r['ci95_low_points']:.2f}, {r['ci95_high_points']:.2f}]"
        )
        lines.append(
            f"| {100 * point['beta']:.0f}% | {point['rho']:.2f} | {r['mean_difference_points']:.2f} points | {interval} | {r['paired_cells']} | {r['families']} |"
        )
    lines.extend(
        [
            "",
            "## Baseline capture curve",
            "",
            "| Cap | Mean baseline blocked-value fraction | Mean baseline capture as share of total T loss |",
            "| ---: | ---: | ---: |",
        ]
    )
    for point in result["baseline_curve_T"]:
        lines.append(
            f"| {100 * point['beta']:.0f}% | {point['mean_baseline_blocked_value_fraction_percent']:.2f}% | {point['mean_baseline_capture_fraction_loss_percent']:.2f}% |"
        )
    lines.extend(
        [
            "",
            "## Scope and checks",
            "",
            "Each cap changes the baseline and the criterion flags, so cross-cap removal does not measure one unchanged objection set. All source/model predictions and memberships remain frozen. T never adjusts a cap, cut, factor or mixture. The original 10%/.95 outcomes reproduce under the replay. Structural objection protection does not imply future capture or value feasibility; every failure remains in the grid.",
            "",
        ]
    )
    return "\n".join(lines)


def receipt(args, result):
    paths = {
        Path(__file__),
        *(path for path in args.frozen.iterdir() if path.is_file()),
        *(path for path in args.output.iterdir() if path.is_file()),
    }
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        args.receipt, "w", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        for path in sorted(paths):
            archive.write(path, str(path.relative_to(args.root)))
        archive.writestr(
            "README.md",
            "# Contraction sensitivity receipt\n\nUse Python 3.12+ stdlib after extraction:\n\n```sh\npython3 scripts/bandha_contraction_sweep_summary_20261117.py --root . --frozen results/csvs/bandha_contraction_sweep_20261117 --output verification\n```\n\nAll nine combinations and every failure remain. The input uses previously examined T data.\n",
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "frozen", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    provenance = json.loads((args.frozen / "bandha_T_PROVENANCE.json").read_text())
    if (
        digest(args.frozen / "bandha_T.csv") != provenance["T_sha256"]
        or digest(args.frozen / "bandha_C_FREEZE.json") != provenance["C_freeze_sha256"]
    ):
        raise ValueError("Sweep inputs differ from their frozen provenance")
    freeze = json.loads((args.frozen / "bandha_C_FREEZE.json").read_text())
    if digest(args.frozen / "bandha_C.csv") != freeze["C_csv_sha256"]:
        raise ValueError("Sweep C outcomes differ from their freeze")
    rows = {part: read_csv(args.frozen / f"bandha_{part}.csv") for part in ("C", "T")}
    result = {
        "generator_sha256": digest(Path(__file__)),
        "scope": "Exploratory sensitivity replay; no model training.",
        "provenance": provenance,
        "inputs": {
            str(path.relative_to(args.root)): digest(path)
            for path in sorted(args.frozen.iterdir())
            if path.is_file()
        },
        "C": panel_summary(rows["C"]),
        "T": panel_summary(rows["T"]),
        "baseline_curve_T": baseline_curve(rows["T"]),
    }
    if (args.frozen / "bandha_capacity.csv").exists():
        capacity_provenance = json.loads(
            (args.frozen / "bandha_capacity_provenance.json").read_text()
        )
        if (
            digest(args.frozen / "bandha_capacity.csv")
            != capacity_provenance["capacity_csv_sha256"]
        ):
            raise ValueError(
                "Capacity coefficients differ from their frozen provenance"
            )
        capacities = read_csv(args.frozen / "bandha_capacity.csv")
        result.update(
            capacity_C=capacity_summary(rows["C"], capacities, "C"),
            capacity_T=capacity_summary(rows["T"], capacities, "T"),
            heuristic_slope_C=slope_summary(rows["C"], capacities, "C"),
            heuristic_slope_T=slope_summary(rows["T"], capacities, "T"),
        )
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "bandha_summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    (args.output / "bandha_summary.md").write_text(markdown(result))
    print(markdown(result))
    if args.receipt:
        receipt(args, result)
        print("Numerical receipt:", args.receipt)


if __name__ == "__main__":
    main()
