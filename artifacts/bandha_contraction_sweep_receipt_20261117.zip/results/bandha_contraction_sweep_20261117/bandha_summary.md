# Contraction budget and capture-floor sweep

Generator: `scripts/bandha_contraction_sweep_summary_20261117.py`.

We replayed frozen XGBoost predictions over all nine cap/floor combinations and all 240 original cases. V sets each cap's baseline and two criterion cuts; C fits each common factor and replacement mixture. All 2,160 common policies froze before T. We trained no model. This sensitivity uses previously examined data.

## Full T grid

Means use defined ratios and retain feasibility failures. Removal and capture use each cap's own baseline and fixed criteria. Joint attainment requires both business targets and nonincrease of both original value-group levels.

| Cap | Floor | Common removal | Thinning removal | Common capture | Common joint | Thinning joint | Common floor misses | C floor infeasible |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 5% | 0.90 | 52.48% | 10.00% | 113.61% | 57/240 | 194/240 | 133 | 13 |
| 5% | 0.95 | 44.20% | 5.00% | 115.80% | 50/240 | 173/240 | 143 | 31 |
| 5% | 0.99 | 37.58% | 1.00% | 115.27% | 34/240 | 131/240 | 165 | 57 |
| 10% | 0.90 | 56.63% | 10.00% | 91.82% | 61/240 | 213/240 | 126 | 13 |
| 10% | 0.95 | 47.59% | 5.00% | 94.62% | 57/240 | 183/240 | 136 | 34 |
| 10% | 0.99 | 39.32% | 1.00% | 97.34% | 43/240 | 142/240 | 156 | 56 |
| 20% | 0.90 | 60.14% | 10.00% | 88.82% | 83/240 | 226/240 | 125 | 11 |
| 20% | 0.95 | 49.17% | 5.00% | 92.47% | 71/240 | 193/240 | 140 | 24 |
| 20% | 0.99 | 38.11% | 1.00% | 94.91% | 42/240 | 152/240 | 175 | 66 |

## Per-cell headroom check

The requested-rho capture bound applies to cases that meet that floor and have positive Bq. We evaluate its quantities per cell; combining a mean removal with a median sigma does not evaluate the bound. All T cases, including floor failures, remain in the main grid.

| Cap | Floor | T floor met, Bq positive | Removal above share-only ceiling | Capture-bound violations |
| ---: | ---: | ---: | ---: | ---: |
| 5% | 0.90 | 104 | 81 | 0 |
| 5% | 0.95 | 94 | 78 | 0 |
| 5% | 0.99 | 72 | 67 | 0 |
| 10% | 0.90 | 113 | 82 | 0 |
| 10% | 0.95 | 103 | 76 | 0 |
| 10% | 0.99 | 83 | 71 | 0 |
| 20% | 0.90 | 115 | 89 | 0 |
| 20% | 0.95 | 100 | 83 | 0 |
| 20% | 0.99 | 65 | 59 | 0 |

At rho .99 on C:

| Cap | Floor met, Bq positive | Mean removal | Mean headroom-bound slack | Above share-only ceiling |
| ---: | ---: | ---: | ---: | ---: |
| 5% | 173 | 40.68% | 11.74 points | 170 |
| 10% | 180 | 43.99% | 11.80 points | 177 |
| 20% | 174 | 44.67% | 12.88 points | 174 |

## Pre-T slope prediction

The extra pre-T prediction required the fitted removal slope to be no steeper than 1/sigma. We test it on the same cases meeting all three floors. The capture inequality sets an upper bound; value-constrained replacement can make the fitted optimum vary more steeply. The failures below concern that additional slope prediction.

| Split | Cap | Same cases meeting all floors | Slope exceeds 1/sigma | Mean slope | Mean 1/sigma |
| --- | ---: | ---: | ---: | ---: | ---: |
| C | 5% | 173 | 97 | 1.771 | 1.506 |
| C | 10% | 180 | 97 | 1.976 | 1.905 |
| C | 20% | 174 | 86 | 2.514 | 2.676 |
| T | 5% | 69 | 35 | 1.832 | 1.821 |
| T | 10% | 79 | 42 | 2.066 | 3.166 |
| T | 20% | 65 | 32 | 2.641 | 2.975 |

## Source-family paired removal

Intervals average within each source family first, then use the same Student-t convention as the primary. They are descriptive sensitivity intervals, without a multiple-comparison selection rule.

| Cap | Floor | Common minus thinning | 95% interval | Defined paired cells | Families |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 5% | 0.90 | 41.30 points | [27.67, 54.93] | 232 | 10 |
| 5% | 0.95 | 37.28 points | [24.59, 49.96] | 232 | 10 |
| 5% | 0.99 | 34.06 points | [21.43, 46.68] | 232 | 10 |
| 10% | 0.90 | 48.75 points | [28.86, 68.63] | 238 | 10 |
| 10% | 0.95 | 44.57 points | [25.74, 63.40] | 238 | 10 |
| 10% | 0.99 | 39.14 points | [21.55, 56.73] | 238 | 10 |
| 20% | 0.90 | 50.54 points | [30.15, 70.93] | 240 | 10 |
| 20% | 0.95 | 45.69 points | [24.80, 66.57] | 240 | 10 |
| 20% | 0.99 | 37.30 points | [21.23, 53.38] | 240 | 10 |

## Baseline capture curve

| Cap | Mean baseline blocked-value fraction | Mean baseline capture as share of total T loss |
| ---: | ---: | ---: |
| 5% | 4.91% | 16.13% |
| 10% | 9.77% | 24.37% |
| 20% | 20.03% | 38.09% |

## Scope and checks

Each cap changes the baseline and the criterion flags, so cross-cap removal does not measure one unchanged objection set. All source/model predictions and memberships remain frozen. T never adjusts a cap, cut, factor or mixture. The original 10%/.95 outcomes reproduce under the replay. Structural objection protection does not imply future capture or value feasibility; every failure remains in the grid.
