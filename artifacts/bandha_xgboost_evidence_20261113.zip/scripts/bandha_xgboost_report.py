"""Generate the boosted fairness report and paper table from frozen outcomes."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path


LABELS = {
    "thinning": "Uniform thinning",
    "common": "Common contraction",
    "selective": "Selective release",
    "reserve": "Selective + reserve",
}
LINEAR = {
    "thinning": "uniform_095",
    "common": "common_contraction",
    "selective": "selective_fixed_quota",
    "reserve": "selective_reserve",
}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def number(value):
    return float(value) if value not in ("", None) else None


def truth(value):
    return str(value).lower() == "true"


def mean(values):
    return statistics.mean(values) if values else None


def quantile(values, p):
    values = sorted(values)
    if not values:
        return None
    index = (len(values) - 1) * p
    left = int(index)
    right = min(left + 1, len(values) - 1)
    return values[left] + (values[right] - values[left]) * (index - left)


def safe(row):
    return all(
        number(row[f"group_{g}_level"]) is not None
        and number(row[f"group_{g}_level"])
        <= number(row[f"group_{g}_baseline"]) + 1e-10
        for g in (0, 1)
    )


def joint(row):
    return (
        safe(row) and truth(row["capture_target_met"]) and truth(row["value_cap_met"])
    )


def summarize(rows):
    by_unit = defaultdict(list)
    for row in rows:
        by_unit[row["unit"]].append(row)
    value = by_unit["value"]
    result = {
        "cells": len(value),
        "cohorts": len({r["dataset"] for r in value}),
        "mean_capture_retained": mean(
            [
                number(r["capture_retained"])
                for r in value
                if number(r["capture_retained"]) is not None
            ]
        ),
        "median_capture_retained": quantile(
            [
                number(r["capture_retained"])
                for r in value
                if number(r["capture_retained"]) is not None
            ],
            0.5,
        ),
        "joint_cells": sum(joint(r) for r in value),
        "positive_joint_cells": sum(
            joint(r)
            and number(r["removal"]) is not None
            and number(r["removal"]) > 1e-10
            for r in value
        ),
        "capture_defined": sum(
            number(r["capture_retained"]) is not None for r in value
        ),
        "capture_passes": sum(truth(r["capture_target_met"]) for r in value),
        "value_passes": sum(truth(r["value_cap_met"]) for r in value),
        "capture_above_baseline": sum(
            number(r["capture_retained"]) is not None
            and number(r["capture_retained"]) > 1 + 1e-10
            for r in value
        ),
        "safe_cells": sum(safe(r) for r in value),
    }
    for unit, group in by_unit.items():
        removals = [
            number(r["removal"]) for r in group if number(r["removal"]) is not None
        ]
        result[f"mean_{unit}_removal"] = mean(removals)
        result[f"defined_{unit}_removals"] = len(removals)
    cells = defaultdict(list)
    for row in rows:
        cells[(row["dataset"], row["seed"])].append(number(row["removal"]))
    spreads = [
        max(v) - min(v)
        for v in cells.values()
        if len(v) == 3 and all(x is not None for x in v)
    ]
    result.update(
        spread_defined=len(spreads),
        spread_median=quantile(spreads, 0.5),
        spread_p90=quantile(spreads, 0.9),
        spread_max=max(spreads, default=None),
        spread_over_one_point=mean([x > 0.01 for x in spreads]),
    )
    return result


def linear_summary(cells, policy):
    result = {"cells": len(cells)}
    capture = []
    joint_count = 0
    for cell in cells:
        row = cell["policies"][LINEAR[policy]]
        capture.append(row["captured_loss"] / cell["baseline_captured_loss"])
        joint_count += int(
            row["captured_loss"]
            >= 0.95 * cell["baseline_captured_loss"]
            - 1e-9 * max(1, cell["baseline_captured_loss"])
            and row["blocked_value"]
            <= 0.1 * cell["total_value"] + 1e-9 * max(1, cell["total_value"])
            and min(cell["value_group_totals"]) > 0
            and row["per_group_nonincrease"]["value"]
        )
    result.update(mean_capture_retained=mean(capture), joint_cells=joint_count)
    for unit in ("count", "value", "loss"):
        values = [
            1
            - c["policies"][LINEAR[policy]]["objection_masses"][unit]
            / c["baseline_objection_masses"][unit]
            for c in cells
            if c["baseline_objection_masses"][unit] > 0
        ]
        result[f"mean_{unit}_removal"] = mean(values)
    return result


def penalty_summary(rows):
    result = {}
    for family in ("group", "account", "mixture"):
        selected = [r for r in rows if r["family"] == family]
        result[family] = {
            "cells": len(selected),
            "increases": sum(truth(r["group_increase"]) for r in selected),
            "gap_reductions": sum(truth(r["gap_reduced"]) for r in selected),
            "harmful_reductions": sum(
                truth(r["gap_reduced"]) and truth(r["group_increase"]) for r in selected
            ),
            "safe_reductions": sum(truth(r["safe_gap_reduction"]) for r in selected),
            "baseline_fallbacks": sum(truth(r["baseline_fallback"]) for r in selected),
        }
    return result


def direction_summary(trows, vrows):
    validation = {(r["dataset"], r["seed"]): r for r in vrows}
    result = {}
    for margin in (0.005, 0.01):
        selected = []
        for row in trows:
            key = row["dataset"], row["seed"]
            v = validation[key]
            a = number(v["group_1_baseline"]) - number(v["group_0_baseline"])
            b = number(row["group_1_baseline"]) - number(row["group_0_baseline"])
            if a * b < 0 and abs(a) > margin and abs(b) > margin:
                selected.append(row)
        result[str(margin)] = {
            "cells": len(selected),
            "cohorts": len({r["dataset"] for r in selected}),
            "safe_common_cells": sum(safe(r) for r in selected),
        }
    return result


def sensitivity_summary(rows):
    result = {}
    for family in ("original_repair", "rebuilt_union"):
        selected = [r for r in rows if r["family"] == family]
        result[family] = {
            "cells": len(selected),
            "group_increases": sum(truth(r["group_increase"]) for r in selected),
            "increased_cohorts": len(
                {r["dataset"] for r in selected if truth(r["group_increase"])}
            ),
            "mean_removal": mean(
                [
                    number(r["removal"])
                    for r in selected
                    if number(r["removal"]) is not None
                ]
            ),
            "mean_capture": mean(
                [
                    number(r["capture_retained"])
                    for r in selected
                    if number(r["capture_retained"]) is not None
                ]
            ),
        }
    return result


def paper_table(summary, path):
    slash = chr(92)
    row_end = slash * 2
    lines = [
        "% Generated by scripts/bandha_xgboost_report.py from frozen T.csv.",
        r"\begin{table}[t]",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{2pt}",
        r"\begin{tabular}{@{}lrrrrrr@{}}",
        r"\toprule",
        r"Rule & $R_1$ & $R_A$ & $R_B$ & Capture & $F_C/F_A$ & $J/J_A^+$ " + row_end,
        r"\midrule",
    ]
    labels = {
        "thinning": "Thinning",
        "common": "Common",
        "selective": "Selective",
        "reserve": "Sel.+reserve",
    }
    for policy, label in labels.items():
        r = summary[policy]
        values = [100 * r[f"mean_{u}_removal"] for u in ("count", "value", "loss")]
        line = label + " & " + " & ".join(f"{v:.2f}" for v in values)
        line += f" & {100 * r['mean_capture_retained']:.2f}"
        line += (
            f" & {r['cells'] - r['capture_passes']}/{r['cells'] - r['value_passes']}"
        )
        line += f" & {r['joint_cells']}/{r['positive_joint_cells']} " + row_end
        lines.append(line)
    r = summary["common"]
    coverage = f"Removal support is {r['defined_count_removals']}/{r['defined_value_removals']}/{r['defined_loss_removals']} for count/value/loss; retained-capture support is {r['capture_defined']}."
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\caption{XGBoost predictors, same final $T$, all 240 cells. $R_U$ and Capture are unweighted cell-mean percentages. $F_C/F_A$ counts misses of the 95\% capture/10\% value targets. $J$ requires both targets and defined value-group nonincrease; $J_A^+$ additionally requires positive value-objection removal. "
            + coverage
            + "}",
            r"\label{tab:results}",
            r"\end{table}",
            "",
        ]
    )
    path.write_text("\n".join(lines))


def markdown(report):
    lines = [
        "# XGBoost fairness rerun",
        "",
        "Generator: `scripts/bandha_xgboost_report.py`.",
        "",
        "All predictors are boosted trees: W-BCE baseline and two raw-mean models. Same 24 cohorts, ten seeds, and immutable C/T membership. Training-only inner validation selects duration; all C policies freeze before T assessment. This is exploratory reuse of examined data.",
        "",
        "## Final T",
        "",
        "| Policy | Linear removal (%) | Boosted removal (%) | Linear capture (%) | Boosted capture (%) | Linear J | Boosted J |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for policy, label in LABELS.items():
        a, b = report["linear"][policy], report["boosted"][policy]
        lines.append(
            f"| {label} | {100 * a['mean_value_removal']:.2f} | {100 * b['mean_value_removal']:.2f} | {100 * a['mean_capture_retained']:.2f} | {100 * b['mean_capture_retained']:.2f} | {a['joint_cells']} | {b['joint_cells']} |"
        )
    lines.extend(
        [
            "",
            "Each setup has its own fitted baseline and objection set. These relative percentages do not isolate model quality or establish superiority over a population optimum.",
            "",
            "## Coverage and safety",
            "",
            f"- Final T rows: {report['T_rows']:,}; cohort–seed cells: {report['cells']}.",
            f"- Common pointwise factor error: {report['factor_error']:.3g}; maximum pointwise safety error: {report['safety_error']:.3g}.",
            f"- Both-group value nonincrease: {report['boosted']['common']['safe_cells']}/{report['cells']} common cells.",
            "",
            "## Baseline direction instability",
            "",
        ]
    )
    for margin, row in report["directions"].items():
        lines.append(
            f"- Margin {margin} in both V and T: {row['cells']} reversals across {row['cohorts']} cohorts; common is safe in {row['safe_common_cells']}."
        )
    lines.extend(
        [
            "",
            "## Original-test penalty diagnostics",
            "",
            "| Family | Group increases | Gap reductions | Harmful reductions | Safe reductions | Fallbacks |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for family, row in report["penalties"].items():
        lines.append(
            f"| {family} | {row['increases']} | {row['gap_reductions']} | {row['harmful_reductions']} | {row['safe_reductions']} | {row['baseline_fallbacks']} |"
        )
    lines.extend(
        [
            "",
            "Penalty diagnostics use the full original-test membership. They are separate from final-T contraction comparisons.",
            "",
            "## Provenance",
            "",
            "```json",
            json.dumps(report["inputs"], indent=2),
            "```",
            "",
        ]
    )
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--diagnostics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--v-metrics", type=Path, required=True)
    parser.add_argument("--sensitivity", type=Path, required=True)
    args = parser.parse_args()

    def read(path):
        with path.open() as f:
            return list(csv.DictReader(f))

    rows = read(args.run / "T.csv")
    value = [r for r in rows if r["unit"] == "value"]
    keys = {(r["dataset"], r["seed"]) for r in value}
    if len(keys) != 240 or len({r["dataset"] for r in value}) != 24:
        raise ValueError("Incomplete boosted panel")
    boosted = {p: summarize([r for r in rows if r["policy"] == p]) for p in LABELS}
    reference_path = (
        args.root / "paper_support/wsdm_short/ultra_wsdm_frozen_evidence_20261106.json"
    )
    cells = json.loads(reference_path.read_text())["cell_evidence"]
    if {(c["dataset"], str(c["seed"])) for c in cells} != keys:
        raise ValueError("Linear/boosted panel differs")
    report = {
        "cells": len(keys),
        "T_rows": sum(int(r["n_rows"]) for r in value if r["policy"] == "baseline"),
        "boosted": boosted,
        "linear": {p: linear_summary(cells, p) for p in LABELS},
        "factor_error": max(
            float(r["factor_error"]) for r in rows if r["policy"] == "common"
        ),
        "safety_error": max(float(r["pointwise_safety_error"]) for r in rows),
        "directions": direction_summary(
            [r for r in value if r["policy"] == "common"], read(args.v_metrics)
        ),
        "sensitivity": sensitivity_summary(read(args.sensitivity / "T.csv")),
        "penalties": penalty_summary(read(args.diagnostics / "original_test.csv")),
        "inputs": {
            str(p): digest(p)
            for p in (
                args.run / "T.csv",
                reference_path,
                args.diagnostics / "original_test.csv",
                args.v_metrics,
                Path(__file__),
            )
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "summary.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n"
    )
    (args.output / "report.md").write_text(markdown(report))
    paper_table(boosted, args.output / "results_table.tex")
    print(
        json.dumps(
            {
                "cells": report["cells"],
                "boosted": boosted,
                "directions": report["directions"],
                "penalties": report["penalties"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
