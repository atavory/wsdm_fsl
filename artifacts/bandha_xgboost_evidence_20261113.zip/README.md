# Frozen XGBoost paper evidence

All 240 cells; boosted baseline and criteria. Aggregate outcomes contain no raw feature rows. Python 3.12+ stdlib suffices.

Run from this extracted directory:

```sh
python scripts/bandha_xgboost_report.py --root . --run results/csvs/bandha_xgboost_20261113/main --diagnostics results/csvs/bandha_xgboost_20261113/diagnostics --sensitivity results/csvs/bandha_xgboost_20261113/sensitivity --v-metrics results/csvs/bandha_xgboost_20261113/sensitivity/V_metrics.csv --output reproduced
```

The reproduced table must match the frozen results_table.tex byte-for-byte. Summary scientific fields must agree; provenance paths differ on another machine. The training runtime support is a separate archive.
