# Agarwal comparison with original training data

Owner: bandha. Follow-up within the user-authorized comparator task.
The C-trained adaptation remains intact as a separate diagnostic.
Its observed C-to-T divergence prompted this protocol check, so this follow-up
is exploratory and not independent confirmation.

- Train actual Fairlearn exponentiated-gradient cost-sensitive XGBoost
  classifiers on the original training split. Preserve feature transformations,
  pretrained boosted baseline and criterion models, V thresholds, and C/T IDs.
- Compute training criterion indicators using the existing saved mean models
  and V-frozen thresholds. No new norm model or test-derived threshold.
- Keep exactly the same learner settings and moment definitions as the
  C-trained variant: depth 6, 100 rounds, eta .05, min_child_weight 5, row/column
  subsampling .8, lambda 1, initial probability .5; EG max_iter 50, eps/nu .002.
  Gap cap .01, value cap .10, capture floor .95 of same-split baseline.
- Report the direct training-EG mixture on C and T. Separately calibrate a
  mixture over acquired classifiers, baseline, and all-pass on C under the
  same constraints. Freeze all C weights before T outcome assessment.
- Retain the C-trained and original-training results without selecting a
  favorable algorithm or hyperparameter from T. The original-training variant
  matches the normal predictive-learning split and is the appropriate primary
  algorithm comparison; the C-trained version is an adaptation diagnostic.
- Keep every one of the 240 cells and all approximate-constraint/acquired-bank
  failure flags. Interpret finite XGBoost responses as approximate, not an
  exact optimal-classifier guarantee. Live paper changes belong to fsll.
