"""Fit actual Agarwal EG classifiers on frozen C; seal before T evaluation."""

from __future__ import annotations

import argparse
import concurrent.futures
import csv
import hashlib
import importlib.metadata
import json
import sys
import time
from pathlib import Path

import numpy as np
from bandha_agarwal_reductions_20261114 import (
    CaptureObjective,
    CSXGBoost,
    ObjectionConstraints,
)
from fairlearn.reductions import ExponentiatedGradient
from scipy.optimize import linprog


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n")


def csv_output(path, rows):
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def imports(public):
    sys.path.insert(0, str(public / "fairness"))
    import bandha_xgboost_rerun as source
    from bandha_external_criteria_study import business_metrics, unit_metrics

    return source, business_metrics, unit_metrics


def evaluate(array, baseline, prediction, case, family, public):
    source, business_metrics, unit_metrics = imports(public)
    q = source.frozen.native(array)
    if np.min(prediction) < -1e-8 or np.max(prediction) > 1 + 1e-8:
        raise ValueError("Invalid mixture probability")
    rows = []
    for unit in ("count", "value", "loss"):
        row = {
            "dataset": case["dataset"],
            "seed": case["seed"],
            "source": case["source"],
            "family": family,
            "unit": unit,
        }
        row.update(business_metrics(array, baseline, prediction))
        row.update(unit_metrics(array, baseline, prediction, q, unit))
        defined = all(row[f"group_{g}_level"] != "" for g in (0, 1))
        increase = (
            max(
                (row[f"group_{g}_level"] - row[f"group_{g}_baseline"] for g in (0, 1)),
                default=0,
            )
            if defined
            else None
        )
        gap = row["group_1_level"] - row["group_0_level"] if defined else None
        base_gap = (
            row["group_1_baseline"] - row["group_0_baseline"] if defined else None
        )
        row.update(
            group_nonincrease=defined and increase <= 1e-10,
            group_increase=defined and increase > 1e-10,
            signed_gap=gap,
            baseline_signed_gap=base_gap,
            gap_reduced=defined and abs(gap) < abs(base_gap) - 1e-10,
            gap_target_met=defined and abs(gap) <= 0.01 + 1e-8,
        )
        row["joint"] = (
            row["capture_target_met"]
            and row["value_cap_met"]
            and row["group_nonincrease"]
        )
        rows.append(row)
    return rows


def calibrate(bank, array, baseline):
    a, b, group = array[:, 2], array[:, 3], array[:, 0]
    q = ~((array[:, 6] > 0.5) & (array[:, 7] > 0.5))
    group_totals = [a[group == g].sum() for g in (0, 1)]
    gap = q * a * ((group == 1) / group_totals[1] - (group == 0) / group_totals[0])
    gaps, costs, captures = bank @ gap, bank @ a / a.sum(), bank @ b / b.sum()
    required = 0.95 * np.sum(baseline * b) / b.sum()
    matrix = np.array([gaps, -gaps, costs, -captures])
    bounds = [0.01, 0.01, 0.10, -required]
    result = linprog(
        -captures,
        A_ub=matrix,
        b_ub=bounds,
        A_eq=[np.ones(len(bank))],
        b_eq=[1],
        bounds=(0, None),
        method="highs",
    )
    status = "feasible_acquired_bank"
    if result.status == 2:
        result = linprog(
            -captures,
            A_ub=matrix[:3],
            b_ub=bounds[:3],
            A_eq=[np.ones(len(bank))],
            b_eq=[1],
            bounds=(0, None),
            method="highs",
        )
        status = "capture_floor_infeasible_acquired_bank"
    if not result.success:
        raise RuntimeError(f"Acquired-bank LP failed: {result.message}")
    weights = np.maximum(result.x, 0)
    weights /= weights.sum()
    return weights, status


def recover_cell(case, args):
    source, _, _ = imports(args.public_root)
    label = case["dataset"] + "__" + case["seed"]
    original = args.run / "cells" / label
    record = json.loads((original / "C_SEAL.json").read_text())
    saved = np.load(original / "PREDICTIONS.npz")
    array = saved["C"]
    designs, ids, y, a, b, group, accounts, raw_path = source.load_case(case, args.raw)
    c_mask = source.partition(case)
    if not np.array_equal(ids[2][c_mask], saved["C_ids"]) or not np.array_equal(
        ids[2][~c_mask], saved["T_ids"]
    ):
        raise ValueError("C/T feature identities changed")
    if sha(raw_path) != record["raw_sha256"]:
        raise ValueError("Raw feature input differs")
    xc, xt = designs[2][c_mask], designs[2][~c_mask]
    baseline = source.frozen.baseline(array, record["case"])
    return source, record, saved, array, xc, xt, y[ids[2][c_mask]], baseline


def train_cell(array, baseline, xc, xt, labels, case, args, directory):
    algorithm = ExponentiatedGradient(
        CSXGBoost(seed=910000 + int(case["seed"]), threads=args.threads, rounds=100),
        ObjectionConstraints(array, baseline),
        objective=CaptureObjective(array[:, 3]),
        eps=0.002,
        nu=0.002,
        max_iter=50,
        run_linprog_step=True,
    )
    algorithm.fit(xc, labels, sensitive_features=array[:, 0].astype(int))
    c_bank = [baseline, np.zeros(len(array))]
    t_bank = []
    predictors = list(algorithm.predictors_.items())
    for index, predictor in predictors:
        c_bank.append(np.asarray(predictor.predict(xc), dtype=float))
        t_bank.append(np.asarray(predictor.predict(xt), dtype=float))
        if hasattr(predictor, "model_"):
            predictor.model_.save_model(directory / f"bandha_model_{index}.ubj")
    bank = np.array(c_bank)
    raw_weights = np.array(
        [float(algorithm.weights_.get(index, 0)) for index, _ in predictors]
    )
    if abs(raw_weights.sum() - 1) > 1e-7:
        raise ValueError("EG mixture weights are not normalized")
    calibration, status = calibrate(bank, array, baseline)
    c_raw, c_cal = raw_weights @ bank[2:], calibration @ bank
    return (
        algorithm,
        predictors,
        bank,
        t_bank,
        raw_weights,
        calibration,
        status,
        c_raw,
        c_cal,
    )


def fit_cell(task):
    case, args = task
    label = case["dataset"] + "__" + case["seed"]
    directory = args.output / ("bandha_" + label)
    directory.mkdir(parents=True, exist_ok=True)
    if (directory / "bandha_C_seal.json").exists():
        old = json.loads((directory / "bandha_C_seal.json").read_text())
        if old.get("fit_identity") != identity(args):
            raise ValueError(
                "Cached fitting code differs; use a fresh output directory"
            )
        return label, "cached", 0
    start = time.monotonic()
    source, record, saved, array, xc, xt, labels, baseline = recover_cell(case, args)
    (
        algorithm,
        predictors,
        bank,
        t_bank,
        raw_weights,
        calibration,
        status,
        c_raw,
        c_cal,
    ) = train_cell(array, baseline, xc, xt, labels, case, args, directory)
    # T probabilities use frozen classifiers/weights; numeric T outcomes are not read here.
    t_baseline = record["case"]["baseline_alpha"] * (
        (saved["T"][:, 1] >= record["case"]["baseline_threshold"])
        & (saved["T"][:, 1] > 0)
    )
    t_complete = np.vstack([t_baseline, np.zeros(len(xt)), *t_bank])
    np.savez_compressed(
        directory / "bandha_predictions.npz",
        C_raw=c_raw,
        C_cal=c_cal,
        T_raw=raw_weights @ t_complete[2:],
        T_cal=calibration @ t_complete,
    )
    csv_output(
        directory / "bandha_C.csv",
        evaluate(array, baseline, c_raw, case, "agarwal_eg", args.public_root)
        + evaluate(array, baseline, c_cal, case, "agarwal_eg_Ccal", args.public_root),
    )
    save(
        directory / "bandha_C_seal.json",
        {
            "case": record["case"],
            "fit_identity": identity(args),
            "original_predictions_sha256": record["predictions_sha256"],
            "predictors": [int(index) for index, _ in predictors],
            "EG_weights": raw_weights.tolist(),
            "Ccal_weights": calibration.tolist(),
            "Ccal_status": status,
            "best_gap": float(algorithm.best_gap_),
            "best_iter": int(algorithm.best_iter_),
            "last_iter": int(algorithm.last_iter_),
            "oracle_calls": int(algorithm.n_oracle_calls_),
            "n_classifiers": len(predictors),
            "seconds": time.monotonic() - start,
            "T_metrics_evaluated": False,
            "predictions_sha256": sha(directory / "bandha_predictions.npz"),
        },
    )
    return label, round(time.monotonic() - start, 2), algorithm.n_oracle_calls_


def identity(args):
    paths = [
        Path(__file__),
        Path(__file__).with_name("bandha_agarwal_reductions_20261114.py"),
        args.root / "bandha_agarwal_protocol_20261114.md",
    ]
    return {
        "code": {str(p): sha(p) for p in paths},
        "original_C_freeze": sha(args.run / "C_FREEZE.json"),
        "packages": {
            p: importlib.metadata.version(p)
            for p in (
                "fairlearn",
                "xgboost",
                "numpy",
                "scipy",
                "scikit-learn",
            )
        },
    }


def fit_phase(args, cases):
    save(args.output / "bandha_SOURCE_SEAL.json", identity(args))
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(fit_cell, (case, args)) for case in cases]
        complete = []
        for future in concurrent.futures.as_completed(futures):
            label, seconds, calls = future.result()
            complete.append(label)
            print(
                f"C sealed {len(complete)}/{len(cases)}: {label}, {seconds}s, {calls} oracle calls",
                flush=True,
            )
            save(
                args.output / "bandha_PROGRESS.json",
                {"completed": complete, "total": len(cases)},
            )
    seals = {
        case["dataset"] + "__" + case["seed"]: sha(
            args.output
            / ("bandha_" + case["dataset"] + "__" + case["seed"])
            / "bandha_C_seal.json"
        )
        for case in cases
    }
    save(
        args.output / "bandha_C_FREEZE.json",
        {"identity": identity(args), "seals": seals, "T_metrics_evaluated": False},
    )


def test_phase(args, cases):
    source, _, _ = imports(args.public_root)
    seal = json.loads((args.output / "bandha_C_FREEZE.json").read_text())
    if seal["identity"] != identity(args):
        raise ValueError("Code or inputs changed after C fitting")
    rows, c_rows = [], []
    for case in cases:
        label = case["dataset"] + "__" + case["seed"]
        directory = args.output / ("bandha_" + label)
        if sha(directory / "bandha_C_seal.json") != seal["seals"][label]:
            raise ValueError("Cell seal changed")
        record = json.loads((directory / "bandha_C_seal.json").read_text())
        original = args.run / "cells" / label / "PREDICTIONS.npz"
        if sha(original) != record["original_predictions_sha256"]:
            raise ValueError("Original predictions changed")
        arrays, probabilities = (
            np.load(original),
            np.load(directory / "bandha_predictions.npz"),
        )
        for part, target in (("C", c_rows), ("T", rows)):
            data = arrays[part]
            baseline = source.frozen.baseline(data, record["case"])
            for key, family in (("raw", "agarwal_eg"), ("cal", "agarwal_eg_Ccal")):
                outcomes = evaluate(
                    data,
                    baseline,
                    probabilities[f"{part}_{key}"],
                    case,
                    family,
                    args.public_root,
                )
                for row in outcomes:
                    row["part"] = part
                target.extend(outcomes)
    csv_output(args.output / "bandha_T.csv", rows)
    csv_output(args.output / "bandha_C.csv", c_rows)
    save(
        args.output / "bandha_T_PROVENANCE.json",
        {
            "C_freeze_sha256": sha(args.output / "bandha_C_FREEZE.json"),
            "T_csv_sha256": sha(args.output / "bandha_T.csv"),
            "cells": len(cases),
            "no_T_selection": True,
        },
    )
    print(f"T complete: {len(cases)} cells", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("fit", "test"))
    for name in ("root", "public-root", "run", "raw", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--canary", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(
        (
            args.root / "results/csvs/bandha_external_criteria_inputs_20261113.json"
        ).read_text()
    )
    cases = manifest["cases"]
    if args.canary:
        cases = [
            c for c in cases if c["dataset"] == "german_credit_sex" and c["seed"] == "0"
        ]
    if args.phase == "fit":
        fit_phase(args, cases)
    else:
        test_phase(args, cases)


if __name__ == "__main__":
    main()
