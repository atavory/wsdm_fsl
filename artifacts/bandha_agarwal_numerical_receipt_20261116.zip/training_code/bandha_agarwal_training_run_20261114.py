"""Agarwal EG on original training rows; independent frozen C/T comparison."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import sys
import time
from pathlib import Path

import bandha_agarwal_run_20261114 as base
import numpy as np
import xgboost as xgb


def identity(args):
    paths = [
        Path(__file__),
        Path(base.__file__),
        Path(base.__file__).with_name("bandha_agarwal_reductions_20261114.py"),
        args.root / "bandha_agarwal_training_protocol_20261114.md",
    ]
    return {
        "code": {str(p): base.sha(p) for p in paths},
        "original_C_freeze": base.sha(args.run / "C_FREEZE.json"),
        "fit_split": "original_train",
        "packages": base.identity(args)["packages"],
    }


def training_data(case, args, record, saved):
    source, _, _ = base.imports(args.public_root)
    designs, ids, y, a, b, group, accounts, raw_path = source.load_case(case, args.raw)
    mask = source.partition(case)
    if (
        not np.array_equal(ids[0], saved["train_ids"])
        or not np.array_equal(ids[2][mask], saved["C_ids"])
        or not np.array_equal(ids[2][~mask], saved["T_ids"])
    ):
        raise ValueError("Training/C/T identity changed")
    if base.sha(raw_path) != record["raw_sha256"]:
        raise ValueError("Raw input changed")
    sys.path.insert(0, str(args.public_root / "fairness"))
    import bandha_xgboost_models as frozen_models

    original = args.run / "cells" / (case["dataset"] + "__" + case["seed"])
    models = {
        name: xgb.Booster(model_file=str(original / (name + ".ubj")))
        for name in ("wbce", "value", "loss")
    }
    logit, ah, bh = frozen_models.predict(
        models, record["models"], designs[0], args.threads
    )
    thresholds = record["case"]["boosted_criterion_thresholds"]
    train = ids[0]
    array = np.column_stack(
        (
            group[train],
            np.exp(np.clip(logit, -50, 50)),
            a[train],
            b[train],
            ah,
            bh,
            bh >= thresholds["harm"],
            bh - ah >= thresholds["net_harm"],
            logit >= thresholds["wbce_ratio"],
        )
    )
    return designs[0], designs[2][mask], designs[2][~mask], y[train], array


def worker(task):
    case, args = task
    label = case["dataset"] + "__" + case["seed"]
    directory = args.output / ("bandha_" + label)
    directory.mkdir(exist_ok=True)
    start = time.monotonic()
    original = args.run / "cells" / label
    record = json.loads((original / "C_SEAL.json").read_text())
    saved = np.load(original / "PREDICTIONS.npz")
    source, _, _ = base.imports(args.public_root)
    xtrain, xc, xt, labels, train = training_data(case, args, record, saved)
    ptrain = source.frozen.baseline(train, record["case"])
    fitted = base.train_cell(train, ptrain, xtrain, xc, labels, case, args, directory)
    algorithm, predictors, _, c_predictions, raw_weights, _, _, _, _ = fitted
    c = saved["C"]
    pc = source.frozen.baseline(c, record["case"])
    c_bank = np.vstack([pc, np.zeros(len(c)), *c_predictions])
    calibrated, status = base.calibrate(c_bank, c, pc)
    c_raw, c_cal = raw_weights @ c_bank[2:], calibrated @ c_bank
    t_info = saved["T"]
    pt = source.frozen.baseline(t_info, record["case"])
    t_predictions = [
        np.asarray(model.predict(xt), dtype=float) for _, model in predictors
    ]
    t_bank = np.vstack([pt, np.zeros(len(xt)), *t_predictions])
    np.savez_compressed(
        directory / "bandha_predictions.npz",
        C_raw=c_raw,
        C_cal=c_cal,
        T_raw=raw_weights @ t_bank[2:],
        T_cal=calibrated @ t_bank,
    )
    base.csv_output(
        directory / "bandha_C.csv",
        base.evaluate(c, pc, c_raw, case, "agarwal_eg", args.public_root)
        + base.evaluate(c, pc, c_cal, case, "agarwal_eg_Ccal", args.public_root),
    )
    base.save(
        directory / "bandha_C_seal.json",
        {
            "case": record["case"],
            "fit_identity": identity(args),
            "fit_split": "original_train",
            "original_predictions_sha256": record["predictions_sha256"],
            "predictors": [int(i) for i, _ in predictors],
            "EG_weights": raw_weights.tolist(),
            "Ccal_weights": calibrated.tolist(),
            "Ccal_status": status,
            "best_gap": float(algorithm.best_gap_),
            "best_iter": int(algorithm.best_iter_),
            "last_iter": int(algorithm.last_iter_),
            "oracle_calls": int(algorithm.n_oracle_calls_),
            "n_classifiers": len(predictors),
            "seconds": time.monotonic() - start,
            "T_metrics_evaluated": False,
            "predictions_sha256": base.sha(directory / "bandha_predictions.npz"),
        },
    )
    return label, round(time.monotonic() - start, 2), algorithm.n_oracle_calls_


def fit(args, cases):
    base.save(args.output / "bandha_SOURCE_SEAL.json", identity(args))
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(worker, (case, args)) for case in cases]
        done = []
        for f in concurrent.futures.as_completed(futures):
            label, seconds, calls = f.result()
            done.append(label)
            print(
                f"C sealed {len(done)}/{len(cases)}: {label}, {seconds}s, {calls} oracle calls",
                flush=True,
            )
            base.save(
                args.output / "bandha_PROGRESS.json",
                {"completed": done, "total": len(cases)},
            )
    seals = {
        c["dataset"] + "__" + c["seed"]: base.sha(
            args.output
            / ("bandha_" + c["dataset"] + "__" + c["seed"])
            / "bandha_C_seal.json"
        )
        for c in cases
    }
    base.save(
        args.output / "bandha_C_FREEZE.json",
        {"identity": identity(args), "seals": seals, "T_metrics_evaluated": False},
    )


def test(args, cases):
    source, _, _ = base.imports(args.public_root)
    freeze = json.loads((args.output / "bandha_C_FREEZE.json").read_text())
    if freeze["identity"] != identity(args):
        raise ValueError("Fitting code or inputs changed")
    rows, crows = [], []
    for case in cases:
        label = case["dataset"] + "__" + case["seed"]
        directory = args.output / ("bandha_" + label)
        if base.sha(directory / "bandha_C_seal.json") != freeze["seals"][label]:
            raise ValueError("C seal changed")
        record = json.loads((directory / "bandha_C_seal.json").read_text())
        if (
            base.sha(directory / "bandha_predictions.npz")
            != record["predictions_sha256"]
        ):
            raise ValueError("Prediction freeze changed")
        original = args.run / "cells" / label / "PREDICTIONS.npz"
        if base.sha(original) != record["original_predictions_sha256"]:
            raise ValueError("Original inputs changed")
        arrays, p = np.load(original), np.load(directory / "bandha_predictions.npz")
        for part, target in (("C", crows), ("T", rows)):
            data = arrays[part]
            p0 = source.frozen.baseline(data, record["case"])
            for key, name in (("raw", "agarwal_eg"), ("cal", "agarwal_eg_Ccal")):
                result = base.evaluate(
                    data, p0, p[part + "_" + key], case, name, args.public_root
                )
                for r in result:
                    r["part"] = part
                target.extend(result)
    base.csv_output(args.output / "bandha_T.csv", rows)
    base.csv_output(args.output / "bandha_C.csv", crows)
    base.save(
        args.output / "bandha_T_PROVENANCE.json",
        {
            "C_freeze_sha256": base.sha(args.output / "bandha_C_FREEZE.json"),
            "T_sha256": base.sha(args.output / "bandha_T.csv"),
            "cells": len(cases),
            "no_T_parameter_selection": True,
            "exploratory_after_Cfit_variant": True,
        },
    )
    print("T complete:", len(cases), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("fit", "test"))
    for name in ("root", "public-root", "run", "raw", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--canary", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    cases = json.loads(
        (
            args.root / "results/csvs/bandha_external_criteria_inputs_20261113.json"
        ).read_text()
    )["cases"]
    if args.canary:
        cases = [
            c for c in cases if c["dataset"] == "german_credit_sex" and c["seed"] == "0"
        ]
    if args.phase == "fit":
        fit(args, cases)
    else:
        test(args, cases)


if __name__ == "__main__":
    main()
