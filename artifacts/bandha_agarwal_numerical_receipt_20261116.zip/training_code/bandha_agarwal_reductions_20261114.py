"""Task-specific moments and XGBoost best responses for Agarwal reductions."""

from __future__ import annotations

import numpy as np
import pandas as pd
import xgboost as xgb
from fairlearn.reductions import ClassificationMoment
from sklearn.base import BaseEstimator, ClassifierMixin


class CaptureObjective(ClassificationMoment):
    def __init__(self, loss):
        super().__init__()
        self.loss = np.asarray(loss, dtype=float)
        self.coefficients = self.loss / self.loss.mean()

    def load_data(self, X, y, *, sensitive_features=None):
        sf = None if sensitive_features is None else pd.Series(sensitive_features)
        super().load_data(X, pd.Series(y), sensitive_features=sf)

    @property
    def index(self):
        return pd.Index(["missed_capture"])

    def gamma(self, predictor):
        prediction = np.asarray(predictor(self.X), dtype=float).reshape(-1)
        return pd.Series(
            [1 - np.mean(prediction * self.coefficients)], index=self.index
        )

    def signed_weights(self, lambda_vec=None):
        return pd.Series(self.coefficients)

    def project_lambda(self, lambda_vec):
        return lambda_vec


class ObjectionConstraints(ClassificationMoment):
    def __init__(self, array, baseline, gap_bound=0.01):
        super().__init__()
        self.array = np.asarray(array, dtype=float)
        self.baseline = np.asarray(baseline, dtype=float)
        self.gap_bound = gap_bound

    def load_data(self, X, y, *, sensitive_features):
        super().load_data(
            X, pd.Series(y), sensitive_features=pd.Series(sensitive_features)
        )
        n = len(self.array)
        group, value, loss = self.array[:, 0], self.array[:, 2], self.array[:, 3]
        q = ~((self.array[:, 6] > 0.5) & (self.array[:, 7] > 0.5))
        totals = [value[group == g].sum() for g in (0, 1)]
        if min(totals) <= 0 or loss.sum() <= 0:
            raise ValueError("Undefined C group-value or loss support")
        gap = n * q * value * ((group == 1) / totals[1] - (group == 0) / totals[0])
        self.matrix = np.array([gap, -gap, value / value.mean(), -loss / loss.mean()])
        required = 0.95 * np.sum(self.baseline * loss) / loss.sum()
        self.bounds = pd.Series(
            [self.gap_bound, self.gap_bound, 0.10, -required], index=self.index
        )

    @property
    def index(self):
        return pd.Index(["gap_positive", "gap_negative", "value", "capture"])

    def gamma(self, predictor):
        prediction = np.asarray(predictor(self.X), dtype=float).reshape(-1)
        return pd.Series(np.mean(self.matrix * prediction, axis=1), index=self.index)

    def bound(self):
        return self.bounds

    def signed_weights(self, lambda_vec):
        return pd.Series(-np.asarray(lambda_vec) @ self.matrix)

    def project_lambda(self, lambda_vec):
        return lambda_vec

    def default_objective(self):
        return CaptureObjective(self.array[:, 3])


class CSXGBoost(ClassifierMixin, BaseEstimator):
    def __init__(self, seed=0, threads=2, rounds=100):
        self.seed = seed
        self.threads = threads
        self.rounds = rounds

    def fit(self, X, y, sample_weight=None):
        self.classes_ = np.array([0, 1])
        weights = (
            np.ones(len(y)) if sample_weight is None else np.asarray(sample_weight)
        )
        self.model_ = xgb.train(
            {
                "objective": "binary:logistic",
                "base_score": 0.5,
                "tree_method": "hist",
                "max_depth": 6,
                "eta": 0.05,
                "lambda": 1.0,
                "min_child_weight": 5,
                "subsample": 0.8,
                "colsample_bytree": 0.8,
                "seed": self.seed,
                "nthread": self.threads,
            },
            xgb.DMatrix(X, label=np.asarray(y), weight=weights, nthread=self.threads),
            self.rounds,
            verbose_eval=False,
        )
        return self

    def predict(self, X):
        margin = self.model_.predict(
            xgb.DMatrix(X, nthread=self.threads), output_margin=True
        )
        return (margin >= 0).astype(int)
