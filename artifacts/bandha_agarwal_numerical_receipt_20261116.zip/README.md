# Portable numerical receipt for the Agarwal comparison

This package recomputes the reported task-specific Fairlearn EG comparison from frozen CSVs. Run:

    python3 bandha_verify_agarwal_receipt_20261116.py

It verifies file hashes, the complete 240-cell matched baseline summaries, and the reported 34 of 66 value-gap-and-budget cases with a group increase. It also reproduces the 92-cell subset where both the common rule and the C-calibrated reduction respect the value cap.

Original-training classifiers and acquired-bank C calibration form the main comparison. The earlier C-fitted adaptation is retained as a diagnostic. Neither is independent confirmation. Raw EG and C-calibrated EG are different methods. The adapted moments target missed capture, a .01 absolute value-objection gap, .10 total-value spending, and .95 baseline capture. No group-level nonincrease constraint was fitted.

Full-panel means include target failures. Comparable budget-restricted statistics and the group-increase count are reported separately. The reductions framework can impose level constraints; this particular gap-constrained experiment does not establish inferiority of the entire framework.

The included training sources match the original source-seal hashes. They require the public baseline runtime, raw data, and generated baseline model/prediction cache for retraining. This package's standalone verified scope is numerical reproduction, not a fresh end-to-end training run.
