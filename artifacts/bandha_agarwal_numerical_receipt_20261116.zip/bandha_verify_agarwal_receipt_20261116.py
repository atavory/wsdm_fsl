"""Recompute the published Agarwal comparison from portable frozen CSVs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path


def read(path):
    with path.open() as handle:
        return list(csv.DictReader(handle))


def number(row, name):
    raw = row[name]
    if raw == "":
        return None
    result = float(raw)
    if not math.isfinite(result):
        raise ValueError("Nonfinite number: " + name)
    return result


def key(row):
    return row["dataset"], row["seed"]


def derive(row):
    b0, b = number(row, "baseline_capture"), number(row, "capture")
    total, value = number(row, "total_value"), number(row, "blocked_value")
    safe = all(number(row, f"group_{g}_level") <= number(row, f"group_{g}_baseline") + 1e-10 for g in (0, 1))
    gap = abs(number(row, "group_1_level") - number(row, "group_0_level"))
    return {
        "key": key(row), "safe": safe, "gap_met": gap <= .01 + 1e-8,
        "value_met": value <= .10 * total + 1e-9 * max(1, total),
        "capture_met": b >= .95 * b0 - 1e-9 * max(1, b0),
        "removal": number(row, "removal"),
        "capture_retained": b / b0 if b0 > 0 else None,
    }


def summary(rows):
    values = [r["removal"] for r in rows if r["removal"] is not None]
    return {
        "cells": len(rows), "removal_support": len(values),
        "mean_value_removal_percent": 100 * statistics.mean(values),
        "group_nonincrease": sum(r["safe"] for r in rows),
        "gap_met": sum(r["gap_met"] for r in rows),
        "value_met": sum(r["value_met"] for r in rows),
        "capture_met": sum(r["capture_met"] for r in rows),
        "joint": sum(r["safe"] and r["value_met"] and r["capture_met"] for r in rows),
    }


def matched(original, reductions):
    baseline = {key(r): r for r in original if r["policy"] == "baseline"}
    if len(baseline) != 240:
        raise ValueError("Expected 240 baseline cells")
    for family in ("agarwal_eg", "agarwal_eg_Ccal"):
        rows = [r for r in reductions if r["family"] == family]
        if len(rows) != 240 or {key(r) for r in rows} != set(baseline):
            raise ValueError("Incomplete reductions panel")
        for row in rows:
            before = baseline[key(row)]
            if row["n_rows"] != before["n_rows"]:
                raise ValueError("Evaluation size differs")
            for field in ("baseline_capture", "baseline_objection_mass", "total_value", "group_0_denominator", "group_1_denominator"):
                a, b = number(row, field), number(before, field)
                if abs(a - b) > 1e-8 * max(1, abs(b)):
                    raise ValueError("Baseline/norm mismatch: " + field)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    manifest = json.loads((args.root / "bandha_manifest.json").read_text())
    for name, sha in manifest["sha256"].items():
        if hashlib.sha256((args.root / name).read_bytes()).hexdigest() != sha:
            raise ValueError("File checksum mismatch: " + name)
    original = [r for r in read(args.root / "bandha_controls_T.csv") if r["unit"] == "value"]
    reductions = [r for r in read(args.root / "original_train/bandha_T.csv") if r["unit"] == "value"]
    matched(original, reductions)
    common = [derive(r) for r in original if r["policy"] == "common"]
    groups = {name: [derive(r) for r in reductions if r["family"] == name] for name in ("agarwal_eg", "agarwal_eg_Ccal")}
    calibrated = groups["agarwal_eg_Ccal"]
    gap_cap = [r for r in calibrated if r["gap_met"] and r["value_met"]]
    both = {r["key"] for r in calibrated if r["value_met"]} & {r["key"] for r in common if r["value_met"]}
    result = {
        "main": {name: summary(rows) for name, rows in groups.items()},
        "calibrated_gap_and_value_cap": len(gap_cap),
        "group_increases_in_that_subset": sum(not r["safe"] for r in gap_cap),
        "both_methods_value_cap": {
            "common": summary([r for r in common if r["key"] in both]),
            "calibrated_EG": summary([r for r in calibrated if r["key"] in both]),
        },
    }
    if len(gap_cap) != 66 or result["group_increases_in_that_subset"] != 34 or len(both) != 92:
        raise ValueError("Published counts did not reproduce")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
