"""Generate descriptive natural-cohort endpoints from the common Figure 3 bank."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess

DATASETS = [('Australian MTPL', 'australian_mtpl_group_blind'),
            ('Belgian MTPL', 'belgian_mtpl_group_blind'),
            ('KuaiRand', 'kuairand_group_blind')]
BASELINES = {'bce', 'fitted_wbce', 'plugin_ratio'}

def read(path):
    with path.open(newline='') as f:
        return list(csv.DictReader(f))

def interval(values):
    if len(values) != 10:
        raise ValueError('Require ten paired splits')
    return statistics.mean(values), 2.2621571628540993 * statistics.stdev(values) / math.sqrt(10)

def cell(values):
    mean, half = interval(values)
    return f'${mean:.3f}\\pm{half:.3f}$'

def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=root / 'results/tables/bandha_figure3_endpoints.tex')
    parser.add_argument('--provenance', type=Path, default=root / 'results/bandha_figure3_endpoint_table_provenance.json')
    args = parser.parse_args()
    bank_path = root / 'results/csvs/bandha_figure3_policy_bank.csv'
    summary_path = root / 'results/csvs/bandha_figure3_policy_summary.csv'
    bank, summary = read(bank_path), read(summary_path)
    lines = [r'\begin{tabular}{llccc}', r'\toprule',
             r'Cohort & Policy & $L/L_0$ & $1-O/O_0$ & $V$ \\', r'\midrule']
    selected = []
    for label, dataset in DATASETS:
        means = [r for r in summary if r['dataset'] == dataset and r['unit'] == 'count']
        baseline = next(r for r in means if r['policy_family'] == 'fitted_wbce')
        endpoints = [r for r in means if r['policy_family'] not in BASELINES and float(r['objection_level']) == 0.0]
        if not endpoints:
            raise ValueError(f'{dataset}: no observed zero-objection policy')
        endpoint = max(endpoints, key=lambda r: (float(r['capture_fraction']), r['policy_id']))
        baselines = {r['seed']: r for r in bank if r['dataset'] == dataset and r['unit'] == 'count'
                     and r['split'] == 'test' and r['policy_family'] == 'fitted_wbce'}
        if set(baselines) != {str(i) for i in range(10)}:
            raise ValueError('Incomplete reference seeds')
        for policy, row in [('W-BCE', baseline), ('Priced endpoint', endpoint)]:
            rows = sorted([r for r in bank if r['dataset'] == dataset and r['unit'] == 'count'
                           and r['split'] == 'test' and r['policy_family'] == row['policy_family']
                           and r['price_rule_id'] == row['price_rule_id']], key=lambda r: int(r['seed']))
            if len(rows) != 10 or {r['seed'] for r in rows} != set(baselines):
                raise ValueError('Incomplete policy seeds')
            capture, closure, spend = [], [], []
            for r in rows:
                b = baselines[r['seed']]
                if float(b['capture']) <= 0 or float(b['objection_level']) <= 0:
                    raise ValueError('Undefined relative reference')
                capture.append(float(r['capture']) / float(b['capture']))
                closure.append(1 - float(r['objection_level']) / float(b['objection_level']))
                spend.append(float(r['value_budget']))
            lines.append(f'{label if policy == "W-BCE" else ""} & {policy} & {cell(capture)} & {cell(closure)} & {cell(spend)} '+r'\\')
            selected.append({'dataset': dataset, 'label': policy, 'policy_id': row['policy_id'],
                             'policy_family': row['policy_family'], 'price_rule_id': row['price_rule_id'],
                             'capture': interval(capture), 'closure': interval(closure), 'test_budget': interval(spend)})
        lines.append(r'\addlinespace')
    lines += [r'\bottomrule', r'\end{tabular}']
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text('\n'.join(lines) + '\n')
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    report = {'data_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
              'source_sha256': digest(Path(__file__)),
              'input_sha256': {str(p.relative_to(root)): digest(p) for p in [bank_path, summary_path]},
              'output_sha256': digest(args.output), 'selected': selected,
              'selection': 'Maximum mean test capture among evaluated price policies with zero test objection in every split; descriptive only',
              'descriptive_only': True}
    args.provenance.parent.mkdir(parents=True, exist_ok=True)
    args.provenance.write_text(json.dumps(report, indent=2) + '\n')
    print(args.output)

if __name__ == '__main__':
    main()
