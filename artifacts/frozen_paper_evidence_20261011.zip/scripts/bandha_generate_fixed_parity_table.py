#!/usr/bin/env python3
"""Check frozen parity arithmetic and generate its diagnostic manuscript table."""
import csv
import hashlib
import json
import math
import statistics
import subprocess
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    inputs = [ROOT/'results/csvs'/f'bandha_fixed_parity_trichotomy_{kind}.csv'
              for kind in ['detail', 'summary', 'eligibility']]
    detail, summaries, eligibility = map(read, inputs)
    for row in detail:
        assert abs(float(row['group_closure'])-float(row['fixed_closure'])-float(row['lift'])) < 1e-7
        assert float(row['fixed_validation_value_budget']) <= float(row['budget_cap'])+1e-8
        assert row['budget_protocol'] == 'validation_frozen_randomized_thinning'
    for row in eligibility:
        assert float(row['fixed_validation_value_budget']) <= float(row['budget_cap'])+1e-8
        should_clear = float(row['fixed_validation_capture_fraction'])+1e-12 >= float(row['capture_floor'])
        # Capture fractions are formatted to ten significant digits in the ledger.
        if abs(float(row['fixed_validation_capture_fraction'])-float(row['capture_floor'])) > 1e-9:
            assert int(row['eligible']) == should_clear
    lines = [r'% Generated from repaired fixed-parity detail with arithmetic checks.',
             r'\begin{tabular}{lrrr}', r'\toprule',
             r'Fixed postprocessor & Median lift & Source signs & Sign $p$ \\', r'\midrule']
    for policy, label in [('equal_group_protection', 'Protected-loss parity'),
                          ('equal_group_decline', 'Block-count parity'),
                          ('equal_group_value', 'Blocked-value parity')]:
        cells = [r for r in detail if r['fixed_policy'] == policy and r['closure_kind'] == 'raw' and float(r['capture_floor']) == .95]
        pool = defaultdict(list)
        for row in cells:
            pool[row['source']].append(float(row['lift']))
        medians = [statistics.median(values) for values in pool.values()]
        positive, negative = sum(x > .01 for x in medians), sum(x < -.01 for x in medians)
        tied = len(medians)-positive-negative
        n = positive+negative
        p = sum(math.comb(n,k) for k in range(positive,n+1))/2**n if n else 1.
        summary, = [r for r in summaries if r['fixed_policy'] == policy and r['closure_kind'] == 'raw' and float(r['capture_floor']) == .95 and float(r['materiality']) == .01]
        median = statistics.median(float(r['lift']) for r in cells)
        assert int(summary['n_cells']) == len(cells)
        assert abs(float(summary['median_lift'])-median) < 1e-8
        assert (int(summary['source_positive']), int(summary['source_negative']), int(summary['source_tied'])) == (positive,negative,tied)
        assert abs(float(summary['source_sign_p_one_sided'])-p) < 1e-10
        lines.append(f'{label} & ${median:+.4f}$ & ${positive}/{negative}/{tied}$ & ${p:.4f}$ '+chr(92)*2)
    lines.extend([r'\bottomrule',r'\end{tabular}'])
    target = ROOT/'results/bandha_fixed_parity_table.tex'
    target.write_text('\n'.join(lines)+'\n')
    report = {'status':'PASS', 'source_commit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT,text=True).strip(),
              'generator_sha256':sha(Path(__file__)), 'command':['python3','scripts/bandha_generate_fixed_parity_table.py'],
              'checked_detail_rows':len(detail), 'checked_eligibility_rows':len(eligibility),
              'input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in inputs},
              'output_sha256':{str(target.relative_to(ROOT)):sha(target)}}
    (ROOT/'results/bandha_fixed_parity_table_provenance.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS: fixed-parity arithmetic, budgets, eligibility and pooled sign checks')


if __name__ == '__main__':
    main()
