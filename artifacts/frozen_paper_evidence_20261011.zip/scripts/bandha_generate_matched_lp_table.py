#!/usr/bin/env python3
"""Generate the prespecified seven-source matched comparator table."""
import csv
import hashlib
import json
import statistics
import subprocess
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [('Australian MTPL', 20), ('Belgian MTPL', 30), ('Bondora', 10),
           ('EU health insurance', 10), ('freMPL', 90), ('Norwegian auto', 10),
           ('Swedish motorcycle', 10)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    source = ROOT/'results/csvs/bandha_matched_account_frontier_lp_detail.csv'
    verification = ROOT/'results/bandha_independent_lp_verification.json'
    checked = json.loads(verification.read_text())
    assert not checked['failures'], 'Independent LP verification must pass before table generation'
    assert checked['input_sha256'][str(source.relative_to(ROOT))] == sha(source)
    pools = defaultdict(list)
    with source.open() as stream:
        for row in csv.DictReader(stream):
            if row['source'] in dict(SOURCES) and float(row['capture_floor']) == .95 and row['currency'] == 'value':
                assert float(row['target']) == .1 and row['eligibility_status'] == 'paired_eligible'
                pools[row['source']].append(row)
    rows, tex = [], [r'% Generated from independently verified LP outcomes; held seven-source set.',
                     r'\begin{tabular}{lrrr}', r'\toprule',
                     r'Source & Group gap & LP gap & Lift \\', r'\midrule']
    for name, expected_cells in SOURCES:
        cells = pools[name]
        assert len(cells) == expected_cells, (name, len(cells), expected_cells)
        assert len({(r['source_artifact'], r['dataset'], r['seed']) for r in cells}) == len(cells)
        row = {'source': name, 'paired_cells': len(cells)}
        for field in ['group_test_gap', 'account_lp_test_gap', 'lift_vs_account_lp',
                      'group_test_capture_fraction', 'account_lp_test_capture_fraction']:
            row['median_'+field] = statistics.median(float(r[field]) for r in cells)
        rows.append(row)
        label = 'French portfolio' if name == 'freMPL' else name
        tex.append(f"{label} & {row['median_group_test_gap']:.4f} & {row['median_account_lp_test_gap']:.4f} & {row['median_lift_vs_account_lp']:+.4f} " + chr(92)*2)
    tex.extend([r'\bottomrule', r'\end{tabular}'])
    target = ROOT/'results/bandha_matched_policy_lp_table.tex'
    target.write_text('\n'.join(tex)+'\n')
    csv_path = ROOT/'results/csvs/bandha_matched_policy_lp_source_summary.csv'
    with csv_path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    manifest = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                'command': ['python3', 'scripts/bandha_generate_matched_lp_table.py'],
                'generator_sha256': sha(Path(__file__)), 'source_pool': SOURCES,
                'capture_floor': .95, 'currency': 'value', 'target': .1,
                'aggregation': 'median across held-source cohort/split cells; source counts explicit',
                'input_sha256': {str(p.relative_to(ROOT)): sha(p) for p in [source, verification]},
                'output_sha256': {str(p.relative_to(ROOT)): sha(p) for p in [target, csv_path]}}
    (ROOT/'results/bandha_matched_policy_lp_table_provenance.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('Generated seven-source LP table from verified outcomes')


if __name__ == '__main__':
    main()
