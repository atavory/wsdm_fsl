"""Generate KDD-focused weighting win figures from frozen CSVs.

The primary comparison is fixed before looking at held-out results: BCE versus
raw W-BCE.  The log-damped W-BCE mean is retained in the CSV as an audit column
but is not eligible to choose the plotted delta.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from scipy.stats import t as student_t

from make_wsdm_objection_figures import (
    GRID,
    INDIGO,
    INK,
    MUTED,
    RUST,
    VIOLET,
    WHITE,
    Canvas,
    PDF,
    _num,
    _rgb,
)


RGB = tuple[float, float, float]
WBCE_METHODS = ("W-BCE(raw)", "W-BCE(log)")
RAW_COLOR: RGB = INDIGO
LOG_COLOR: RGB = VIOLET
CI_COLOR: RGB = (0.48, 0.52, 0.54)


@dataclass(frozen=True)
class DatasetSpec:
    label: str
    source_csv: str
    row_filter: Callable[[dict[str, str]], bool]


@dataclass(frozen=True)
class MetricSpec:
    key: str
    label: str
    output_csv: str
    output_pdf: str
    title: str
    subtitle: str
    x_label: str
    datasets: tuple[DatasetSpec, ...]


@dataclass(frozen=True)
class WinPoint:
    dataset: str
    source_csv: str
    metric: str
    n_splits: int
    bce_mean: float
    wbce_raw_mean: float
    wbce_log_mean: float
    selected_method: str
    selected_mean: float
    delta_mean: float
    delta_ci95: float


def accept_all(_: dict[str, str]) -> bool:
    return True


def dataset_equals(name: str) -> Callable[[dict[str, str]], bool]:
    return lambda row: row.get("dataset") == name


def fre_mtpl2_objective_1(row: dict[str, str]) -> bool:
    return row.get("dataset") == "freMTPL2" and row.get("objective") == "1"


GINI_DATASETS: tuple[DatasetSpec, ...] = (
    DatasetSpec("KuaiRand", "results/csvs/wsdm_kuairand.csv", accept_all),
    DatasetSpec(
        "Australian MTPL",
        "results/csvs/icaif_australian_mtpl_nested.csv",
        accept_all,
    ),
    DatasetSpec("freMTPL2", "results/csvs/bandha_fremtpl2_train_only_scores.csv", fre_mtpl2_objective_1),
    DatasetSpec("Belgian MTPL", "results/csvs/icaif_belgian_mtpl.csv", accept_all),
    DatasetSpec("Lending Club", "results/csvs/icaif_lending_club.csv", accept_all),
    DatasetSpec("Prosper", "results/csvs/icaif_prosper.csv", accept_all),
    DatasetSpec("SBA 7(a)", "results/csvs/icaif_sba.csv", accept_all),
    DatasetSpec("Bondora", "results/csvs/icaif_bondora.csv", accept_all),
    DatasetSpec("Fannie Mae", "results/csvs/icaif_fannie_harp_nested.csv", accept_all),
    DatasetSpec("Freddie Mac", "results/csvs/icaif_freddie_crt_nested.csv", accept_all),
)


CAPTURE_DATASETS: tuple[DatasetSpec, ...] = (
    DatasetSpec("KuaiRand", "results/csvs/wsdm_kuairand.csv", accept_all),
    DatasetSpec(
        "Australian MTPL",
        "results/csvs/icaif_australian_mtpl_nested.csv",
        accept_all,
    ),
    DatasetSpec("freMTPL2", "results/csvs/bandha_fremtpl2_train_only_scores.csv", fre_mtpl2_objective_1),
    DatasetSpec("Belgian MTPL", "results/csvs/icaif_belgian_mtpl.csv", accept_all),
    DatasetSpec("Lending Club", "results/csvs/icaif_lending_club.csv", accept_all),
    DatasetSpec("Prosper", "results/csvs/icaif_prosper.csv", accept_all),
    DatasetSpec("SBA 7(a)", "results/csvs/icaif_sba.csv", accept_all),
    DatasetSpec("Bondora", "results/csvs/icaif_bondora.csv", accept_all),
    DatasetSpec("Fannie Mae", "results/csvs/icaif_fannie_harp_nested.csv", accept_all),
    DatasetSpec("Freddie Mac", "results/csvs/icaif_freddie_crt_nested.csv", accept_all),
)


METRICS: tuple[MetricSpec, ...] = (
    MetricSpec(
        key="gini",
        label="Yield Gini",
        output_csv="results/csvs/kdd_weighting_gini_wins.csv",
        output_pdf="results/figures/kdd_weighting_gini_wins.pdf",
        title="Raw W-BCE versus BCE: yield Gini",
        subtitle="",
        x_label="W-BCE minus BCE yield-Gini points",
        datasets=GINI_DATASETS,
    ),
    MetricSpec(
        key="capture",
        label="Operating-point capture",
        output_csv="results/csvs/kdd_weighting_capture_wins.csv",
        output_pdf="results/figures/kdd_weighting_capture_wins.pdf",
        title="Raw W-BCE versus BCE: loss capture",
        subtitle="",
        x_label="W-BCE minus BCE capture at the value budget",
        datasets=CAPTURE_DATASETS,
    ),
)


CAPTURE_METRIC_BY_DATASET: dict[str, str] = {
    "KuaiRand": "prospective_harm_capture",
    "freMTPL2": "capture_at_10pct_value",
    "Australian MTPL": "prospective_capture",
    "Fannie Mae": "prospective_capture",
    "Freddie Mac": "prospective_capture",
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", type=Path, default=root)
    return parser.parse_args()


def resolve(base_dir: Path, path: str) -> Path:
    return base_dir / path


def to_float(value: str) -> float:
    return float(value) if value != "" else float("nan")


def mean(values: list[float]) -> float:
    return statistics.fmean(values)


def ci95(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    return float(student_t.ppf(.975, len(values)-1)) * statistics.stdev(values) / math.sqrt(len(values))


def read_seed_values(
    base_dir: Path,
    spec: DatasetSpec,
    metric_key: str,
) -> dict[str, dict[str, float]]:
    path = resolve(base_dir, spec.source_csv)
    metric = metric_key
    if metric_key == "capture":
        metric = CAPTURE_METRIC_BY_DATASET.get(spec.label, "capture_at_10pct_revenue")
    by_method: dict[str, dict[str, float]] = {}
    with path.open(newline="") as handle:
        for row in csv.DictReader(handle):
            if not spec.row_filter(row):
                continue
            method = row.get("method", "")
            if method not in ("BCE", *WBCE_METHODS):
                continue
            if metric not in row:
                raise ValueError(f"{path} has no metric column {metric}")
            seed = row.get("seed")
            if seed is None:
                raise ValueError(f"{path} has no seed column")
            if seed in by_method.setdefault(method, {}):
                raise ValueError(f"Duplicate method/seed in {path}: {method}, {seed}")
            by_method[method][seed] = to_float(row[metric])
    missing = [method for method in ("BCE", *WBCE_METHODS) if method not in by_method]
    if missing:
        raise ValueError(f"{spec.label} missing methods: {', '.join(missing)}")
    return by_method


def make_point(base_dir: Path, metric: MetricSpec, spec: DatasetSpec) -> WinPoint:
    values = read_seed_values(base_dir, spec, metric.key)
    common_seeds = sorted(values['BCE'])
    if not common_seeds or any(set(values[m]) != set(common_seeds) for m in WBCE_METHODS):
        raise ValueError(f"{spec.label} has missing or unpaired BCE/W-BCE seeds")

    means = {
        method: mean([values[method][seed] for seed in common_seeds])
        for method in ("BCE", *WBCE_METHODS)
    }
    selected_method = "W-BCE(raw)"
    deltas = [
        values[selected_method][seed] - values["BCE"][seed]
        for seed in common_seeds
    ]
    return WinPoint(
        dataset=spec.label,
        source_csv=spec.source_csv,
        metric=metric.label,
        n_splits=len(common_seeds),
        bce_mean=means["BCE"],
        wbce_raw_mean=means["W-BCE(raw)"],
        wbce_log_mean=means["W-BCE(log)"],
        selected_method=selected_method,
        selected_mean=means[selected_method],
        delta_mean=mean(deltas),
        delta_ci95=ci95(deltas),
    )


def format_float(value: float) -> str:
    return f"{value:.10g}"


def write_points(points: list[WinPoint], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "dataset",
        "source_csv",
        "metric",
        "n_splits",
        "bce_mean",
        "wbce_raw_mean",
        "wbce_log_mean",
        "selected_method",
        "selected_mean",
        "delta_mean",
        "delta_ci95",
    ]
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for point in points:
            writer.writerow(
                {
                    "dataset": point.dataset,
                    "source_csv": point.source_csv,
                    "metric": point.metric,
                    "n_splits": point.n_splits,
                    "bce_mean": format_float(point.bce_mean),
                    "wbce_raw_mean": format_float(point.wbce_raw_mean),
                    "wbce_log_mean": format_float(point.wbce_log_mean),
                    "selected_method": point.selected_method,
                    "selected_mean": format_float(point.selected_mean),
                    "delta_mean": format_float(point.delta_mean),
                    "delta_ci95": format_float(point.delta_ci95),
                }
            )


def xmap(value: float, left: float, width: float, xmin: float, xmax: float) -> float:
    return left + width * (value - xmin) / (xmax - xmin)


def draw_bar_figure(points: list[WinPoint], metric: MetricSpec, output: Path) -> None:
    sorted_points = sorted(points, key=lambda point: point.delta_mean, reverse=True)
    max_high = max(point.delta_mean + point.delta_ci95 for point in sorted_points)
    min_low = min(0.0, min(point.delta_mean - point.delta_ci95 for point in sorted_points))
    xmin = min(-0.02, math.floor(min_low * 20) / 20)
    xmax = max(0.05, math.ceil(max_high * 20) / 20)

    canvas = Canvas(272, 188)
    left = 82
    right = 254
    bottom = 31
    top = 151
    width = right - left
    row_gap = (top - bottom) / (len(sorted_points) - 1)

    canvas.text(10, 173, metric.title, size=9.5, font="F2")
    wins = sum(point.delta_mean > 0 for point in points)
    canvas.text(10, 161, f"Positive mean differences on {wins} of {len(points)} datasets.", size=6.4, color=MUTED)
    canvas.rect(left, bottom - 4, width, top - bottom + 8, fill=WHITE, stroke=GRID, line_width=0.7)

    tick_step = 0.05
    tick = math.ceil(xmin / tick_step) * tick_step
    while tick <= xmax + 1e-12:
        x = xmap(tick, left, width, xmin, xmax)
        color = INK if abs(tick) < 1e-12 else GRID
        line_width = 0.45 if abs(tick) < 1e-12 else 0.3
        canvas.line([(x, bottom - 4), (x, top + 4)], stroke=color, line_width=line_width)
        canvas.text(x, bottom - 14, f"{tick:.2f}", size=5.2, color=MUTED, align="center")
        tick += tick_step

    zero = xmap(0.0, left, width, xmin, xmax)
    for index, point in enumerate(sorted_points):
        y = top - index * row_gap
        canvas.line([(left, y), (right, y)], stroke=GRID, line_width=0.18)
        label = point.dataset
        if metric.key == 'capture':
            label += ' [V]' if point.dataset in ('KuaiRand', 'Australian MTPL', 'Fannie Mae', 'Freddie Mac') else ' [T]'
        canvas.text(left - 6, y - 2.0, label, size=5.8, color=INK, align="right")
        x_value = xmap(point.delta_mean, left, width, xmin, xmax)
        x_low = xmap(point.delta_mean - point.delta_ci95, left, width, xmin, xmax)
        x_high = xmap(point.delta_mean + point.delta_ci95, left, width, xmin, xmax)
        color = RAW_COLOR
        canvas.rect(
            min(zero, x_value),
            y - 2.5,
            abs(x_value - zero),
            5.0,
            fill=color,
            stroke=None,
        )
        canvas.line([(x_low, y), (x_high, y)], stroke=CI_COLOR, line_width=0.35)
        canvas.line([(x_low, y - 1.6), (x_low, y + 1.6)], stroke=CI_COLOR, line_width=0.35)
        canvas.line([(x_high, y - 1.6), (x_high, y + 1.6)], stroke=CI_COLOR, line_width=0.35)
        canvas.circle(x_value, y, 2.3, fill=color, stroke=WHITE, line_width=0.35)
        label = f"{point.delta_mean:+.3f}"
        if x_value > right - 38:
            canvas.text(right - 3, y - 2.0, label, size=5.0, color=INK, align="right")
        else:
            canvas.text(x_value + 3, y - 2.0, label, size=5.0, color=INK)

    canvas.text((left + right) / 2, 5, metric.x_label, size=6.6, color=INK, align="center")

    pdf = PDF()
    pdf.add_page(canvas)
    output.parent.mkdir(parents=True, exist_ok=True)
    pdf.write(output)


def main() -> None:
    args = parse_args()
    base_dir = args.base_dir.resolve()
    hashes, outputs = {}, {}
    for metric in METRICS:
        points = [
            make_point(base_dir, metric, spec)
            for spec in metric.datasets
        ]
        csv_path = resolve(base_dir, metric.output_csv)
        pdf_path = resolve(base_dir, metric.output_pdf)
        write_points(points, csv_path)
        draw_bar_figure(points, metric, pdf_path)
        for spec in metric.datasets:
            path = resolve(base_dir, spec.source_csv)
            hashes[spec.source_csv] = hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (csv_path, pdf_path):
            outputs[str(path.relative_to(base_dir))] = hashlib.sha256(path.read_bytes()).hexdigest()
        wins = sum(1 for point in points if point.delta_mean > 0)
        print(f"{metric.label}: {wins}/{len(points)} positive deltas")
        print(f"wrote {csv_path}")
        print(f"wrote {pdf_path}")
    provenance = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=base_dir, text=True).strip(),
                  'command': ['python3', 'viz/make_kdd_weighting_win_figures.py'],
                  'generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'canvas_sha256': hashlib.sha256((base_dir/'viz/make_wsdm_objection_figures.py').read_bytes()).hexdigest(),
                  'comparison': 'fixed raw W-BCE minus BCE, paired complete seed sets',
                  'confidence_interval': '95% split-paired Student t, df=n_splits-1',
                  'capture_labels': {'V': 'validation-frozen threshold', 'T': 'test-curve interpolation'},
                  'input_sha256': hashes, 'output_sha256': outputs}
    (base_dir/'results/bandha_score_figure_provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')


if __name__ == "__main__":
    main()
