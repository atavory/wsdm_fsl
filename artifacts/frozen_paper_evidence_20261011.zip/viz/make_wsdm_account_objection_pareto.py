"""Generate the WSDM account-objection Pareto figure.

The script writes a generated points CSV under results/csvs/ and then draws the
paper PDF from that CSV.  It uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from make_wsdm_objection_figures import (  # noqa: E402
    AMBER,
    COPPER,
    GRID,
    INDIGO,
    INK,
    MUTED,
    PDF,
    RUST,
    VALUE_BLOCK,
    WHITE,
    Canvas,
    _num,
    _rgb,
)


RGB = tuple[float, float, float]
TARGET = 0.10
T_CRIT_95: dict[int, float] = {
    2: 12.706,
    3: 4.303,
    4: 3.182,
    5: 2.776,
    6: 2.571,
    7: 2.447,
    8: 2.365,
    9: 2.306,
    10: 2.262,
}

COHORTS: tuple[tuple[str, str, RGB, str], ...] = (
    ("australian_mtpl_group_aware", "Australian aware", INDIGO, "circle"),
    ("australian_mtpl_group_blind", "Australian blind", COPPER, "square"),
    ("belgian_mtpl_group_aware", "Belgian aware", VALUE_BLOCK, "circle"),
    ("belgian_mtpl_group_blind", "Belgian blind", RUST, "square"),
    ("kuairand_group_aware", "KuaiRand aware", AMBER, "circle"),
    ("kuairand_group_blind", "KuaiRand blind", INDIGO, "square"),
    ("australian_stress_moderate", "Stress moderate", VALUE_BLOCK, "triangle"),
    ("australian_stress_strong", "Stress strong", RUST, "triangle"),
    ("australian_stress_extreme", "Stress extreme", AMBER, "triangle"),
)

UNITS: tuple[tuple[str, str], ...] = (
    ("count", "Count"),
    ("value", "Value"),
    ("loss", "Loss"),
)

SWEEP_DOT: RGB = (0.76, 0.79, 0.86)
ERROR_BAR: RGB = (0.52, 0.56, 0.58)
FRONTIER_COLOR: RGB = VALUE_BLOCK
WBCE_COLOR: RGB = INDIGO
BCE_COLOR: RGB = RUST
X_LOW = 0.0
X_HIGH = 1.04
Y_LOW = -0.20
Y_HIGH = 1.03


@dataclass(frozen=True)
class AccountPoint:
    dataset: str
    cohort: str
    unit: str
    lambda_harm: float
    lambda_net_harm: float
    capture: float
    capture_ci95: float
    closed: float
    closed_ci95: float
    objection: float
    objection_ci95: float


@dataclass(frozen=True)
class MethodPoint:
    dataset: str
    cohort: str
    unit: str
    method: str
    capture: float
    capture_ci95: float
    closed: float
    closed_ci95: float
    objection: float
    objection_ci95: float


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", type=Path, default=root)
    parser.add_argument(
        "--account-path-csv",
        nargs="+",
        type=Path,
        default=[
            Path("results/csvs/wsdm_w16_objection_penalty_path_dense.csv"),
            Path("results/csvs/wsdm_w16_objection_penalty_path_belgian_dense.csv"),
            Path("results/csvs/wsdm_w16_objection_penalty_path_kuairand_300k.csv"),
        ],
    )
    parser.add_argument("--unit", choices=[unit for unit, _ in UNITS], default="count")
    parser.add_argument(
        "--points-csv",
        type=Path,
        default=Path("results/csvs/wsdm_account_objection_pareto_points.csv"),
    )
    parser.add_argument(
        "--method-points-csv",
        type=Path,
        default=Path("results/csvs/wsdm_account_objection_method_points.csv"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/figures/wsdm_account_objection_pareto.pdf"),
    )
    return parser.parse_args()


def resolve_path(base_dir: Path, path: Path) -> Path:
    return path if path.is_absolute() else base_dir / path


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def to_float(value: str | None) -> float:
    if value is None or value == "":
        return float("nan")
    return float(value)


def mean(values: list[float]) -> float:
    finite = [value for value in values if math.isfinite(value)]
    return statistics.fmean(finite) if finite else float("nan")


def ci95(values: list[float]) -> float:
    finite = [value for value in values if math.isfinite(value)]
    n = len(finite)
    if n <= 1:
        return 0.0 if finite else float("nan")
    t_value = T_CRIT_95.get(n, 1.96)
    return t_value * statistics.stdev(finite) / math.sqrt(n)


def same_target(value: str) -> bool:
    return math.isclose(float(value), TARGET, rel_tol=0.0, abs_tol=1e-12)


def baseline_rows(rows: list[dict[str, str]], dataset: str) -> dict[str, dict[str, str]]:
    baselines: dict[str, dict[str, str]] = {}
    for row in rows:
        if row["dataset"] != dataset:
            continue
        if row["slice"] != "all" or row["group"] != "ALL" or not same_target(row["target"]):
            continue
        if (
            to_float(row["lambda_wbce_ratio"]) == 0.0
            and to_float(row["lambda_harm"]) == 0.0
            and to_float(row["lambda_net_harm"]) == 0.0
        ):
            baselines[row["seed"]] = row
    return baselines


def summarize_account_values(
    dataset: str,
    cohort: str,
    unit: str,
    lambda_harm: float,
    lambda_net_harm: float,
    values: list[tuple[float, float, float]],
) -> AccountPoint:
    captures = [capture for capture, _, _ in values]
    closed = [closed for _, closed, _ in values]
    objections = [objection for _, _, objection in values]
    return AccountPoint(
        dataset=dataset,
        cohort=cohort,
        unit=unit,
        lambda_harm=lambda_harm,
        lambda_net_harm=lambda_net_harm,
        capture=mean(captures),
        capture_ci95=ci95(captures),
        closed=mean(closed),
        closed_ci95=ci95(closed),
        objection=mean(objections),
        objection_ci95=ci95(objections),
    )


def account_points(rows: list[dict[str, str]]) -> list[AccountPoint]:
    result: list[AccountPoint] = []
    labels = {dataset: label for dataset, label, _, _ in COHORTS}
    for dataset, cohort, _, _ in COHORTS:
        baselines = baseline_rows(rows, dataset)
        by_key: dict[tuple[str, float, float], list[tuple[float, float, float]]] = defaultdict(list)
        for row in rows:
            if row["dataset"] != dataset:
                continue
            if row["slice"] != "all" or row["group"] != "ALL" or not same_target(row["target"]):
                continue
            if to_float(row["lambda_wbce_ratio"]) != 0.0:
                continue
            baseline = baselines.get(row["seed"])
            if baseline is None:
                continue
            base_capture = to_float(baseline["test_capture"])
            if base_capture <= 0:
                continue
            lambda_harm = to_float(row["lambda_harm"])
            lambda_net_harm = to_float(row["lambda_net_harm"])
            capture = to_float(row["test_capture"]) / base_capture
            for unit, _ in UNITS:
                base_objection = to_float(baseline[f"test_penalty_any_{unit}"])
                if base_objection <= 0:
                    continue
                objection = to_float(row[f"test_penalty_any_{unit}"])
                closed = 1.0 - objection / base_objection
                by_key[(unit, lambda_harm, lambda_net_harm)].append(
                    (capture, closed, objection)
                )
        for (unit, lambda_harm, lambda_net_harm), values in sorted(by_key.items()):
            result.append(
                summarize_account_values(
                    dataset,
                    labels[dataset],
                    unit,
                    lambda_harm,
                    lambda_net_harm,
                    values,
                )
            )
    return result


def account_frontier(points: list[AccountPoint]) -> list[AccountPoint]:
    unique: dict[float, AccountPoint] = {}
    for point in points:
        key = round(point.capture, 5)
        current = unique.get(key)
        if current is None or point.closed > current.closed:
            unique[key] = point
    frontier: list[AccountPoint] = []
    best_closed = -float("inf")
    for point in sorted(unique.values(), key=lambda item: item.capture, reverse=True):
        if point.closed > best_closed + 1e-5:
            frontier.append(point)
            best_closed = point.closed
    return list(reversed(frontier))


def write_points_csv(account: list[AccountPoint], points_csv: Path) -> None:
    rows: list[dict[str, str]] = []
    by_panel: dict[tuple[str, str], list[AccountPoint]] = defaultdict(list)
    for point in account:
        by_panel[(point.unit, point.cohort)].append(point)
        rows.append(account_row(point, "account_sweep", len(rows)))
    for unit, _ in UNITS:
        for _, cohort, _, _ in COHORTS:
            for order, point in enumerate(account_frontier(by_panel[(unit, cohort)])):
                rows.append(account_row(point, "account_frontier", order))
    points_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "figure_part",
        "panel_order",
        "panel",
        "dataset",
        "cohort",
        "unit",
        "series",
        "point_order",
        "lambda_harm",
        "lambda_net_harm",
        "capture_fraction",
        "capture_ci95",
        "objection_closed",
        "objection_closed_ci95",
        "objection_level",
        "objection_level_ci95",
    ]
    with points_csv.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def account_row(point: AccountPoint, series: str, order: int) -> dict[str, str]:
    return {
        "figure_part": "account",
        "panel_order": str(1 + [unit for unit, _ in UNITS].index(point.unit)),
        "panel": dict(UNITS)[point.unit],
        "dataset": point.dataset,
        "cohort": point.cohort,
        "unit": point.unit,
        "series": series,
        "point_order": str(order),
        "lambda_harm": f"{point.lambda_harm:.8f}",
        "lambda_net_harm": f"{point.lambda_net_harm:.8f}",
        "capture_fraction": f"{point.capture:.8f}",
        "capture_ci95": f"{point.capture_ci95:.8f}",
        "objection_closed": f"{point.closed:.8f}",
        "objection_closed_ci95": f"{point.closed_ci95:.8f}",
        "objection_level": f"{point.objection:.8f}",
        "objection_level_ci95": f"{point.objection_ci95:.8f}",
    }


def read_generated_points(path: Path) -> dict[tuple[str, str, str], list[AccountPoint]]:
    account: dict[tuple[str, str, str], list[AccountPoint]] = defaultdict(list)
    for row in read_rows(path):
        point = AccountPoint(
            dataset=row["dataset"],
            cohort=row["cohort"],
            unit=row["unit"],
            lambda_harm=to_float(row["lambda_harm"]),
            lambda_net_harm=to_float(row["lambda_net_harm"]),
            capture=to_float(row["capture_fraction"]),
            capture_ci95=to_float(row["capture_ci95"]),
            closed=to_float(row["objection_closed"]),
            closed_ci95=to_float(row["objection_closed_ci95"]),
            objection=to_float(row["objection_level"]),
            objection_ci95=to_float(row["objection_level_ci95"]),
        )
        account[(row["series"], row["unit"], row["cohort"])].append(point)
    for points in account.values():
        points.sort(key=lambda point: point.capture)
    return account


def read_method_points(path: Path) -> dict[tuple[str, str, str], list[MethodPoint]]:
    methods: dict[tuple[str, str, str], list[MethodPoint]] = defaultdict(list)
    if not path.exists():
        return methods
    for row in read_rows(path):
        point = MethodPoint(
            dataset=row["dataset"],
            cohort=row["cohort"],
            unit=row["unit"],
            method=row["method"],
            capture=to_float(row["capture_fraction"]),
            capture_ci95=to_float(row["capture_ci95"]),
            closed=to_float(row["objection_closed"]),
            closed_ci95=to_float(row["objection_closed_ci95"]),
            objection=to_float(row["objection_level"]),
            objection_ci95=to_float(row["objection_level_ci95"]),
        )
        methods[(row["method"], row["unit"], row["cohort"])].append(point)
    return methods


def xmap(value: float, left: float, width: float, low: float, high: float) -> float:
    return left + width * (value - low) / (high - low)


def ymap(value: float, bottom: float, height: float, low: float, high: float) -> float:
    return bottom + height * (value - low) / (high - low)


def tex_num(value: float) -> str:
    text = f"{value:.2f}"
    return text[1:] if text.startswith("0") else text


def draw_poly(canvas: Canvas, points: list[tuple[float, float]], fill: RGB, stroke: RGB) -> None:
    canvas.commands.append("q")
    canvas.commands.append(f"{_rgb(fill)} rg")
    canvas.commands.append(f"{_rgb(stroke)} RG")
    canvas.commands.append("0.45 w")
    x0, y0 = points[0]
    canvas.commands.append(f"{_num(x0)} {_num(y0)} m")
    for x, y in points[1:]:
        canvas.commands.append(f"{_num(x)} {_num(y)} l")
    canvas.commands.append("h B")
    canvas.commands.append("Q")


def draw_marker(canvas: Canvas, x: float, y: float, color: RGB, shape: str = "circle") -> None:
    size = 3.5
    if shape == "circle":
        canvas.circle(x, y, size * 0.75, fill=color, stroke=WHITE, line_width=0.45)
    elif shape == "square":
        canvas.rect(x - size / 2, y - size / 2, size, size, fill=color, stroke=WHITE, line_width=0.45)
    elif shape == "triangle":
        draw_poly(
            canvas,
            [(x, y + size * 0.65), (x - size * 0.7, y - size * 0.55), (x + size * 0.7, y - size * 0.55)],
            color,
            WHITE,
        )
    elif shape == "diamond":
        draw_poly(
            canvas,
            [
                (x, y + size * 0.72),
                (x - size * 0.72, y),
                (x, y - size * 0.72),
                (x + size * 0.72, y),
            ],
            color,
            WHITE,
        )
    else:
        raise ValueError(shape)


def draw_account_error(
    canvas: Canvas,
    point: AccountPoint,
    left: float,
    bottom: float,
    width: float,
    height: float,
) -> None:
    x = xmap(point.capture, left, width, X_LOW, X_HIGH)
    y = ymap(point.closed, bottom, height, Y_LOW, Y_HIGH)
    x_low = xmap(max(X_LOW, point.capture - point.capture_ci95), left, width, X_LOW, X_HIGH)
    x_high = xmap(min(X_HIGH, point.capture + point.capture_ci95), left, width, X_LOW, X_HIGH)
    y_low = ymap(max(Y_LOW, point.closed - point.closed_ci95), bottom, height, Y_LOW, Y_HIGH)
    y_high = ymap(min(Y_HIGH, point.closed + point.closed_ci95), bottom, height, Y_LOW, Y_HIGH)
    if x_high - x_low > 0.7:
        canvas.line([(x_low, y), (x_high, y)], stroke=ERROR_BAR, line_width=0.35)
        canvas.line([(x_low, y - 1.7), (x_low, y + 1.7)], stroke=ERROR_BAR, line_width=0.35)
        canvas.line([(x_high, y - 1.7), (x_high, y + 1.7)], stroke=ERROR_BAR, line_width=0.35)
    if y_high - y_low > 0.7:
        canvas.line([(x, y_low), (x, y_high)], stroke=ERROR_BAR, line_width=0.35)
        canvas.line([(x - 1.7, y_low), (x + 1.7, y_low)], stroke=ERROR_BAR, line_width=0.35)
        canvas.line([(x - 1.7, y_high), (x + 1.7, y_high)], stroke=ERROR_BAR, line_width=0.35)


def draw_account_panel(
    canvas: Canvas,
    account: dict[tuple[str, str, str], list[AccountPoint]],
    methods: dict[tuple[str, str, str], list[MethodPoint]],
    unit: str,
    cohort: str,
    label: str,
    left: float,
    bottom: float,
    width: float,
    height: float,
) -> None:
    canvas.text(left, bottom + height + 7, label, size=7.8, font="F2")
    canvas.rect(left, bottom, width, height, fill=WHITE, stroke=GRID, line_width=0.75)
    for tick in (0.0, 0.25, 0.50, 0.75, 1.0):
        x = xmap(tick, left, width, X_LOW, X_HIGH)
        y = ymap(tick, bottom, height, Y_LOW, Y_HIGH)
        canvas.line([(x, bottom), (x, bottom + height)], stroke=GRID, line_width=0.3)
        canvas.line([(left, y), (left + width, y)], stroke=GRID, line_width=0.3)
        canvas.text(x, bottom - 8, tex_num(tick), size=5.2, color=MUTED, align="center")
        canvas.text(left - 3, y - 1.8, tex_num(tick), size=5.2, color=MUTED, align="right")
    y_zero = ymap(0.0, bottom, height, Y_LOW, Y_HIGH)
    canvas.line([(left, y_zero), (left + width, y_zero)], stroke=INK, line_width=0.45)
    sweep = account[("account_sweep", unit, cohort)]
    frontier = account[("account_frontier", unit, cohort)]
    if not sweep or not frontier:
        raise RuntimeError(f"empty account Pareto panel for {cohort} / {unit}")
    for point in sweep:
        x = xmap(max(X_LOW, min(X_HIGH, point.capture)), left, width, X_LOW, X_HIGH)
        y = ymap(max(Y_LOW, min(Y_HIGH, point.closed)), bottom, height, Y_LOW, Y_HIGH)
        canvas.circle(x, y, 0.62, fill=SWEEP_DOT)
    if len(frontier) >= 2:
        step = max(1, len(frontier) // 4)
        for point in frontier[::step]:
            draw_account_error(canvas, point, left, bottom, width, height)
        curve = [
            (
                xmap(max(X_LOW, min(X_HIGH, point.capture)), left, width, X_LOW, X_HIGH),
                ymap(max(Y_LOW, min(Y_HIGH, point.closed)), bottom, height, Y_LOW, Y_HIGH),
            )
            for point in frontier
        ]
        canvas.line(curve, stroke=FRONTIER_COLOR, line_width=1.25)
        for point in frontier[::step]:
            draw_marker(
                canvas,
                xmap(max(X_LOW, min(X_HIGH, point.capture)), left, width, X_LOW, X_HIGH),
                ymap(max(Y_LOW, min(Y_HIGH, point.closed)), bottom, height, Y_LOW, Y_HIGH),
                FRONTIER_COLOR,
                shape="circle",
            )
        last = max(frontier, key=lambda point: (point.closed, point.capture))
        canvas.text(
            left + width - 4,
            bottom + 5,
            f"max {int(round(max(0.0, min(1.0, last.closed)) * 100))}%",
            size=5.8,
            color=FRONTIER_COLOR,
            font="F2",
            align="right",
        )
    for method, color, shape in (
        ("W-BCE", WBCE_COLOR, "diamond"),
        ("BCE", BCE_COLOR, "square"),
    ):
        method_points = methods.get((method, unit, cohort), [])
        if not method_points:
            continue
        point = method_points[0]
        draw_account_error(canvas, point, left, bottom, width, height)
        x = xmap(max(X_LOW, min(X_HIGH, point.capture)), left, width, X_LOW, X_HIGH)
        y = ymap(max(Y_LOW, min(Y_HIGH, point.closed)), bottom, height, Y_LOW, Y_HIGH)
        draw_marker(canvas, x, y, color, shape=shape)


def legend(canvas: Canvas, y: float) -> None:
    text_y = y - 2.2
    canvas.line([(330, y), (350, y)], stroke=FRONTIER_COLOR, line_width=1.25)
    draw_marker(canvas, 340, y, FRONTIER_COLOR, shape="circle")
    canvas.text(357, text_y, "frontier", size=6.3, color=INK)
    draw_marker(canvas, 409, y, WBCE_COLOR, shape="diamond")
    canvas.text(417, text_y, "W-BCE", size=6.3, color=INK)
    draw_marker(canvas, 467, y, BCE_COLOR, shape="square")
    canvas.text(475, text_y, "BCE", size=6.3, color=INK)


def build_figure(points_csv: Path, method_points_csv: Path, output: Path) -> None:
    account = read_generated_points(points_csv)
    methods = read_method_points(method_points_csv)
    canvas = Canvas(540, 250)
    canvas.text(18, 234, "Account-level objection Pareto frontiers", size=10.5, font="F2")
    canvas.text(
        18,
        219,
        "Each panel sweeps harm and net-harm objection prices at the 10% value budget.",
        size=7.0,
        color=MUTED,
    )
    legend(canvas, 234.0)
    panel_w = 88
    panel_h = 70
    top_lefts = (22, 124, 226, 328, 430)
    bottom_lefts = (73, 175, 277, 379)
    bottoms = (128, 35)
    for index, (_, label, _, _) in enumerate(COHORTS):
        if index < 5:
            left = top_lefts[index]
            bottom = bottoms[0]
        else:
            left = bottom_lefts[index - 5]
            bottom = bottoms[1]
        draw_account_panel(
            canvas,
            account,
            methods,
            "count",
            label,
            label,
            left,
            bottom,
            panel_w,
            panel_h,
        )
    canvas.text(270, 13, "retained loss capture", size=7.2, color=INK, align="center")
    canvas.rotated_text(8, 118, "objection share removed", angle_degrees=90, size=7.2, color=INK, align="center")
    pdf = PDF()
    pdf.add_page(canvas)
    output.parent.mkdir(parents=True, exist_ok=True)
    pdf.write(output)


def main() -> None:
    args = parse_args()
    base_dir = args.base_dir
    account_paths = [resolve_path(base_dir, path) for path in args.account_path_csv]
    points_csv = resolve_path(base_dir, args.points_csv)
    method_points_csv = resolve_path(base_dir, args.method_points_csv)
    output = resolve_path(base_dir, args.output)
    rows: list[dict[str, str]] = []
    for path in account_paths:
        rows.extend(read_rows(path))
    accounts = [point for point in account_points(rows) if point.unit == args.unit]
    write_points_csv(accounts, points_csv)
    build_figure(points_csv, method_points_csv, output)
    print(f"wrote {points_csv}")
    print(f"wrote {output}")


if __name__ == "__main__":
    main()
