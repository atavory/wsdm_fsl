"""Plot the common-reference Figure 3 bank and its measured Pareto extension.

Shaded regions are dominated by evaluated policies. Their stair-step edges
do not assert attainability of untested randomized mixtures.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
from dataclasses import dataclass
from pathlib import Path

from make_wsdm_account_objection_pareto import draw_marker, draw_poly
from make_wsdm_objection_figures import Canvas, PDF, INK, MUTED, GRID, WHITE


GREEN = (0.15, 0.49, 0.36)
EXTENSION = (0.88, 0.95, 0.90)
BASE_REGION = (0.93, 0.93, 0.95)
DOT = (0.67, 0.74, 0.72)
METHODS = {
    "fitted_wbce": ("W-BCE", (0.25, 0.31, 0.60), "diamond"),
    "bce": ("BCE", (0.72, 0.35, 0.25), "square"),
    "plugin_ratio": ("Plug-in", (0.50, 0.35, 0.60), "triangle"),
}
PANELS = (
    ("Australian MTPL", "australian_mtpl_group_blind"),
    ("Belgian MTPL", "belgian_mtpl_group_blind"),
    ("KuaiRand", "kuairand_group_blind"),
)


@dataclass(frozen=True)
class Point:
    family: str
    rule: str
    x: float
    y: float
    x_ci: float = 0.0
    y_ci: float = 0.0


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def point(row: dict[str, str]) -> Point:
    result = Point(
        row["policy_family"], row.get("price_rule_id", row.get("policy_id", "")),
        float(row["capture_fraction"]), float(row["objection_closed"]),
        float(row.get("capture_ci95", "0")),
        float(row.get("objection_closed_ci95", "0")),
    )
    if not all(math.isfinite(v) for v in (result.x, result.y, result.x_ci, result.y_ci)):
        raise ValueError(f"Nonfinite plot coordinate: {row}")
    if result.x_ci < 0 or result.y_ci < 0:
        raise ValueError("Negative interval half-width")
    return result


def dominates(a: Point, b: Point, tol: float = 1e-9) -> bool:
    return (a.x >= b.x - tol and a.y >= b.y - tol
            and (a.x > b.x + tol or a.y > b.y + tol))


def pareto(points: list[Point]) -> list[Point]:
    return [p for p in points if not any(dominates(q, p) for q in points)]


def boundary(points: list[Point]) -> list[Point]:
    unique: dict[float, Point] = {}
    for p in pareto(points):
        if p.x not in unique or p.y > unique[p.x].y:
            unique[p.x] = p
    return sorted(unique.values(), key=lambda p: p.x)


def ticks(low: float, high: float) -> list[float]:
    span = high - low
    raw = span / 4
    power = 10 ** math.floor(math.log10(raw))
    step = next(v * power for v in (1, 2, 2.5, 5, 10) if v * power >= raw)
    start = math.ceil(low / step - 1e-9) * step
    return [start + i * step for i in range(10) if start + i * step <= high + 1e-9]


def region(canvas: Canvas, points: list[Point], xm, ym, low_x: float,
           low_y: float, color) -> None:
    edge = boundary(points)
    if not edge:
        return
    coords = [(xm(low_x), ym(low_y)), (xm(low_x), ym(edge[0].y)),
              (xm(edge[0].x), ym(edge[0].y))]
    for previous, current in zip(edge, edge[1:]):
        coords.extend([(xm(previous.x), ym(current.y)), (xm(current.x), ym(current.y))])
    coords.append((xm(edge[-1].x), ym(low_y)))
    draw_poly(canvas, coords, color, color)


def error_bars(canvas: Canvas, p: Point, xm, ym) -> None:
    if p.x_ci:
        canvas.line([(xm(p.x - p.x_ci), ym(p.y)), (xm(p.x + p.x_ci), ym(p.y))],
                    stroke=MUTED, line_width=0.4)
    if p.y_ci:
        canvas.line([(xm(p.x), ym(p.y - p.y_ci)), (xm(p.x), ym(p.y + p.y_ci))],
                    stroke=MUTED, line_width=0.4)


def draw_panel(canvas: Canvas, title: str, rows: list[dict[str, str]],
               method_rows: list[dict[str, str]], left: float,
               show_y: bool, common_y: tuple[float, float]) -> dict:
    all_points = [point(r) for r in rows]
    methods = {r["policy_family"]: point(r) for r in method_rows}
    if set(methods) != set(METHODS) or len(method_rows) != len(METHODS):
        raise ValueError(f"{title}: require exactly one genuine W-BCE, BCE and plug-in baseline")
    for row in rows + method_rows:
        if int(row["n_splits"]) != 10:
            raise ValueError(f"{title}: incomplete split coverage: {row}")
    reference = methods["fitted_wbce"]
    if not (math.isclose(reference.x, 1.0, abs_tol=1e-8)
            and math.isclose(reference.y, 0.0, abs_tol=1e-8)):
        raise ValueError(f"{title}: coordinates do not share the fitted W-BCE reference")
    # Verify separate method export agrees with the summary used for the bank.
    for family, p in methods.items():
        matching = [q for q in all_points if q.family == family]
        if len(matching) != 1 or not (math.isclose(matching[0].x, p.x, abs_tol=1e-8)
                                     and math.isclose(matching[0].y, p.y, abs_tol=1e-8)):
            raise ValueError(f"{title}: {family} method/summary export mismatch")
    front = pareto(all_points)
    xmin = min(0.0, min(p.x - p.x_ci for p in all_points))
    xmax = max(1.0, max(p.x + p.x_ci for p in all_points))
    xpad = max(0.025, (xmax - xmin) * 0.04)
    xlow, xhigh = (xmin - xpad if xmin < 0 else 0.0), xmax + xpad
    ylow, yhigh = common_y
    bottom, width, height = 48, 135, 76
    xm = lambda x: left + width * (x - xlow) / (xhigh - xlow)
    ym = lambda y: bottom + height * (y - ylow) / (yhigh - ylow)
    canvas.text(left, bottom + height + 10, title, size=8.2, font="F2")
    canvas.rect(left, bottom, width, height, fill=WHITE)
    region(canvas, all_points, xm, ym, xlow, ylow, EXTENSION)
    region(canvas, list(methods.values()), xm, ym, xlow, ylow, BASE_REGION)
    for value in ticks(xlow, xhigh):
        x = xm(value)
        canvas.line([(x, bottom), (x, bottom + height)], stroke=GRID, line_width=0.3)
        canvas.text(x, bottom - 10, f"{value:g}", size=5.8, color=MUTED, align="center")
    for value in ticks(ylow, yhigh):
        y = ym(value)
        canvas.line([(left, y), (left + width, y)], stroke=GRID, line_width=0.3)
        if show_y:
            canvas.text(left - 5, y - 2, f"{value:g}", size=5.8, color=MUTED, align="right")
    edge = boundary(all_points)
    outline = [(xm(xlow), ym(edge[0].y)), (xm(edge[0].x), ym(edge[0].y))]
    for previous, current in zip(edge, edge[1:]):
        outline.extend([(xm(previous.x), ym(current.y)), (xm(current.x), ym(current.y))])
    canvas.line(outline, stroke=GREEN, line_width=0.9)
    for p in all_points:
        if p.family not in METHODS:
            canvas.circle(xm(p.x), ym(p.y), 0.6, fill=DOT)
    for p in front:
        if p.family not in METHODS:
            canvas.circle(xm(p.x), ym(p.y), 1.8, fill=GREEN, stroke=WHITE, line_width=0.3)
    status = {}
    for family, (label, color, shape) in METHODS.items():
        p = methods[family]
        error_bars(canvas, p, xm, ym)
        draw_marker(canvas, xm(p.x), ym(p.y), color, shape)
        n = sum(dominates(q, p) for q in all_points)
        status[label] = {"capture_fraction": p.x, "objection_closed": p.y,
                         "on_frontier": n == 0, "n_dominators": n}
    canvas.rect(left, bottom, width, height, stroke=GRID, line_width=0.65)
    return {"title": title, "points": len(all_points), "pareto_points": len(front),
            "x_range": [xlow, xhigh], "y_range": [ylow, yhigh], "competitors": status}


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", type=Path,
                        default=root / "results/csvs/bandha_figure3_policy_summary.csv")
    parser.add_argument("--methods", type=Path,
                        default=root / "results/csvs/bandha_figure3_method_points.csv")
    parser.add_argument("--output", type=Path,
                        default=root / "results/figures/bandha_figure3_common_frontier.pdf")
    parser.add_argument("--provenance", type=Path,
                        default=root / "results/bandha_figure3_plot_provenance.json")
    args = parser.parse_args()
    summary, methods = read_csv(args.summary), read_csv(args.methods)
    selected_datasets = {dataset for _, dataset in PANELS}
    summary = [r for r in summary if r["unit"] == "count" and r["dataset"] in selected_datasets]
    methods = [r for r in methods if r["unit"] == "count" and r["dataset"] in selected_datasets]
    if not summary:
        raise ValueError("No canonical count-unit Figure 3 data")
    pts = [point(r) for r in summary]
    ymin = min(0.0, min(p.y - p.y_ci for p in pts))
    ymax = max(1.0, max(p.y + p.y_ci for p in pts))
    ypad = max(0.025, (ymax - ymin) * 0.03)
    canvas = Canvas(540, 150)
    canvas.rect(0, 0, 540, 150, fill=WHITE)
    panels = []
    for i, (title, dataset) in enumerate(PANELS):
        panels.append(draw_panel(canvas, title,
                      [r for r in summary if r["dataset"] == dataset],
                      [r for r in methods if r["dataset"] == dataset],
                      57 + i * 164, i == 0, (ymin - ypad, ymax + ypad)))
    canvas.text(289, 29, "Loss capture / unpriced W-BCE", size=7.0, align="center")
    for x, (label, color, shape) in zip((150, 230, 295), METHODS.values()):
        draw_marker(canvas, x, 12, color, shape)
        canvas.text(x + 8, 10, label, size=7.0, color=color)
    canvas.circle(375, 12, 1.8, fill=GREEN, stroke=WHITE, line_width=0.3)
    canvas.text(383, 10, "Priced frontier", size=7.0, color=GREEN)
    canvas.rotated_text(14, 86, "W-BCE objection share removed", angle_degrees=90,
                        size=7.0, align="center")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pdf = PDF()
    pdf.add_page(canvas)
    pdf.write(args.output)
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    report = {"data_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
              "generator_sha256": digest(Path(__file__)),
              "source_sha256": {str(p.relative_to(root)): digest(p) for p in [Path(__file__).resolve(), Path(__file__).resolve().parent / "make_wsdm_account_objection_pareto.py", Path(__file__).resolve().parent / "make_wsdm_objection_figures.py"]},
              "input_sha256": {str(p.relative_to(root)) if p.is_relative_to(root) else str(p): digest(p) for p in [args.summary, args.methods]},
              "output_sha256": digest(args.output), "panels": panels,
              "boundary": "dominated region of evaluated pure policies; no convex-mixture claim",
              "axis_clipping": False, "descriptive_only": True}
    args.provenance.parent.mkdir(parents=True, exist_ok=True)
    args.provenance.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
