# Value-objective continuation

Owner: bandha. Authorized on 2026-11-17 after the capture results were seen.

The user explicitly requested completion of the unfinished experiment:
"so why not finish the shit?" This instruction supersedes the value-arm
withdrawal for this continuation. We retain the earlier protocol amendment
and the completed capture-only outputs as the history of the experiment.

We complete the same value-objection objective, all 24 settings and ten
seeds. We reuse the 180 valid C-sealed value fits and refit the 60 cases
whose constant-classifier export failed. We preserve those partial outputs
before refitting. We retain the original training/V/C/T memberships,
thresholds, two-group count/value/loss constraints, .10 value cap, .95
capture floor, XGBoost settings, Fairlearn tolerances, and fallback rules.
The corrected exporter handles constant classifiers; it does not change
the learning objective, classifier acquisition, or calibration.

We seal all 240 value policies before evaluating any value-arm T outcomes.
The completed capture results have already been examined. Consequently,
this is an exploratory continuation following examination of the other
arm, and we disclose that timing. We make no claim of a blind decision to
complete both arms. We change no hyperparameter or objective based on T.
We retain every case and every resource or convergence failure.

The continuation runner is
`github-yielding_fairness/fairness/bandha_resume_value_levels_20261117.py`.
It imports the unchanged fitting functions in the data checkout and checks
their identities against the original source snapshot. Its source snapshot
and separate value C freeze preserve the earlier capture freeze and CSVs.
We use four workers with the original two threads per XGBoost response.

```sh
DYLD_LIBRARY_PATH=/Users/atavory/.cache/bandha_fsl_xgboost_venv/lib/python3.12/site-packages/sklearn/.dylibs \
  /Users/atavory/.cache/bandha_fsl_xgboost_venv/bin/python \
  /Users/atavory/fbsource/github-yielding_fairness/fairness/bandha_resume_value_levels_20261117.py fit \
  --root /Users/atavory/fbsource/bandha_fsl_data_live \
  --public-root /Users/atavory/fbsource/github-yielding_fairness \
  --run /Users/atavory/.cache/bandha_fsl_xgboost_20261113 \
  --raw /Users/atavory/.cache/bandha_fsl_xgboost_raw \
  --output /Users/atavory/.cache/bandha_level_reductions_20261117 \
  --workers 4 --threads 2
```

Replace `fit` by `test` after the value C freeze exists. Freeze the new
value CSVs and the combined comparison under the live data checkout, and
update experiment provenance and status before adding manuscript evidence.
