"""Fit and seal direct level-constrained reductions on original training rows."""

from __future__ import annotations

import argparse
import concurrent.futures
import importlib.metadata
import json
import sys
import time
from pathlib import Path

import bandha_agarwal_run_20261114 as original
import bandha_agarwal_training_run_20261114 as training
import numpy as np
import xgboost as xgb
from bandha_agarwal_levels_20261117 import (
    LevelConstraints,
    ValueObjectionObjective,
    calibrate,
)
from bandha_agarwal_reductions_20261114 import CaptureObjective, CSXGBoost
from fairlearn.reductions import ExponentiatedGradient
from sklearn.dummy import DummyClassifier


OBJECTIVES = ("capture", "value")
CANARY_CASES = {("german_credit_sex", "0"), ("uci_credit_age", "0"), ("cms_gender", "0")}


def identity(args):
    script = Path(__file__)
    paths = [
        script, script.with_name("bandha_agarwal_levels_20261117.py"),
        Path(original.__file__), Path(training.__file__),
        script.with_name("bandha_agarwal_reductions_20261114.py"),
        args.root / "bandha_level_reductions_protocol_20261117.md",
    ]
    paths.extend(args.public_root / "fairness" / n for n in (
        "bandha_xgboost_rerun.py", "bandha_xgboost_models.py",
        "fairness_candidates.py", "public_group_candidates.py",
        "public_w16_candidates_registry.py", "bandha_external_criteria_io.py",
    ))
    return {
        "code": {str(p): original.sha(p) for p in paths},
        "original_C_freeze": original.sha(args.run / "C_FREEZE.json"),
        "packages": {p: importlib.metadata.version(p) for p in (
            "fairlearn", "xgboost", "numpy", "scipy", "scikit-learn",
        )},
        "fit_split": "original_train", "objectives": list(OBJECTIVES),
        "eps": .002, "nu": .002, "max_iter": 50, "threads": args.threads,
        "value_cap": .10, "capture_floor": .95,
        "level_units": ["count", "value", "loss"],
        "openmp_runtime_sha256": original.sha(Path(
            importlib.metadata.distribution("scikit-learn").locate_file(
                "sklearn/.dylibs/libomp.dylib"
            )
        )),
    }


def check_reconstructed_features(case, args, record, xc, saved):
    source, _, _ = original.imports(args.public_root)
    directory = args.run / "cells" / (case["dataset"] + "__" + case["seed"])
    models = {n: xgb.Booster(model_file=str(directory / (n + ".ubj"))) for n in ("wbce", "value", "loss")}
    if xc.shape[1] != models["wbce"].num_features():
        raise ValueError("Reconstructed feature dimension changed")
    logit, a, b = source.models.predict(models, record["models"], xc, args.threads)
    actual = (np.exp(np.clip(logit, -50, 50)), a, b)
    expected = (saved["C"][:, 1], saved["C"][:, 4], saved["C"][:, 5])
    errors = {}
    for name, found, target in zip(("wbce", "value", "loss"), actual, expected):
        error = float(np.max(np.abs(found - target) / np.maximum(1, np.abs(target)), initial=0))
        if error > 1e-6:
            raise ValueError(f"Original model predictions changed: {name} {error}")
        errors[name] = error
    return errors


def objective_for(name, array):
    return CaptureObjective(array[:, 3]) if name == "capture" else ValueObjectionObjective(array)


def fit_classifiers(array, p0, features, labels, case, args, objective):
    algorithm = ExponentiatedGradient(
        CSXGBoost(seed=910000 + int(case["seed"]), threads=args.threads, rounds=100),
        LevelConstraints(array, p0), objective=objective_for(objective, array),
        eps=.002, nu=.002, max_iter=50, run_linprog_step=True,
    )
    algorithm.fit(features, labels, sensitive_features=array[:, 0].astype(int))
    predictors = list(algorithm.predictors_.items())
    weights = np.asarray([float(algorithm.weights_.get(i, 0)) for i, _ in predictors])
    if not np.isfinite(weights).all() or abs(weights.sum() - 1) > 1e-7 or np.min(weights) < -1e-9:
        raise ValueError("Raw reductions mixture is not a valid probability mixture")
    if not np.isfinite(algorithm.best_gap_):
        raise ValueError("Reductions training gap is nonfinite")
    return algorithm, predictors, weights


def predict_bank(predictors, features, baseline):
    return np.vstack([
        baseline, np.zeros(len(features)),
        *[np.asarray(model.predict(features), dtype=float) for _, model in predictors],
    ])


def export_predictors(predictors, directory):
    result = []
    for index, model in predictors:
        if hasattr(model, "model_"):
            name = f"bandha_model_{index}.ubj"
            model.model_.save_model(directory / name)
            result.append({"index": int(index), "kind": "xgboost", "file": name})
        elif isinstance(model, DummyClassifier) and model.strategy == "constant":
            constant = int(np.asarray(model.constant).reshape(-1)[0])
            if constant not in (0, 1):
                raise ValueError("Unsupported constant classifier output")
            result.append({"index": int(index), "kind": "constant", "prediction": constant})
        else:
            raise TypeError("Unsupported reductions classifier: " + type(model).__name__)
    original.save(directory / "bandha_predictor_manifest.json", result)
    return result


def compatible_cached_identity(prior, current, args):
    if prior == current:
        return True
    source = args.output / "bandha_SOURCE_SEAL_before_export_fix.json"
    proof = args.output / "bandha_EXPORT_COMPATIBILITY.json"
    if not source.is_file() or not proof.is_file():
        return False
    previous = json.loads(source.read_text())
    certificate = json.loads(proof.read_text())
    key = str(Path(__file__))
    if prior != previous or current["code"][key] != certificate["fixed_driver_sha256"]:
        return False
    if prior["code"][key] != certificate["previous_driver_sha256"]:
        return False
    previous["code"][key] = current["code"][key]
    return previous == current and all(certificate["unchanged_fitting_functions"].values())


def seal_arm(case, args, record, saved, train_array, xtrain, xc, xt, labels, objective, checks):
    label = case["dataset"] + "__" + case["seed"]
    directory = args.output / ("bandha_" + label) / objective
    directory.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    source, _, _ = original.imports(args.public_root)
    ptrain = source.frozen.baseline(train_array, record["case"])
    algorithm, predictors, raw_weights = fit_classifiers(train_array, ptrain, xtrain, labels, case, args, objective)
    c = saved["C"]
    pc = source.frozen.baseline(c, record["case"])
    c_bank = predict_bank(predictors, xc, pc)
    weights, certificate = calibrate(c_bank, c, pc, objective)
    c_raw, c_cal = raw_weights @ c_bank[2:], weights @ c_bank
    t_baseline = source.frozen.baseline(saved["T"], record["case"])
    t_bank = predict_bank(predictors, xt, t_baseline)
    np.savez_compressed(directory / "bandha_predictions.npz", C_raw=c_raw, C_cal=c_cal, T_raw=raw_weights @ t_bank[2:], T_cal=weights @ t_bank)
    manifests = export_predictors(predictors, directory)
    rows = original.evaluate(c, pc, c_raw, case, f"levels_{objective}_raw", args.public_root)
    rows += original.evaluate(c, pc, c_cal, case, f"levels_{objective}_Ccal", args.public_root)
    original.csv_output(directory / "bandha_C.csv", rows)
    original.save(directory / "bandha_C_seal.json", {
        "case": record["case"], "fit_identity": identity(args), "objective": objective,
        "original_predictions_sha256": record["predictions_sha256"],
        "predictors": [int(i) for i, _ in predictors], "EG_weights": raw_weights.tolist(),
        "predictor_manifest": manifests,
        "Ccal_weights": weights.tolist(), "Ccal_certificate": certificate,
        "best_gap": float(algorithm.best_gap_), "best_iter": int(algorithm.best_iter_),
        "oracle_calls": int(algorithm.n_oracle_calls_), "n_classifiers": len(predictors),
        "gap_converged": bool(algorithm.best_gap_ <= .002 + 1e-10),
        "seconds": time.monotonic() - start, "feature_reconstruction": checks,
        "T_metrics_evaluated": False,
        "predictions_sha256": original.sha(directory / "bandha_predictions.npz"),
    })
    return {"objective": objective, "seconds": round(time.monotonic() - start, 2), "calls": int(algorithm.n_oracle_calls_), "gap": float(algorithm.best_gap_), "calibration": certificate["status"]}


def worker(task):
    case, args = task
    label = case["dataset"] + "__" + case["seed"]
    original_path = args.run / "cells" / label
    record = json.loads((original_path / "C_SEAL.json").read_text())
    prediction_path = original_path / "PREDICTIONS.npz"
    if original.sha(prediction_path) != record["predictions_sha256"]:
        raise ValueError("Original frozen predictions changed: " + label)
    with np.load(prediction_path) as saved:
        xtrain, xc, xt, labels, train_array = training.training_data(case, args, record, saved)
        checks = check_reconstructed_features(case, args, record, xc, saved)
        outcomes = []
        for objective in OBJECTIVES:
            seal = args.output / ("bandha_" + label) / objective / "bandha_C_seal.json"
            if seal.exists():
                prior = json.loads(seal.read_text())
                if not compatible_cached_identity(prior["fit_identity"], identity(args), args):
                    raise ValueError("Cached level fit uses different inputs or code")
                outcomes.append({"objective": objective, "cached": True})
                continue
            outcomes.append(seal_arm(case, args, record, saved, train_array, xtrain, xc, xt, labels, objective, checks))
    return label, outcomes


def cell_seals(args, cases):
    return {
        (case["dataset"] + "__" + case["seed"]): {
            objective: original.sha(args.output / ("bandha_" + case["dataset"] + "__" + case["seed"]) / objective / "bandha_C_seal.json")
            for objective in OBJECTIVES
        }
        for case in cases
    }


def fit(args, cases):
    frozen_identity = identity(args)
    original.save(args.output / "bandha_SOURCE_SEAL.json", frozen_identity)
    completed = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        jobs = [pool.submit(worker, (case, args)) for case in cases]
        for job in concurrent.futures.as_completed(jobs):
            label, outcomes = job.result()
            completed.append(label)
            print(f"C sealed {len(completed)}/{len(cases)}: {label} {outcomes}", flush=True)
            original.save(args.output / "bandha_PROGRESS.json", {"completed": completed, "total": len(cases), "last": outcomes})
    if identity(args) != frozen_identity:
        raise ValueError("Fitting code changed during the full run")
    original.save(args.output / "bandha_C_FREEZE.json", {"identity": frozen_identity, "seals": cell_seals(args, cases), "T_metrics_evaluated": False})
    print("All C policies frozen:", len(cases) * len(OBJECTIVES), flush=True)


def evaluate_arm(args, case, objective, freeze, saved):
    label = case["dataset"] + "__" + case["seed"]
    directory = args.output / ("bandha_" + label) / objective
    path = directory / "bandha_C_seal.json"
    if original.sha(path) != freeze["seals"][label][objective]:
        raise ValueError("C policy seal changed")
    record = json.loads(path.read_text())
    if original.sha(directory / "bandha_predictions.npz") != record["predictions_sha256"]:
        raise ValueError("Level-reductions predictions changed")
    source, _, _ = original.imports(args.public_root)
    result = {"C": [], "T": []}
    with np.load(directory / "bandha_predictions.npz") as p:
        for part in result:
            data = saved[part]
            p0 = source.frozen.baseline(data, record["case"])
            for kind in ("raw", "cal"):
                suffix = "raw" if kind == "raw" else "Ccal"
                rows = original.evaluate(data, p0, p[part + "_" + kind], case, f"levels_{objective}_{suffix}", args.public_root)
                for row in rows:
                    row["part"] = part
                    row["level_target_scope"] = "count_value_loss_original_groups"
                result[part].extend(rows)
    return result


def test(args, cases):
    freeze = json.loads((args.output / "bandha_C_FREEZE.json").read_text())
    if freeze["identity"] != identity(args):
        raise ValueError("Code or inputs changed after C policy freezing")
    aggregate = {"C": [], "T": []}
    for case in cases:
        path = args.run / "cells" / (case["dataset"] + "__" + case["seed"]) / "PREDICTIONS.npz"
        with np.load(path) as saved:
            for objective in OBJECTIVES:
                result = evaluate_arm(args, case, objective, freeze, saved)
                for part in aggregate:
                    aggregate[part].extend(result[part])
    for part, rows in aggregate.items():
        original.csv_output(args.output / f"bandha_{part}.csv", rows)
    original.save(args.output / "bandha_T_PROVENANCE.json", {"C_freeze_sha256": original.sha(args.output / "bandha_C_FREEZE.json"), "T_sha256": original.sha(args.output / "bandha_T.csv"), "cells": len(cases), "arms": list(OBJECTIVES), "no_T_parameter_selection": True, "exploratory": True})
    print("T complete:", len(cases) * len(OBJECTIVES), flush=True)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("fit", "test"))
    for name in ("root", "public-root", "run", "raw", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--canary", action="store_true")
    return parser.parse_args()


def main():
    args = arguments()
    args.output.mkdir(parents=True, exist_ok=True)
    cases = json.loads((args.root / "results/csvs/bandha_external_criteria_inputs_20261113.json").read_text())["cases"]
    if args.canary:
        cases = [c for c in cases if (c["dataset"], c["seed"]) in CANARY_CASES]
    if len(cases) != (3 if args.canary else 240):
        raise ValueError("Unexpected number of fixed cases")
    if args.phase == "fit":
        fit(args, cases)
    else:
        test(args, cases)


if __name__ == "__main__":
    main()
