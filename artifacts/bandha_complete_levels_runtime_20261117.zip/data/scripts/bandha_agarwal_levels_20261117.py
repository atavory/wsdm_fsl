"""Known-group objection-level constraints for the reductions follow-up."""

from __future__ import annotations

import numpy as np
import pandas as pd
from bandha_agarwal_reductions_20261114 import CaptureObjective
from fairlearn.reductions import ClassificationMoment
from scipy.optimize import linprog


def objection_flag(array):
    return ~((array[:, 6] > .5) & (array[:, 7] > .5))


def level_rows(array, baseline):
    n = len(array)
    group, q = array[:, 0], objection_flag(array)
    rows, bounds, names = [], [], []
    units = {"count": np.ones(n), "value": array[:, 2], "loss": array[:, 3]}
    for unit, amounts in units.items():
        for g in (0, 1):
            mask = group == g
            denominator = float(amounts[mask].sum())
            if denominator == 0:
                continue
            coefficient = n * q * amounts * mask / denominator
            rows.append(coefficient)
            bounds.append(float(np.mean(coefficient * baseline)))
            names.append(f"level_{g}_{unit}")
    return rows, bounds, names


def moment_system(array, baseline, value_cap=.10, capture_floor=.95):
    array = np.asarray(array, dtype=float)
    baseline = np.asarray(baseline, dtype=float)
    if array.ndim != 2 or array.shape[1] != 9 or baseline.shape != (len(array),):
        raise ValueError("Invalid prediction/moment schema")
    if not np.isfinite(array).all() or not np.isfinite(baseline).all():
        raise ValueError("Nonfinite moment inputs")
    a, b = array[:, 2], array[:, 3]
    if a.mean() <= 0 or b.mean() <= 0:
        raise ValueError("Population value/loss support is undefined")
    rows, bounds, names = level_rows(array, baseline)
    rows.extend([a / a.mean(), -b / b.mean()])
    bounds.extend([value_cap, -capture_floor * float(np.sum(baseline * b) / b.sum())])
    names.extend(["value_cap", "capture_floor"])
    return np.asarray(rows), np.asarray(bounds), pd.Index(names)


class LevelConstraints(ClassificationMoment):
    def __init__(self, array, baseline, value_cap=.10, capture_floor=.95):
        super().__init__()
        self.array = np.asarray(array, dtype=float)
        self.baseline = np.asarray(baseline, dtype=float)
        self.matrix, self.bounds, self.names = moment_system(
            self.array, self.baseline, value_cap, capture_floor
        )

    def load_data(self, X, y, *, sensitive_features):
        if len(X) != len(self.array):
            raise ValueError("Features and moment inputs differ in length")
        super().load_data(X, pd.Series(y), sensitive_features=pd.Series(sensitive_features))

    @property
    def index(self):
        return self.names

    def gamma(self, predictor):
        prediction = np.asarray(predictor(self.X), dtype=float).reshape(-1)
        return pd.Series(np.mean(self.matrix * prediction, axis=1), index=self.index)

    def bound(self):
        return pd.Series(self.bounds, index=self.index)

    def signed_weights(self, lambda_vec):
        return pd.Series(-np.asarray(lambda_vec) @ self.matrix)

    def project_lambda(self, lambda_vec):
        return lambda_vec

    def default_objective(self):
        return CaptureObjective(self.array[:, 3])


class ValueObjectionObjective(ClassificationMoment):
    def __init__(self, array):
        super().__init__()
        self.array = np.asarray(array, dtype=float)
        if self.array[:, 2].mean() <= 0:
            raise ValueError("Value objective has no positive denominator")
        self.coefficients = objection_flag(self.array) * self.array[:, 2] / self.array[:, 2].mean()

    def load_data(self, X, y, *, sensitive_features=None):
        sf = None if sensitive_features is None else pd.Series(sensitive_features)
        super().load_data(X, pd.Series(y), sensitive_features=sf)

    @property
    def index(self):
        return pd.Index(["value_objections"])

    def gamma(self, predictor):
        prediction = np.asarray(predictor(self.X), dtype=float).reshape(-1)
        return pd.Series([np.mean(prediction * self.coefficients)], index=self.index)

    def signed_weights(self, lambda_vec=None):
        return pd.Series(-self.coefficients)

    def project_lambda(self, lambda_vec):
        return lambda_vec


def bank_objective(bank, array, objective):
    if objective == "capture":
        return -bank @ array[:, 3] / array[:, 3].sum()
    if objective == "value":
        return bank @ (objection_flag(array) * array[:, 2]) / array[:, 2].sum()
    raise ValueError("Unknown reductions objective: " + objective)


def solve_bank(objective, matrix, bounds, size):
    return linprog(
        objective, A_ub=matrix, b_ub=bounds,
        A_eq=[np.ones(size)], b_eq=[1], bounds=(0, 1), method="highs",
        options={"primal_feasibility_tolerance": 1e-10, "dual_feasibility_tolerance": 1e-10},
    )


def calibrate(bank, array, baseline, objective):
    bank = np.asarray(bank, dtype=float)
    if bank.ndim != 2 or bank.shape[1] != len(array):
        raise ValueError("Invalid acquired classifier bank")
    moments, bounds, names = moment_system(array, baseline)
    matrix = moments @ bank.T / len(array)
    result = solve_bank(bank_objective(bank, array, objective), matrix, bounds, len(bank))
    status = "feasible_acquired_bank"
    active = np.ones(len(bounds), dtype=bool)
    if result.status == 2:
        active[names.get_loc("capture_floor")] = False
        result = solve_bank(
            bank_objective(bank, array, "capture"), matrix[active], bounds[active], len(bank)
        )
        status = "capture_floor_infeasible_best_capture_fallback"
    if not result.success:
        raise RuntimeError("Known-level acquired-bank LP failed: " + result.message)
    if np.min(result.x) < -1e-9:
        raise ValueError("LP produced a negative mixture weight")
    weights = np.maximum(result.x, 0)
    weights /= weights.sum()
    residual = matrix @ weights - bounds
    if np.max(residual[active]) > 1e-8 or abs(weights.sum() - 1) > 1e-10:
        raise ValueError("Calibrated mixture failed its active moment certificate")
    return weights, {
        "status": status, "moment_names": names.tolist(),
        "bounds": bounds.tolist(), "applied_moments": (matrix @ weights).tolist(),
        "active_max_violation": float(max(0, np.max(residual[active]))),
        "all_max_violation": float(max(0, np.max(residual))),
        "objective": objective if np.all(active) else "capture_fallback",
    }
