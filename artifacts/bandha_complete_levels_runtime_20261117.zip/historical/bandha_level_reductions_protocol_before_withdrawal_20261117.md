# Direct level-constrained reductions follow-up

Owner: bandha. User authorized further experiments on 2026-11-17.
This protocol is fixed before the new fits or their T evaluation.

## Fixed inputs

Use the existing 24 settings under ten seeds, exact original training/V/C/T
IDs, original training-only feature transformations, frozen boosted
baseline and harm/net-harm models, V baseline/criterion thresholds and the
original C/T amounts. Preserve the earlier gap-constrained run.

## Two arms

1. **Capture objective:** minimize missed captured loss. This matches the
   completed gap-constrained reductions objective, changing its fairness
   moments to direct level nonincrease.
2. **Value-objection objective:** minimize population value-weighted
   objection mass, divided by total value. This matches common contraction's
   desired objection removal, with a more flexible acquired classifier bank.

Both use direct `D_g^U(pi)<=D_g^U(pi_0)` constraints for each original
binary group and U in count, value and loss. Omit an undefined moment
when its group outcome weight is zero. The original absolute gap cap is
replaced, rather than added. Retain the pooled .10 value cap and .95
same-subset baseline capture floor.

Keep Fairlearn 0.15.0 EG at eps/nu .002 and maximum 50 iterations. Use the
original cost-sensitive XGBoost responses: 100 depth-six histogram trees,
eta .05, lambda 1, min_child_weight 5, row/column subsampling .8,
base_score .5, seed 910000+seed and two threads.

The local XGBoost runtime uses the libomp library already bundled with
the installed scikit-learn wheel, supplied via DYLD_LIBRARY_PATH. Record
its hash with the fit identity. No model library or raw inputs are replaced.

## Fitting and evaluation

Fit each new bank on original training rows. Compute training criterion
flags using the existing mean models and V thresholds. Calibrate the
acquired classifiers, baseline and all-pass on C under the same direct
level/business constraints and the selected objective. With an infeasible
capture floor, choose the best capture mixture satisfying the remaining
level and value bounds, retaining the failure flag. All-pass guarantees
feasibility of that remaining finite-bank problem.

Use HiGHS numerical feasibility tolerances 1e-10 and record the normalized
moment residuals after mixture normalization. Record raw EG and calibrated
mixtures separately. Preserve convergence/fallback flags; no T-driven
hyperparameter or objective selection.

Seal both arms for every case on C before T outcome evaluation. Evaluate
all existing primary endpoints, all defined group/unit level violations,
pointwise added objections, and the same new group partitions. Give both
run means and equal-source summaries, retaining every infeasible case.

This is exploratory follow-up on already examined data. Finite known
group/unit constraints do not imply pointwise bounds, arbitrary-group
protection or proportionality in every aggregation. Approximate XGBoost
oracles and finite acquired banks do not prove global classifier optimality.
