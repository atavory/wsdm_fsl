"""Fit a sparse maximum-predicted-capture selector and freeze its dual rule.

Forecast fields expose only group, predicted value, ratio score, and the fixed
objection indicator. The new LP uses no settled candidate value or loss. Its
baseline threshold, baseline thinning, and objection references remain the
explicit historical inputs from the original validation-frozen experiment.

The objective maximizes predicted loss under a predicted value budget,
disparity tolerance, and two predicted group caps. The 0.95 retained-capture
target is a diagnostic, not an LP constraint. Test application uses only the
frozen score coefficients, normalization constants, and four boundary
probabilities; it never orders or budgets a test batch using outcomes.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import logging
import math
import platform
import shlex
import sys
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import bandha_fairness_group_outcomes as outcomes
import bandha_no_worsening_bank_mixtures as original
import numpy as np
import scipy
from numpy.typing import NDArray
from scipy.optimize import linprog, OptimizeResult
from scipy.sparse import csr_matrix, vstack


LOGGER: logging.Logger = logging.getLogger(__name__)
GENERATOR = "scripts/bandha_direct_constrained_selector.py"
PROTOCOL = "bandha_direct_selector_protocol_20261104.md"
INPUT_FREEZE = "results/bandha_normalized_prices/validation_freeze.json.gz"
HELPERS = (
    "scripts/bandha_fairness_group_outcomes.py",
    "scripts/bandha_no_worsening_bank_mixtures.py",
    "scripts/bandha_cached_group_awareness.py",
)
GAMMAS = (1.0, 0.75, 0.50, 0.25, 0.0)
MARGINS = (0.0, 0.05)
VALUE_CAP = 0.10
EVALUATION_FLOOR = 0.95
SOLVER_TOLERANCE = 1e-10
CHECK_TOLERANCE = 1e-8
RATIO_ABSOLUTE_TOLERANCE = 1e-12
RATIO_RELATIVE_TOLERANCE = 1e-12
BOUND_TOLERANCE = 1e-10
COLUMN_IMPACT_FACTOR = 16.0
TARGET_TOLERANCE = 1e-10
CellKey = tuple[str, str, str]
FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


class MissingPredictedSupport(ValueError):
    """At least one predicted group denominator is unavailable."""


class SelectorNumericalError(RuntimeError):
    """An optimum or its prospective replay fails the numerical contract."""


@dataclass(frozen=True, slots=True)
class Forecast:
    group: int
    value: float
    ratio: float
    objectable: bool


@dataclass
class PredictionBatch:
    group: IntArray
    value: FloatArray
    ratio: FloatArray
    objectable: NDArray[np.bool_]

    @property
    def loss(self) -> FloatArray:
        return self.value * self.ratio

    @property
    def size(self) -> int:
        return len(self.value)


@dataclass(frozen=True)
class Scope:
    key: CellKey
    source: str
    relative_input: str
    groups: tuple[str, str]
    baseline_index: int
    baseline_threshold: float
    baseline_alpha: float


@dataclass
class EmpiricalProblem:
    forecasts: PredictionBatch
    matrix: csr_matrix
    rhs: FloatArray
    objective: FloatArray
    upper: FloatArray
    normalization: dict[str, Any]
    baseline: dict[str, Any]


def forecast_record(
    row: Mapping[str, str], compact: bool, groups: tuple[str, str] | list[str]
) -> Forecast:
    group = outcomes.legacy.decode("group", row["g"]) if compact else row["group"]
    logit = float(row["q"] if compact else row["score"])
    value = float(
        row["ah"] if compact else row.get("estimated_value", row.get("a_hat", "0"))
    )
    harm = float(
        row["h"]
        if compact
        else row.get("selected_criterion_harm", row.get("selected_harm", "0"))
    )
    net = float(
        row["nh"]
        if compact
        else row.get("selected_criterion_net_harm", row.get("selected_net_harm", "0"))
    )
    if (
        not math.isfinite(logit)
        or not math.isfinite(value)
        or harm not in (0.0, 1.0)
        or net not in (0.0, 1.0)
    ):
        raise ValueError("Invalid forecast or fixed binary reference indicator")
    objectable = not (harm > 0.5 and net > 0.5)
    value = max(value, 0.0)
    unused_observed_slots = (group, 0.0, 0.0, logit, value, objectable)
    ratio = outcomes.value_unit_score(unused_observed_slots, 0.0)
    return Forecast(tuple(groups).index(group), value, ratio, objectable)


def forecast_batch(records: Iterable[Forecast]) -> PredictionBatch:
    values = list(records)
    if not values:
        raise ValueError("Empty forecast batch")
    if any(
        row.group not in (0, 1)
        or row.value < 0.0
        or row.ratio <= 0.0
        or not math.isfinite(row.value)
        or not math.isfinite(row.ratio)
        for row in values
    ):
        raise ValueError("Invalid forecast-only batch")
    return PredictionBatch(
        np.asarray([row.group for row in values], dtype=np.int64),
        np.asarray([row.value for row in values], dtype=np.float64),
        np.asarray([row.ratio for row in values], dtype=np.float64),
        np.asarray([row.objectable for row in values], dtype=bool),
    )


def load_scopes(
    root: Path, revision: str
) -> tuple[dict[CellKey, Scope], list[dict[str, Any]]]:
    manifests = [outcomes.committed_input(root, INPUT_FREEZE, revision)]
    with gzip.open(root / INPUT_FREEZE, "rt") as handle:
        frozen = json.load(handle)
    scopes = {}
    for case in frozen["cases"]:
        if case["currency"] != "value":
            continue
        point = outcomes.baseline_point(case)
        index = next(i for i, item in enumerate(case["bank"]) if item is point)
        key = (case["dataset"], str(case["seed"]), "value")
        if key in scopes:
            raise ValueError("Duplicate frozen cell")
        scopes[key] = Scope(
            key,
            original.source_name(key[0]),
            case["input"],
            tuple(case["groups"]),
            index,
            point["threshold"],
            case["baseline"]["alpha"],
        )
    if len(scopes) != 240 or len({scope.source for scope in scopes.values()}) != 10:
        raise ValueError(
            "The direct-selector scope must retain all 240 cells and ten sources"
        )
    for item in frozen["inputs"]:
        identity = outcomes.committed_input(root, item["path"], revision)
        if identity["sha256"] != item["sha256"]:
            raise ValueError("Candidate input differs from the original freeze")
        manifests.append(identity)
    for name in HELPERS:
        manifests.append(outcomes.committed_input(root, name, revision))
    return scopes, manifests


def validation_records(
    root: Path, relative: str, scopes: Mapping[CellKey, Scope]
) -> dict[CellKey, list[Forecast]]:
    result: dict[CellKey, list[Forecast]] = defaultdict(list)
    with gzip.open(root / relative, "rt", newline="") as handle:
        reader = csv.DictReader(handle)
        compact = "d" in (reader.fieldnames or ())
        for row in reader:
            dataset, seed, split, target = outcomes.candidate_key(row, compact)
            key = (dataset, str(seed), "value")
            if (
                split.lower() == "validation"
                and math.isclose(target, VALUE_CAP)
                and key in scopes
            ):
                result[key].append(forecast_record(row, compact, scopes[key].groups))
    return dict(result)


def load_validation_forecasts(
    root: Path, scopes: Mapping[CellKey, Scope]
) -> dict[CellKey, PredictionBatch]:
    by_input: dict[str, dict[CellKey, Scope]] = defaultdict(dict)
    for key, scope in scopes.items():
        by_input[scope.relative_input][key] = scope
    result = {}
    for relative, cells in sorted(by_input.items()):
        loaded = validation_records(root, relative, cells)
        if set(loaded) != set(cells):
            raise ValueError("A frozen cell lacks validation predictions")
        result.update({key: forecast_batch(rows) for key, rows in loaded.items()})
        LOGGER.info("Loaded forecast fields only: %s", relative)
    return result


def normalization(forecasts: PredictionBatch) -> dict[str, Any]:
    value = math.fsum(forecasts.value)
    loss = math.fsum(forecasts.loss)
    groups = [math.fsum(forecasts.value[forecasts.group == group]) for group in (0, 1)]
    if any(total <= 0.0 for total in groups):
        raise MissingPredictedSupport("A predicted group value denominator is zero")
    if (
        value <= 0.0
        or loss <= 0.0
        or not all(math.isfinite(total) for total in (value, loss, *groups))
    ):
        raise ValueError("Predicted totals are nonpositive or nonfinite")
    return {"value_total": value, "loss_total": loss, "group_value_totals": groups}


def baseline_probabilities(forecasts: PredictionBatch, scope: Scope) -> FloatArray:
    selected = (forecasts.ratio >= scope.baseline_threshold) & (forecasts.ratio > 0.0)
    return selected.astype(np.float64) * scope.baseline_alpha


def model_moments(
    forecasts: PredictionBatch, probabilities: FloatArray, totals: Mapping[str, Any]
) -> dict[str, float]:
    capture = math.fsum(forecasts.loss * probabilities)
    spend = math.fsum(forecasts.value * probabilities)
    levels = [
        math.fsum(
            (forecasts.value * forecasts.objectable * probabilities)[
                forecasts.group == group
            ]
        )
        / totals["group_value_totals"][group]
        for group in (0, 1)
    ]
    return {
        "captured_loss": capture,
        "capture_fraction": capture / totals["loss_total"],
        "blocked_value": spend,
        "spend_fraction": spend / totals["value_total"],
        "D0": levels[0],
        "D1": levels[1],
        "signed_gap": levels[1] - levels[0],
        "absolute_gap": abs(levels[1] - levels[0]),
    }


def constraint_matrix(
    forecasts: PredictionBatch, totals: Mapping[str, Any]
) -> csr_matrix:
    budget = csr_matrix(forecasts.value / totals["value_total"])
    complaint = forecasts.value * forecasts.objectable
    rows = [
        csr_matrix(
            np.where(
                forecasts.group == group,
                complaint / totals["group_value_totals"][group],
                0.0,
            )
        )
        for group in (0, 1)
    ]
    gap = rows[1] - rows[0]
    return vstack((budget, gap, -gap, rows[0], rows[1]), format="csr")


def make_problem(
    forecasts: PredictionBatch, scope: Scope, gamma: float, margin: float
) -> EmpiricalProblem:
    if not 0.0 <= gamma <= 1.0 or not 0.0 <= margin <= 1.0:
        raise ValueError("Gamma and margin must lie in the unit interval")
    totals = normalization(forecasts)
    baseline = model_moments(
        forecasts, baseline_probabilities(forecasts, scope), totals
    )
    epsilon = gamma * baseline["absolute_gap"]
    rhs = np.asarray(
        (
            VALUE_CAP,
            epsilon,
            epsilon,
            (1.0 - margin) * baseline["D0"],
            (1.0 - margin) * baseline["D1"],
        )
    )
    objective = -(forecasts.loss / totals["loss_total"])
    upper = (forecasts.value > 0.0).astype(np.float64)
    return EmpiricalProblem(
        forecasts,
        constraint_matrix(forecasts, totals),
        rhs,
        objective,
        upper,
        totals,
        baseline,
    )


def solve(problem: EmpiricalProblem) -> OptimizeResult:
    scale = float(problem.forecasts.size)
    result = linprog(
        problem.objective * scale,
        A_ub=problem.matrix * scale,
        b_ub=problem.rhs * scale,
        bounds=np.c_[np.zeros(problem.forecasts.size), problem.upper],
        method="highs-ds",
        options={
            "presolve": False,
            "primal_feasibility_tolerance": SOLVER_TOLERANCE,
            "dual_feasibility_tolerance": SOLVER_TOLERANCE,
        },
    )
    if result.status != 0:
        raise SelectorNumericalError(
            f"LP failed despite an explicit feasible all-pass policy: {result.status}, {result.message}"
        )
    if not np.isfinite(result.x).all() or not math.isfinite(result.fun):
        raise SelectorNumericalError("Nonfinite optimum")
    return result


def max_absolute(values: FloatArray) -> float:
    return float(np.max(np.abs(values), initial=0.0))


def kkt_receipt(problem: EmpiricalProblem, result: OptimizeResult) -> dict[str, float]:
    pi = np.asarray(result.x)
    marginals = np.asarray(result.ineqlin.marginals)
    scale = float(problem.forecasts.size)
    lower = np.asarray(result.lower.marginals) / scale
    upper = np.asarray(result.upper.marginals) / scale
    slack = problem.rhs - problem.matrix @ pi
    stationarity = problem.objective - problem.matrix.T @ marginals - lower - upper
    primal = float(-problem.objective @ pi)
    dual = float(-(problem.rhs @ marginals + problem.upper @ upper))
    errors = {
        "primal_constraint_error": float(np.max(np.maximum(-slack, 0.0), initial=0.0)),
        "lower_bound_error": float(np.max(np.maximum(-pi, 0.0), initial=0.0)),
        "upper_bound_error": float(
            np.max(np.maximum(pi - problem.upper, 0.0), initial=0.0)
        ),
        "inequality_dual_sign_error": float(
            np.max(np.maximum(marginals, 0.0), initial=0.0)
        ),
        "lower_dual_sign_error": float(np.max(np.maximum(-lower, 0.0), initial=0.0)),
        "upper_dual_sign_error": float(np.max(np.maximum(upper, 0.0), initial=0.0)),
        "stationarity_error": max_absolute(stationarity),
        "inequality_complementarity_error": max_absolute(marginals * slack),
        "lower_complementarity_error": max_absolute(lower * pi),
        "upper_complementarity_error": max_absolute(upper * (problem.upper - pi)),
        "primal_dual_gap": abs(primal - dual),
        "solver_objective_error": abs(primal + float(result.fun) / scale),
    }
    if max(errors.values()) > CHECK_TOLERANCE:
        raise SelectorNumericalError(f"KKT or primal error: {errors}")
    return {
        "normalized_primal_objective": primal,
        "normalized_dual_objective": dual,
        **errors,
    }


def dual_multipliers(result: OptimizeResult) -> dict[str, Any]:
    values = -np.asarray(result.ineqlin.marginals)
    if np.min(values) < -CHECK_TOLERANCE:
        raise SelectorNumericalError("Negative multiplier for an upper inequality")
    values = np.maximum(values, 0.0)
    return {
        "budget": float(values[0]),
        "disparity_upper": float(values[1]),
        "disparity_lower": float(values[2]),
        "group_caps": [float(values[3]), float(values[4])],
    }


def point_score(record: Forecast, selector: Mapping[str, Any]) -> float:
    dual = selector["multipliers"]
    signed = dual["disparity_upper"] - dual["disparity_lower"]
    group_coefficient = dual["group_caps"][record.group] + (
        signed if record.group == 1 else -signed
    )
    return (
        record.value * record.ratio / selector["model_loss_total"]
        - dual["budget"] * record.value / selector["model_value_total"]
        - group_coefficient
        * record.objectable
        * record.value
        / selector["model_group_value_totals"][record.group]
    )


def batch_scores(forecasts: PredictionBatch, selector: Mapping[str, Any]) -> FloatArray:
    dual = selector["multipliers"]
    signed = dual["disparity_upper"] - dual["disparity_lower"]
    coefficients = np.asarray(
        (dual["group_caps"][0] - signed, dual["group_caps"][1] + signed)
    )
    denominators = np.asarray(selector["model_group_value_totals"])
    return (
        forecasts.loss / selector["model_loss_total"]
        - dual["budget"] * forecasts.value / selector["model_value_total"]
        - coefficients[forecasts.group]
        * forecasts.objectable
        * forecasts.value
        / denominators[forecasts.group]
    )


def probability(record: Forecast, selector: Mapping[str, Any]) -> float:
    if not selector["defined"]:
        raise MissingPredictedSupport("The frozen selector lacks predicted support")
    if record.value <= 0.0:
        return 0.0
    key = f"{record.group}:{int(record.objectable)}"
    score = record.ratio - selector["raw_ratio_thresholds"][key]
    tolerance = selector["ratio_tolerances"][key]
    if score > tolerance:
        return 1.0
    if score < -tolerance:
        return 0.0
    return float(selector["boundary_probabilities"][key])


def batch_probability(
    forecasts: PredictionBatch, selector: Mapping[str, Any]
) -> FloatArray:
    if not selector["defined"]:
        raise MissingPredictedSupport("The frozen selector lacks predicted support")
    result = np.zeros(forecasts.size, dtype=np.float64)
    for group in (0, 1):
        for q in (0, 1):
            key = f"{group}:{q}"
            mask = (forecasts.group == group) & (forecasts.objectable == bool(q))
            gap = forecasts.ratio[mask] - selector["raw_ratio_thresholds"][key]
            tolerance = selector["ratio_tolerances"][key]
            result[mask] = np.where(
                gap > tolerance,
                1.0,
                np.where(
                    gap < -tolerance, 0.0, selector["boundary_probabilities"][key]
                ),
            )
    result[forecasts.value <= 0.0] = 0.0
    return result


def ratio_tolerances(thresholds: Mapping[str, float]) -> dict[str, float]:
    return {
        key: RATIO_ABSOLUTE_TOLERANCE + RATIO_RELATIVE_TOLERANCE * abs(value)
        for key, value in thresholds.items()
    }


def ratio_band_statistics(
    ratios: FloatArray, pi: FloatArray, threshold: float, floor: float
) -> dict[str, Any]:
    gap = ratios - threshold
    fractional = (pi > BOUND_TOLERANCE) & (pi < 1.0 - BOUND_TOLERANCE)
    lower_conflict = (pi <= BOUND_TOLERANCE) & (gap > 0.0)
    upper_conflict = (pi >= 1.0 - BOUND_TOLERANCE) & (gap < 0.0)
    fractional_gap = max_absolute(gap[fractional])
    lower_gap = float(np.max(gap[lower_conflict], initial=0.0))
    upper_gap = float(np.max(-gap[upper_conflict], initial=0.0))
    required = max(floor, fractional_gap, lower_gap, upper_gap)
    scale = max(
        1.0, abs(threshold), abs(threshold - required), abs(threshold + required)
    )
    roundoff = 64.0 * np.finfo(np.float64).eps * scale
    width = required + roundoff
    return {
        "absolute_relative_floor": floor,
        "bound_tolerance": BOUND_TOLERANCE,
        "roundoff_padding": roundoff,
        "material_fractional_rows": int(np.sum(fractional)),
        "lower_sign_conflict_rows": int(np.sum(lower_conflict)),
        "upper_sign_conflict_rows": int(np.sum(upper_conflict)),
        "maximum_fractional_ratio_gap": fractional_gap,
        "maximum_lower_positive_ratio_gap": lower_gap,
        "maximum_upper_negative_ratio_gap": upper_gap,
        "band_width": width,
        "band_rows": int(np.sum(np.abs(gap) <= width)),
    }


def normalized_column_impacts(problem: EmpiricalProblem) -> FloatArray:
    constraints = np.asarray(abs(problem.matrix).max(axis=0).toarray()).ravel()
    impacts = np.maximum(-problem.objective, constraints)
    if not np.isfinite(impacts).all() or np.any(impacts < 0.0):
        raise SelectorNumericalError("Nonfinite or negative forecast-column impact")
    return impacts


def band_coverage_statistics(
    problem: EmpiricalProblem,
    impacts: FloatArray,
    mask: NDArray[np.bool_],
    width: float,
    threshold: float,
    cutoff: float,
) -> dict[str, Any]:
    negligible = mask & (impacts <= cutoff)
    band = mask & (np.abs(problem.forecasts.ratio - threshold) <= width)
    return {
        "column_impact_cutoff": cutoff,
        "negligible_columns_excluded_from_band_coverage": int(np.sum(negligible)),
        "excluded_column_impact_sum": math.fsum(impacts[negligible]),
        "coverage_columns": int(np.sum(mask & ~negligible)),
        "band_rows": int(np.sum(band)),
        "negligible_columns_still_in_lp_and_replay": True,
    }


def adaptive_ratio_bands(
    problem: EmpiricalProblem, pi: FloatArray, thresholds: Mapping[str, float]
) -> tuple[dict[str, float], dict[str, Any]]:
    forecasts = problem.forecasts
    impacts = normalized_column_impacts(problem)
    cutoff = CHECK_TOLERANCE / (COLUMN_IMPACT_FACTOR * forecasts.size)
    floors = ratio_tolerances(thresholds)
    widths, diagnostics = {}, {}
    for group in (0, 1):
        for q in (0, 1):
            key = f"{group}:{q}"
            mask = (
                (forecasts.group == group)
                & (forecasts.objectable == bool(q))
                & (forecasts.value > 0.0)
            )
            coverage = mask & (impacts > cutoff)
            data = ratio_band_statistics(
                forecasts.ratio[coverage], pi[coverage], thresholds[key], floors[key]
            )
            data["covered_band_rows"] = data["band_rows"]
            data.update(
                band_coverage_statistics(
                    problem, impacts, mask, data["band_width"], thresholds[key], cutoff
                )
            )
            widths[key] = data["band_width"]
            diagnostics[key] = data
    return widths, diagnostics


def boundary_probabilities(
    forecasts: PredictionBatch, pi: FloatArray, selector: Mapping[str, Any]
) -> dict[str, float]:
    result = {}
    for group in (0, 1):
        for q in (0, 1):
            key = f"{group}:{q}"
            tied = (
                np.abs(forecasts.ratio - selector["raw_ratio_thresholds"][key])
                <= selector["ratio_tolerances"][key]
            )
            mask = (
                tied
                & (forecasts.value > 0.0)
                & (forecasts.group == group)
                & (forecasts.objectable == bool(q))
            )
            amount = math.fsum(forecasts.value[mask])
            numerator = math.fsum((forecasts.value * pi)[mask])
            result[key] = numerator / amount if amount > 0.0 else 0.0
    if any(not 0.0 <= value <= 1.0 for value in result.values()):
        raise SelectorNumericalError("Boundary probability leaves the unit interval")
    return result


def dual_certificate(
    problem: EmpiricalProblem, served: FloatArray, duals: Mapping[str, Any]
) -> dict[str, float]:
    values = np.asarray(
        [
            duals["budget"],
            duals["disparity_upper"],
            duals["disparity_lower"],
            *duals["group_caps"],
        ],
        dtype=np.float64,
    )
    if not np.isfinite(values).all() or np.any(values < 0.0):
        raise SelectorNumericalError("The dual certificate has invalid multipliers")
    profit = -problem.objective
    residual = profit - problem.matrix.T @ values
    upper = math.fsum(values * problem.rhs) + math.fsum(
        problem.upper * np.maximum(residual, 0.0)
    )
    capture = math.fsum(profit * served)
    return {
        "served_dual_upper_bound": upper,
        "served_normalized_objective": capture,
        "served_dual_signed_gap": upper - capture,
        "served_dual_gap_error": abs(upper - capture),
    }


def replay_receipt(
    problem: EmpiricalProblem,
    pi: FloatArray,
    served: FloatArray,
    duals: Mapping[str, Any],
) -> dict[str, Any]:
    expected = model_moments(problem.forecasts, pi, problem.normalization)
    actual = model_moments(problem.forecasts, served, problem.normalization)
    certificate = dual_certificate(problem, served, duals)
    errors = {
        "predicted_constraint_total_error": max_absolute(
            problem.matrix @ (served - pi)
        ),
        "normalized_objective_error": abs(float(problem.objective @ (served - pi))),
        "served_constraint_error": float(
            np.max(np.maximum(problem.matrix @ served - problem.rhs, 0.0), initial=0.0)
        ),
        "served_bound_error": float(
            max(
                np.max(-served, initial=0.0),
                np.max(served - problem.upper, initial=0.0),
            )
        ),
        "served_dual_gap_error": certificate["served_dual_gap_error"],
    }
    if (
        not all(math.isfinite(value) for value in errors.values())
        or max(errors.values()) > CHECK_TOLERANCE
    ):
        raise SelectorNumericalError(
            f"Frozen dual rule fails feasibility or optimal capture: {errors}"
        )
    return {
        "primal_moments": expected,
        "served_moments": actual,
        "primal_constraint_total_difference": max_absolute(
            problem.matrix @ (served - pi)
        ),
        **certificate,
        **errors,
    }


def selector_identity(scope: Scope, gamma: float, margin: float) -> dict[str, Any]:
    return {
        "kind": "dual",
        "dataset": scope.key[0],
        "seed": scope.key[1],
        "measurement_unit": "value",
        "source": scope.source,
        "input": scope.relative_input,
        "groups": list(scope.groups),
        "gamma": gamma,
        "margin": margin,
        "capture_floor": EVALUATION_FLOOR,
        "baseline_index": scope.baseline_index,
        "baseline_threshold": scope.baseline_threshold,
        "baseline_alpha": scope.baseline_alpha,
    }


def raw_thresholds(selector: Mapping[str, Any]) -> dict[str, float]:
    dual = selector["multipliers"]
    signed = dual["disparity_upper"] - dual["disparity_lower"]
    budget = (
        dual["budget"] * selector["model_loss_total"] / selector["model_value_total"]
    )
    result = {}
    for group in (0, 1):
        coefficient = dual["group_caps"][group] + (signed if group else -signed)
        contrast = (
            coefficient
            * selector["model_loss_total"]
            / selector["model_group_value_totals"][group]
        )
        result[f"{group}:0"] = budget
        result[f"{group}:1"] = budget + contrast
    return result


def fitted_target_fields(problem: EmpiricalProblem, optimum: float) -> dict[str, Any]:
    baseline = problem.baseline["captured_loss"]
    target_met = optimum >= (EVALUATION_FLOOR - TARGET_TOLERANCE) * baseline
    return {
        "model_optimum_capture": optimum,
        "model_baseline_budget_feasible": (
            problem.baseline["spend_fraction"] <= VALUE_CAP + TARGET_TOLERANCE
        ),
        "model_baseline_capture_positive": baseline > 0.0,
        "model_retained_capture_fraction": optimum / baseline
        if baseline > 0.0
        else None,
        "model_target_feasible": target_met,
        "fitted_capture_floor_met": target_met,
        "model_reference_D0": problem.baseline["D0"],
        "model_reference_D1": problem.baseline["D1"],
        "model_group_cap_limits": [float(value) for value in problem.rhs[3:]],
        "model_target_shortfall": max(0.0, EVALUATION_FLOOR * baseline - optimum),
    }


def fit_selector(
    forecasts: PredictionBatch, scope: Scope, gamma: float, margin: float
) -> dict[str, Any]:
    problem = make_problem(forecasts, scope, gamma, margin)
    result = solve(problem)
    kkt = kkt_receipt(problem, result)
    pi = np.clip(result.x, 0.0, problem.upper)
    selector = {
        **selector_identity(scope, gamma, margin),
        "defined": True,
        "support_status": "valid",
        "solver_status": 0,
        "baseline_fallback": False,
        "n_validation_rows": forecasts.size,
        "zero_predicted_value_rows": int(np.sum(forecasts.value == 0.0)),
        "solver_common_scale": float(forecasts.size),
        "model_value_total": problem.normalization["value_total"],
        "model_loss_total": problem.normalization["loss_total"],
        "model_group_value_totals": problem.normalization["group_value_totals"],
        "epsilon": float(problem.rhs[1]),
        "group_caps": [float(value) for value in problem.rhs[3:]],
        "multipliers": dual_multipliers(result),
        "model_baseline": problem.baseline,
        "kkt_receipt": kkt,
        "primal_probability_canonicalization_error": max_absolute(result.x - pi),
    }
    selector["raw_ratio_thresholds"] = raw_thresholds(selector)
    bands, diagnostics = adaptive_ratio_bands(
        problem, pi, selector["raw_ratio_thresholds"]
    )
    selector["ratio_tolerances"] = bands
    selector["numeric_ratio_band_diagnostics"] = diagnostics
    selector["numeric_bands_learned_from_validation"] = True
    selector["boundary_probabilities"] = boundary_probabilities(forecasts, pi, selector)
    served = batch_probability(forecasts, selector)
    selector["replay_receipt"] = replay_receipt(
        problem, result.x, served, selector["multipliers"]
    )
    optimum = (
        float(-result.fun)
        / problem.forecasts.size
        * problem.normalization["loss_total"]
    )
    selector.update(fitted_target_fields(problem, optimum))
    return selector


def missing_support_selector(
    scope: Scope, gamma: float, margin: float, message: str
) -> dict[str, Any]:
    return {
        **selector_identity(scope, gamma, margin),
        "defined": False,
        "support_status": "missing_predicted_group_support",
        "solver_status": None,
        "baseline_fallback": True,
        "failure_message": message,
    }


def fit_scope(forecasts: PredictionBatch, scope: Scope) -> list[dict[str, Any]]:
    result = []
    for gamma in GAMMAS:
        for margin in MARGINS:
            try:
                selector = fit_selector(forecasts, scope, gamma, margin)
            except MissingPredictedSupport as error:
                selector = missing_support_selector(scope, gamma, margin, str(error))
                selector["n_validation_rows"] = forecasts.size
                selector["zero_predicted_value_rows"] = int(
                    np.sum(forecasts.value == 0.0)
                )
            result.append(selector)
    return result


def numerical_summary(selectors: list[dict[str, Any]]) -> dict[str, Any]:
    valid = [row for row in selectors if row["defined"]]
    names = (
        [
            name
            for name in valid[0]["kkt_receipt"]
            if name.endswith("_error") or name == "primal_dual_gap"
        ]
        if valid
        else []
    )
    return {
        "selectors": len(selectors),
        "valid_selectors": len(valid),
        "missing_support_selectors": len(selectors) - len(valid),
        "maximum_kkt_errors": {
            name: max(row["kkt_receipt"][name] for row in valid) for name in names
        },
        "maximum_primal_constraint_total_difference": max(
            (
                row["replay_receipt"]["primal_constraint_total_difference"]
                for row in valid
            ),
            default=None,
        ),
        "maximum_replay_objective_error": max(
            (row["replay_receipt"]["normalized_objective_error"] for row in valid),
            default=None,
        ),
        "maximum_served_dual_gap_error": max(
            (row["replay_receipt"]["served_dual_gap_error"] for row in valid),
            default=None,
        ),
    }


def runtime_metadata() -> dict[str, Any]:
    return {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "command": [sys.executable, *sys.argv],
        "command_shell": shlex.join([sys.executable, *sys.argv]),
    }


def protocol_metadata(
    root: Path,
    revision: str,
    manifests: list[dict[str, Any]],
    selectors: list[dict[str, Any]],
    verification: bool,
) -> dict[str, Any]:
    return {
        "generator": GENERATOR,
        "schema_version": 1,
        "phase": "select",
        "complete": True,
        "n_cells": len({(row["dataset"], row["seed"]) for row in selectors}),
        "n_selectors": len(selectors),
        "verification_only": verification,
        "input_revision": revision,
        "inputs": manifests,
        "implementation": [
            {"path": name, "sha256": outcomes.digest(root / name)}
            for name in (GENERATOR, *HELPERS)
        ],
        "protocol": {"path": PROTOCOL, "sha256": outcomes.digest(root / PROTOCOL)},
        **runtime_metadata(),
        "solver": "highs-ds",
        "solver_presolve": False,
        "solver_tolerance": SOLVER_TOLERANCE,
        "checked_tolerance": CHECK_TOLERANCE,
        "target_tolerance": TARGET_TOLERANCE,
        "ratio_absolute_tolerance": RATIO_ABSOLUTE_TOLERANCE,
        "ratio_relative_tolerance": RATIO_RELATIVE_TOLERANCE,
        "numeric_band_bound_tolerance": BOUND_TOLERANCE,
        "band_coverage_column_impact_cutoff": "checked_tolerance / (16 * n_validation_rows)",
        "maximum_total_excluded_column_impact_bound": CHECK_TOLERANCE
        / COLUMN_IMPACT_FACTOR,
        "solver_scaling": "Multiply objective and every inequality row/RHS by the validation row count; inequality multipliers stay unchanged.",
        "serving_score": "Raw ratio minus frozen group/objectable threshold; positive predicted value changes do not affect classification.",
        "gamma_scope": list(GAMMAS),
        "margin_scope": list(MARGINS),
        "primary_gamma": 0.50,
        "primary_margin": 0.0,
        "capture_floor": EVALUATION_FLOOR,
        "value_cap": VALUE_CAP,
        "objective": "maximum_sum_predicted_loss_without_capture_floor",
        "prediction_fields_only": True,
        "heldout_outcomes_parsed": False,
        "settled_candidate_values_used_for_new_score": False,
        "legacy_reference_calibration": "Original baseline threshold/thinning and harm/net-harm references used observed validation value in their historical construction; we preserve those fixed inputs.",
        "boundary_rule": "Four V-frozen ratio bands cover material-impact fractional primal probabilities and bound/sign conflicts. Numerically negligible columns cannot widen bands but remain in the LP, serving replay, constraints and capture certificate. Band probabilities match predicted-value-weighted primal mass. Zero predicted value passes. Independent feasibility and capture checks remain fatal.",
        "numerical": numerical_summary(selectors),
        "selectors": selectors,
    }


def csv_identity(selector: Mapping[str, Any]) -> dict[str, Any]:
    names = (
        "kind",
        "dataset",
        "seed",
        "source",
        "input",
        "measurement_unit",
        "gamma",
        "margin",
        "capture_floor",
        "baseline_index",
        "baseline_threshold",
        "baseline_alpha",
        "defined",
        "support_status",
        "solver_status",
        "baseline_fallback",
        "n_validation_rows",
        "zero_predicted_value_rows",
        "model_value_total",
        "model_loss_total",
        "model_optimum_capture",
        "model_retained_capture_fraction",
        "model_baseline_budget_feasible",
        "model_baseline_capture_positive",
        "fitted_capture_floor_met",
        "model_target_shortfall",
        "epsilon",
        "model_reference_D0",
        "model_reference_D1",
    )
    return {name: selector.get(name) for name in names}


def csv_model_fields(selector: Mapping[str, Any]) -> dict[str, Any]:
    baseline = selector.get("model_baseline", {})
    result = {
        "model_baseline_spend": baseline.get("spend_fraction"),
        "model_baseline_capture": baseline.get("captured_loss"),
    }
    groups = selector.get("model_group_value_totals", [None, None])
    limits = selector.get("model_group_cap_limits", [None, None])
    for group in (0, 1):
        result[f"model_group_{group}_value_total"] = groups[group]
        result[f"model_group_{group}_cap_limit"] = limits[group]
    return result


def csv_policy_fields(selector: Mapping[str, Any]) -> dict[str, Any]:
    multipliers = selector.get("multipliers", {})
    result = {
        name + "_multiplier": multipliers.get(name)
        for name in ("budget", "disparity_upper", "disparity_lower")
    }
    caps = multipliers.get("group_caps", [None, None])
    for group in (0, 1):
        result[f"group_cap_{group}_multiplier"] = caps[group]
        for q in (0, 1):
            key = f"{group}:{q}"
            for name in (
                "raw_ratio_thresholds",
                "ratio_tolerances",
                "boundary_probabilities",
            ):
                result[f"{name}_{group}_{q}"] = selector.get(name, {}).get(key)
    return result


def csv_band_coverage_fields(bands: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "negligible_columns_excluded_from_band_coverage": sum(
            value["negligible_columns_excluded_from_band_coverage"]
            for value in bands.values()
        )
        if bands
        else None,
        "excluded_band_coverage_column_impact_sum": math.fsum(
            value["excluded_column_impact_sum"] for value in bands.values()
        )
        if bands
        else None,
    }


def validation_selection_row(selector: Mapping[str, Any]) -> dict[str, Any]:
    kkt = selector.get("kkt_receipt", {})
    replay = selector.get("replay_receipt", {})
    kkt_errors = [
        value
        for name, value in kkt.items()
        if name.endswith("_error") or name == "primal_dual_gap"
    ]
    replay_errors = [value for name, value in replay.items() if name.endswith("_error")]
    bands = selector.get("numeric_ratio_band_diagnostics", {})
    band_widths = [value["band_width"] for value in bands.values()]
    return {
        **csv_identity(selector),
        **csv_model_fields(selector),
        **csv_policy_fields(selector),
        **csv_band_coverage_fields(bands),
        "numeric_bands_learned_from_validation": selector.get(
            "numeric_bands_learned_from_validation"
        ),
        "maximum_numeric_band_width": max(band_widths) if band_widths else None,
        "numeric_band_rows": sum(value["band_rows"] for value in bands.values())
        if bands
        else None,
        "material_fractional_rows": sum(
            value["material_fractional_rows"] for value in bands.values()
        )
        if bands
        else None,
        "lower_sign_conflict_rows": sum(
            value["lower_sign_conflict_rows"] for value in bands.values()
        )
        if bands
        else None,
        "upper_sign_conflict_rows": sum(
            value["upper_sign_conflict_rows"] for value in bands.values()
        )
        if bands
        else None,
        "maximum_kkt_error": max(kkt_errors) if kkt_errors else None,
        "maximum_replay_error": max(replay_errors) if replay_errors else None,
    }


def write_outputs(root: Path, metadata: dict[str, Any], prefix: str) -> None:
    directory = root / "results" / "csvs"
    path = directory / f"{prefix}_validation_freeze.json"
    selections = directory / f"{prefix}_validation_selections.csv"
    rows = [validation_selection_row(selector) for selector in metadata["selectors"]]
    with selections.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    summary = directory / f"{prefix}_numerical_summary.json"
    summary.write_text(
        json.dumps(metadata["numerical"], indent=2, sort_keys=True, allow_nan=False)
        + "\n"
    )
    metadata["outputs"] = [
        {"path": str(item.relative_to(root)), "sha256": outcomes.digest(item)}
        for item in (selections, summary)
    ]
    path.write_text(
        json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    LOGGER.info("Frozen direct rules: %s", metadata["numerical"])


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--input-revision", default="HEAD")
    parser.add_argument("--output-prefix", default="bandha_direct_selector")
    parser.add_argument("--verification-only", action="store_true")
    parser.add_argument("--canary-cell", action="append", default=[])
    result = parser.parse_args()
    if not result.output_prefix.startswith("bandha_direct_selector") or any(
        value not in "abcdefghijklmnopqrstuvwxyz0123456789_"
        for value in result.output_prefix
    ):
        raise ValueError("Outputs must remain in the direct-selector area")
    if result.canary_cell and not result.verification_only:
        raise ValueError("Partial-cell runs must be verification-only")
    return result


def main() -> None:
    args = arguments()
    root = args.root.resolve()
    revision = outcomes.git_output(root, ["rev-parse", args.input_revision])
    if not args.verification_only:
        outcomes.committed_input(root, GENERATOR, "HEAD")
    protocol_identity = outcomes.committed_input(root, PROTOCOL, "HEAD")
    code = [
        {"path": name, "sha256": outcomes.digest(root / name)}
        for name in (GENERATOR, *HELPERS)
    ]
    scopes, manifests = load_scopes(root, revision)
    if args.canary_cell:
        keys = {tuple(value.rsplit(":", 1)) for value in args.canary_cell}
        scopes = {key: scope for key, scope in scopes.items() if key[:2] in keys}
        if {key[:2] for key in scopes} != keys:
            raise ValueError("Unknown canary cell")
    forecasts = load_validation_forecasts(root, scopes)
    selectors = []
    for key, scope in sorted(scopes.items()):
        selectors.extend(fit_scope(forecasts[key], scope))
        LOGGER.info("Completed predicted-coefficient LP cell: %s", key)
    metadata = protocol_metadata(
        root, revision, manifests, selectors, args.verification_only
    )
    metadata["implementation_revision"] = outcomes.git_output(
        root, ["rev-parse", "HEAD"]
    )
    metadata["inputs"].append(protocol_identity)
    if metadata["implementation"] != code:
        raise ValueError(
            "Source implementation changed during the prediction-only solve"
        )
    for item in metadata["inputs"]:
        if outcomes.digest(root / item["path"]) != item["sha256"]:
            raise ValueError("Frozen input or protocol changed during the solve")
    if not args.verification_only and (
        metadata["n_cells"] != 240 or metadata["n_selectors"] != 2400
    ):
        raise ValueError("The final selector freeze omits declared cells or targets")
    write_outputs(root, metadata, args.output_prefix)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    main()
