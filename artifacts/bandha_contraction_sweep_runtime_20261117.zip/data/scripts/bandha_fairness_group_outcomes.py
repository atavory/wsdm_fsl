"""Summarize group outcomes of the existing frozen normalized policies.

We reconstruct only the zero-penalty baseline from the committed candidate
inputs, using its frozen threshold and thinning probability. We obtain each
selected policy's group amounts from the existing selected-component CSV and
combine the frozen weights for the group-blind mixture. We do not select
policies, fit predictors, enlarge policy banks, or use the uncompressed
validation-freeze file.

We retain baseline-zero-gap cells. All summaries are descriptive. The report
separates absolute gap reduction from increases in either group's normalized
objections and reports the actual held-out capture and blocked-value spend.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
import platform
import shlex
import statistics
import subprocess
import sys
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import bandha_cached_group_awareness as legacy


CaseKey = tuple[str, str, str]
CellKey = tuple[str, str]
Candidate = tuple[str, float, float, float, float, bool]
Cases = Mapping[CaseKey, Mapping[str, Any]]
Baselines = Mapping[CellKey, "BaselineAmounts"]
PointKey = tuple[str, str, str, int, str]
MassPoints = Mapping[PointKey, list[dict[str, Any]]]


MASS_NAMES = ("total_mass", "potential_mass", "selected_mass", "complaint_mass")
UNITS = ("count", "value", "loss")
OUTCOME_ID_FIELDS = (
    "dataset",
    "seed",
    "measurement_unit",
    "capture_floor",
    "policy_family",
)
SOURCE_INPUTS = (
    "results/bandha_normalized_prices/validation_freeze.json.gz",
    "results/bandha_normalized_prices/heldout_comparison.csv",
    "results/bandha_normalized_prices/selected_component_group_masses.csv",
    "scripts/bandha_cached_group_awareness.py",
    "scripts/bandha_normalized_group_prices.py",
)
OUTCOME_FIELDS = (
    "input",
    "source",
    "dataset",
    "seed",
    "measurement_unit",
    "capture_floor",
    "policy_family",
    "group_0",
    "group_1",
    "validation_high_group",
    "baseline_test_high_group",
    "baseline_status",
    "bank_components",
    "baseline_D0",
    "baseline_D1",
    "D0",
    "D1",
    "delta_D0",
    "delta_D1",
    "baseline_signed_gap",
    "signed_gap",
    "baseline_absolute_gap",
    "absolute_gap",
    "absolute_gap_reduction",
    "reported_baseline_absolute_gap",
    "closure",
    "baseline_aggregate_objection_mass",
    "aggregate_objection_mass",
    "aggregate_objection_mass_change",
    "baseline_aggregate_objection_level",
    "aggregate_objection_level",
    "aggregate_objection_level_change",
    "group_0_total_mass",
    "group_1_total_mass",
    "group_0_potential_mass",
    "group_1_potential_mass",
    "group_0_selected_mass",
    "group_1_selected_mass",
    "group_0_complaint_mass",
    "group_1_complaint_mass",
    "baseline_group_0_complaint_mass",
    "baseline_group_1_complaint_mass",
    "baseline_loss_capture_fraction",
    "loss_capture_fraction",
    "retained_loss_capture_fraction",
    "baseline_captured_loss",
    "captured_loss",
    "test_total_loss",
    "test_total_value",
    "baseline_blocked_value_fraction",
    "blocked_value_fraction",
    "baseline_blocked_value",
    "blocked_value",
    "validation_retained_capture_fraction",
    "validation_blocked_value_fraction",
    "capture_floor_met",
    "value_cap_met",
    "both_constraints_met",
    "validation_capture_floor_met",
    "validation_value_cap_met",
    "baseline_zero_gap",
    "group_0_increased",
    "group_1_increased",
    "any_group_increased",
    "aggregate_objections_increased",
    "gap_reduced",
    "gap_reduced_without_group_increase",
    "gap_reduced_with_group_increase",
    "gap_reduced_only_by_group_increase",
    "baseline_high_group_relief",
    "baseline_low_group_increase",
    "group_order_reversed",
)
SUMMARY_FIELDS = (
    "source",
    "measurement_unit",
    "capture_floor",
    "policy_family",
    "n_cells",
    "baseline_zero_gap_cells",
    "gap_reduced_cells",
    "any_group_increased_cells",
    "gap_reduced_without_group_increase_cells",
    "gap_reduced_with_group_increase_cells",
    "gap_reduced_only_by_group_increase_cells",
    "aggregate_objections_increased_cells",
    "capture_floor_met_cells",
    "value_cap_met_cells",
    "both_constraints_met_cells",
    "gap_reduced_without_increase_and_constraints_met_cells",
    "median_absolute_gap",
    "median_absolute_gap_reduction",
    "median_aggregate_objection_level_change",
    "median_retained_loss_capture_fraction",
    "median_blocked_value_fraction",
)


@dataclass
class StableSum:
    total: float = 0.0
    correction: float = 0.0

    def add(self, value: float) -> None:
        updated = self.total + value
        if abs(self.total) >= abs(value):
            self.correction += (self.total - updated) + value
        else:
            self.correction += (value - updated) + self.total
        self.total = updated

    def value(self) -> float:
        return self.total + self.correction


@dataclass
class UnitAmounts:
    total: StableSum = field(default_factory=StableSum)
    potential: StableSum = field(default_factory=StableSum)
    selected: StableSum = field(default_factory=StableSum)
    complaint: StableSum = field(default_factory=StableSum)

    def add(self, amount: float, objectable: bool, blocked: bool) -> None:
        self.total.add(amount)
        if objectable:
            self.potential.add(amount)
        if blocked:
            self.selected.add(amount)
        if objectable and blocked:
            self.complaint.add(amount)

    def mass(self, group: str, alpha: float) -> dict[str, Any]:
        return {
            "group": group,
            "total_mass": self.total.value(),
            "potential_mass": self.potential.value(),
            "selected_mass": self.selected.value() * alpha,
            "complaint_mass": self.complaint.value() * alpha,
        }


@dataclass
class BaselineAmounts:
    groups: tuple[str, str]
    threshold: float
    alpha: float
    amounts: dict[tuple[str, str], UnitAmounts] = field(default_factory=dict)
    n_candidates: int = 0

    def __post_init__(self) -> None:
        self.amounts = {
            (group, unit): UnitAmounts() for group in self.groups for unit in UNITS
        }

    def add(self, candidate: tuple[str, float, float, float, float, bool]) -> None:
        score = value_unit_score(candidate)
        self.add_masked(candidate, score >= self.threshold and score > 0.0)

    def add_masked(
        self, candidate: tuple[str, float, float, float, float, bool], blocked: bool
    ) -> None:
        group, value, loss, _, _, objectable = candidate
        if group not in self.groups:
            raise ValueError(f"Unexpected group {group!r}; expected {self.groups}")
        for unit, amount in zip(UNITS, (1.0, value, loss)):
            self.amounts[(group, unit)].add(amount, objectable, blocked)
        self.n_candidates += 1

    def masses(self, unit: str) -> list[dict[str, Any]]:
        return [
            self.amounts[(group, unit)].mass(group, self.alpha) for group in self.groups
        ]

    def total(self, unit: str) -> float:
        return math.fsum(
            self.amounts[(group, unit)].total.value() for group in self.groups
        )

    def selected(self, unit: str) -> float:
        return (
            math.fsum(
                self.amounts[(group, unit)].selected.value() for group in self.groups
            )
            * self.alpha
        )


@dataclass
class Integrity:
    relative_tolerance: float
    absolute_tolerance: float
    comparisons: int = 0
    maximum_absolute_errors: dict[str, float] = field(default_factory=dict)

    def equal(self, actual: float, expected: float, name: str, key: Any) -> None:
        if not math.isfinite(actual) or not math.isfinite(expected):
            raise ValueError(f"Nonfinite {name} for {key}: {actual}, {expected}")
        error = abs(actual - expected)
        self.maximum_absolute_errors[name] = max(
            self.maximum_absolute_errors.get(name, 0.0), error
        )
        self.comparisons += 1
        if not math.isclose(
            actual,
            expected,
            rel_tol=self.relative_tolerance,
            abs_tol=self.absolute_tolerance,
        ):
            raise ValueError(
                f"Inconsistent {name} for {key}: {actual!r} != {expected!r}"
            )


def git_output(root: Path, arguments: list[str]) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *arguments], check=True, capture_output=True, text=True
    ).stdout.strip()


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def committed_input(root: Path, relative: str, revision: str) -> dict[str, Any]:
    path = root / relative
    expected = git_output(root, ["rev-parse", f"{revision}:{relative}"])
    actual = git_output(root, ["hash-object", "--", relative])
    if actual != expected:
        raise ValueError(f"Input differs from committed revision: {relative}")
    return {
        "path": relative,
        "sha256": digest(path),
        "git_blob": actual,
        "bytes": path.stat().st_size,
    }


def load_inputs(
    root: Path, revision: str
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    manifests = [committed_input(root, name, revision) for name in SOURCE_INPUTS]
    with gzip.open(root / SOURCE_INPUTS[0], "rt") as handle:
        frozen = json.load(handle)
    for item in frozen["inputs"]:
        manifest = committed_input(root, item["path"], revision)
        if manifest["sha256"] != item["sha256"]:
            raise ValueError(
                f"Candidate hash differs from validation freeze: {item['path']}"
            )
        manifests.append(manifest)
    return frozen, manifests


def unique_rows(
    rows: Iterable[dict[str, str]], names: tuple[str, ...]
) -> dict[tuple[str, ...], dict[str, str]]:
    output = {}
    for row in rows:
        key = tuple(row[name] for name in names)
        if key in output:
            raise ValueError(f"Duplicate input key {key}")
        output[key] = row
    return output


def load_comparison(root: Path) -> dict[tuple[str, str, str, float], dict[str, str]]:
    with (root / SOURCE_INPUTS[1]).open(newline="") as handle:
        rows = unique_rows(
            csv.DictReader(handle), ("dataset", "seed", "currency", "capture_floor")
        )
    output = {}
    for key, row in rows.items():
        numeric_key = (*key[:3], float(key[3]))
        if numeric_key in output:
            raise ValueError(f"Duplicate numeric comparison key {numeric_key}")
        output[numeric_key] = row
    return output


def load_mass_rows(
    root: Path,
) -> dict[tuple[str, str, str, int, str], list[dict[str, Any]]]:
    names = ("dataset", "seed", "currency", "bank_index", "split", "group")
    with (root / SOURCE_INPUTS[2]).open(newline="") as handle:
        rows = unique_rows(csv.DictReader(handle), names)
    output: dict[tuple[str, str, str, int, str], list[dict[str, Any]]] = defaultdict(
        list
    )
    for key, row in rows.items():
        point_key = (*key[:3], int(key[3]), key[4])
        output[point_key].append(
            {
                "group": row["group"],
                "family": row["family"],
                "lambda": float(row["lambda"]),
                **{name: float(row[name]) for name in MASS_NAMES},
            }
        )
    return dict(output)


def baseline_point(case: Mapping[str, Any]) -> Mapping[str, Any]:
    points = [
        point
        for point in case["bank"]
        if point["family"] == "account" and point["lambda"] == 0.0
    ]
    if len(points) != 1:
        raise ValueError("The frozen case lacks a unique zero-penalty account policy")
    return points[0]


def index_cases(
    frozen: Mapping[str, Any],
) -> dict[tuple[str, str, str], Mapping[str, Any]]:
    output = {}
    for case in frozen["cases"]:
        if case["status"] != "frozen":
            raise ValueError(f"Unavailable frozen case: {case['status']}")
        key = (case["dataset"], str(case["seed"]), case["currency"])
        if key in output:
            raise ValueError(f"Duplicate frozen case {key}")
        if len(case["groups"]) != 2 or case["high"] not in (0, 1):
            raise ValueError(f"Invalid group structure {key}")
        output[key] = case
    return output


def baseline_accumulators(
    cases: Mapping[tuple[str, str, str], Mapping[str, Any]],
) -> dict[tuple[str, str], BaselineAmounts]:
    output = {}
    for key, case in cases.items():
        cell_key = key[:2]
        point = baseline_point(case)
        settings = (
            tuple(case["groups"]),
            point["threshold"],
            case["baseline"]["alpha"],
        )
        if cell_key in output:
            existing = output[cell_key]
            if (existing.groups, existing.threshold, existing.alpha) != settings:
                raise ValueError(
                    f"Baseline policy differs across measurement units: {cell_key}"
                )
        else:
            output[cell_key] = BaselineAmounts(*settings)
    return output


def candidate_key(row: Mapping[str, str], compact: bool) -> tuple[str, str, str, float]:
    if compact:
        return (
            legacy.decode("dataset", row["d"]),
            row["s"],
            legacy.decode("split", row["p"]),
            float(row["t"]),
        )
    return (
        row["dataset"],
        row["seed"],
        row.get("sample_split", row.get("split", "")),
        float(row["target"]),
    )


def candidate_values(
    row: Mapping[str, str], compact: bool
) -> tuple[str, float, float, float, float, bool]:
    if compact:
        group = legacy.decode("group", row["g"])
        value, loss, logit, predicted_value = (
            float(row[name]) for name in ("A", "B", "q", "ah")
        )
        objectable = not (float(row["h"]) > 0.5 and float(row["nh"]) > 0.5)
    else:
        group = row["group"]
        value, loss, logit = (float(row[name]) for name in ("value", "loss", "score"))
        predicted_value = float(row.get("estimated_value", row.get("a_hat", "0")))
        harm = float(row.get("selected_criterion_harm", row.get("selected_harm", "0")))
        net_harm = float(
            row.get("selected_criterion_net_harm", row.get("selected_net_harm", "0"))
        )
        objectable = not (harm > 0.5 and net_harm > 0.5)
    if not all(
        math.isfinite(number) for number in (value, loss, logit, predicted_value)
    ):
        raise ValueError("Nonfinite frozen candidate coefficient")
    return (
        group,
        max(value, 0.0),
        max(loss, 0.0),
        logit,
        max(predicted_value, 0.0),
        objectable,
    )


def value_unit_score(
    candidate: tuple[str, float, float, float, float, bool],
    penalty_coefficient: float = 0.0,
) -> float:
    _, _, _, logit, predicted_value, objectable = candidate
    ratio = math.exp(max(-50.0, min(50.0, logit)))
    if predicted_value <= 0.0:
        return ratio
    adjusted_loss = (
        ratio * predicted_value - penalty_coefficient * predicted_value * objectable
    )
    return max(adjusted_loss, 0.0) / predicted_value


def iter_test_candidates(
    path: Path, cells: set[tuple[str, str]]
) -> Iterable[tuple[tuple[str, str], tuple[str, float, float, float, float, bool]]]:
    with gzip.open(path, "rt", newline="") as handle:
        reader = csv.DictReader(handle)
        compact = "d" in (reader.fieldnames or ())
        for row in reader:
            dataset, seed, split, target = candidate_key(row, compact)
            if (
                (dataset, seed) in cells
                and split.lower() == "test"
                and math.isclose(target, 0.1)
            ):
                yield (dataset, seed), candidate_values(row, compact)


def reconstruct_baselines(
    root: Path, cases: Mapping[tuple[str, str, str], Mapping[str, Any]]
) -> dict[tuple[str, str], BaselineAmounts]:
    output = baseline_accumulators(cases)
    by_input: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for key, case in cases.items():
        by_input[case["input"]].add(key[:2])
    for relative, cells in sorted(by_input.items()):
        for key, candidate in iter_test_candidates(root / relative, cells):
            output[key].add(candidate)
        print(f"Baseline reconstruction: {relative}", flush=True)
    if any(value.n_candidates == 0 for value in output.values()):
        raise ValueError("At least one frozen baseline has no matching test candidates")
    return output


def ordered_masses(
    masses: Iterable[Mapping[str, Any]], groups: Iterable[str]
) -> list[dict[str, Any]]:
    by_group = {str(mass["group"]): dict(mass) for mass in masses}
    names = tuple(groups)
    if len(by_group) != 2 or set(by_group) != set(names):
        raise ValueError(f"Incomplete group amounts; expected {names}")
    for group in names:
        mass = by_group[group]
        if not all(
            math.isfinite(float(mass[name])) and float(mass[name]) >= 0.0
            for name in MASS_NAMES
        ):
            raise ValueError(f"Invalid group amounts for {group}")
        if (
            not 0
            <= mass["complaint_mass"]
            <= min(mass["potential_mass"], mass["selected_mass"]) + 1e-6
        ):
            raise ValueError(f"Complaint amount exceeds its support for {group}")
        if mass["total_mass"] <= 0.0:
            raise ValueError(f"Unavailable positive group denominator for {group}")
    return [by_group[group] for group in names]


def levels(masses: Iterable[Mapping[str, Any]]) -> tuple[float, float]:
    values = list(masses)
    return float(values[0]["complaint_mass"]) / float(values[0]["total_mass"]), float(
        values[1]["complaint_mass"]
    ) / float(values[1]["total_mass"])


def mass_metrics(masses: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    values = list(masses)
    d0, d1 = levels(values)
    total = math.fsum(float(mass["total_mass"]) for mass in values)
    complaint = math.fsum(float(mass["complaint_mass"]) for mass in values)
    return {
        "D0": d0,
        "D1": d1,
        "signed_gap": d1 - d0,
        "absolute_gap": abs(d1 - d0),
        "aggregate_objection_mass": complaint,
        "aggregate_objection_level": complaint / total,
    }


def verify_mass_points(
    cases: Mapping[tuple[str, str, str], Mapping[str, Any]],
    baselines: Mapping[tuple[str, str], BaselineAmounts],
    points: Mapping[tuple[str, str, str, int, str], list[dict[str, Any]]],
    integrity: Integrity,
) -> None:
    for key, raw in points.items():
        dataset, seed, unit, index, split = key
        case = cases[(dataset, seed, unit)]
        point = case["bank"][index]
        masses = ordered_masses(raw, case["groups"])
        if any(
            mass["family"] != point["family"] or mass["lambda"] != point["lambda"]
            for mass in masses
        ):
            raise ValueError(f"Selected amounts disagree with the frozen policy {key}")
        expected = (
            point["validation"]["masses"]
            if split == "validation"
            else baselines[(dataset, seed)].masses(unit)
        )
        expected = ordered_masses(expected, case["groups"])
        fields = MASS_NAMES if split == "validation" else MASS_NAMES[:2]
        for actual_group, expected_group in zip(masses, expected):
            for name in fields:
                integrity.equal(
                    float(actual_group[name]), float(expected_group[name]), name, key
                )


def components(
    case: Mapping[str, Any], floor: float, family: str
) -> list[tuple[int, float]]:
    if family == "baseline":
        index = next(
            index
            for index, point in enumerate(case["bank"])
            if point["family"] == "account" and point["lambda"] == 0.0
        )
        return [(index, 1.0)]
    if family == "group_blind_mixture":
        mixture = case["lp"][str(floor)]
        if mixture is None:
            raise ValueError("The frozen mixture is unavailable")
        values = [
            (int(index), float(weight)) for index, weight in mixture["components"]
        ]
        if min(weight for _, weight in values) < 0.0 or not math.isclose(
            math.fsum(weight for _, weight in values), 1.0, abs_tol=1e-7
        ):
            raise ValueError("Invalid frozen mixture weights")
        return values
    name = "account" if family == "group_blind" else "group"
    index = case["selected"][f"{floor}:{name}"]
    if index is None:
        raise ValueError(f"The frozen {family} selection is unavailable")
    return [(int(index), 1.0)]


def combine_masses(
    case: Mapping[str, Any],
    key: tuple[str, str, str],
    chosen: Iterable[tuple[int, float]],
    points: Mapping[tuple[str, str, str, int, str], list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    values = [
        (ordered_masses(points[(*key, index, "test")], case["groups"]), weight)
        for index, weight in chosen
    ]
    output = []
    for group_index, group in enumerate(case["groups"]):
        result = {"group": group}
        for name in MASS_NAMES:
            if name in MASS_NAMES[:2]:
                result[name] = values[0][0][group_index][name]
            else:
                result[name] = math.fsum(
                    float(masses[group_index][name]) * weight
                    for masses, weight in values
                )
        output.append(result)
    return ordered_masses(output, case["groups"])


def validation_metrics(
    case: Mapping[str, Any], floor: float, tag: str, chosen: list[tuple[int, float]]
) -> tuple[float, float]:
    if tag == "lp":
        values = case["lp"][str(floor)]
        return values["validation_capture_fraction"], values["validation_budget"]
    values = case["bank"][chosen[0][0]]["validation"]
    return values["capture"] / case["baseline"]["capture"], values["budget"]


def selected_metrics(
    comparison: Mapping[str, str],
    case: Mapping[str, Any],
    floor: float,
    family: str,
    chosen: list[tuple[int, float]],
) -> dict[str, float]:
    if family == "baseline":
        return {
            "capture": float(comparison["baseline_test_capture"]),
            "retained": 1.0,
            "budget": float("nan"),
            "validation_retained": 1.0,
            "validation_budget": case["baseline"]["budget"],
            "closure": 0.0,
            "expected_gap": float(comparison["baseline_test_gap"]),
        }
    tag = {
        "group_blind": "account",
        "group_aware": "group",
        "group_blind_mixture": "lp",
    }[family]
    val_retained, val_budget = validation_metrics(case, floor, tag, chosen)
    retained = float(comparison[tag + "_test_capture_fraction"])
    return {
        "capture": retained * float(comparison["baseline_test_capture"]),
        "retained": retained,
        "budget": float(comparison[tag + "_test_value_budget"]),
        "validation_retained": val_retained,
        "validation_budget": val_budget,
        "closure": float(comparison[tag + "_closure"]),
        "expected_gap": float(comparison[tag + "_test_gap"]),
    }


def effect_flags(
    base: Mapping[str, float], policy: Mapping[str, float], tolerance: float
) -> dict[str, Any]:
    delta0, delta1 = policy["D0"] - base["D0"], policy["D1"] - base["D1"]
    increased = delta0 > tolerance or delta1 > tolerance
    reduced = base["absolute_gap"] - policy["absolute_gap"] > tolerance
    high = 0 if base["D0"] >= base["D1"] else 1
    high_relief = base[f"D{high}"] - policy[f"D{high}"]
    low_increase = policy[f"D{1 - high}"] - base[f"D{1 - high}"]
    return {
        "delta_D0": delta0,
        "delta_D1": delta1,
        "baseline_zero_gap": base["absolute_gap"] <= tolerance,
        "group_0_increased": delta0 > tolerance,
        "group_1_increased": delta1 > tolerance,
        "any_group_increased": increased,
        "aggregate_objections_increased": policy["aggregate_objection_level"]
        - base["aggregate_objection_level"]
        > tolerance,
        "gap_reduced": reduced,
        "gap_reduced_without_group_increase": reduced and not increased,
        "gap_reduced_with_group_increase": reduced and increased,
        "gap_reduced_only_by_group_increase": reduced
        and high_relief <= tolerance
        and low_increase > tolerance,
        "baseline_high_group_relief": high_relief,
        "baseline_low_group_increase": low_increase,
        "group_order_reversed": base["signed_gap"] * policy["signed_gap"]
        < -(tolerance * tolerance),
    }


def verify_outcome(
    row: Mapping[str, Any],
    expected: Mapping[str, str],
    metrics: Mapping[str, float],
    masses: list[dict[str, Any]],
    integrity: Integrity,
) -> None:
    key = tuple(row[name] for name in OUTCOME_ID_FIELDS)
    integrity.equal(
        row["baseline_loss_capture_fraction"],
        float(expected["baseline_test_capture"]),
        "baseline_capture",
        key,
    )
    integrity.equal(
        row["baseline_absolute_gap"],
        float(expected["baseline_test_gap"]),
        "baseline_gap",
        key,
    )
    integrity.equal(row["absolute_gap"], metrics["expected_gap"], "selected_gap", key)
    reported_gap = float(expected["baseline_test_gap"])
    closure = (
        1.0 - row["absolute_gap"] / reported_gap
        if reported_gap != 0.0
        else float(row["absolute_gap"] == 0.0)
    )
    if row["policy_family"] != "baseline":
        integrity.equal(closure, metrics["closure"], "selected_closure", key)
    unit = row["measurement_unit"]
    selected = math.fsum(float(mass["selected_mass"]) for mass in masses)
    if unit == "value":
        integrity.equal(
            selected / row["test_total_value"],
            row["blocked_value_fraction"],
            "selected_value_budget",
            key,
        )
    if unit == "loss":
        integrity.equal(
            selected / row["test_total_loss"],
            row["loss_capture_fraction"],
            "selected_loss_capture",
            key,
        )
    if not row["validation_capture_floor_met"] or not row["validation_value_cap_met"]:
        raise ValueError(f"Frozen selection violates its validation constraints: {key}")


def identity_fields(
    key: CaseKey,
    case: Mapping[str, Any],
    floor: float,
    family: str,
    comparison: Mapping[str, str],
    base: Mapping[str, float],
    chosen: list[tuple[int, float]],
) -> dict[str, Any]:
    return {
        "input": case["input"],
        "source": comparison["source"],
        "dataset": key[0],
        "seed": key[1],
        "measurement_unit": key[2],
        "capture_floor": floor,
        "policy_family": family,
        "group_0": case["groups"][0],
        "group_1": case["groups"][1],
        "validation_high_group": case["groups"][case["high"]],
        "baseline_test_high_group": case["groups"][
            0 if base["D0"] >= base["D1"] else 1
        ],
        "baseline_status": "reconstructed_from_committed_candidates",
        "bank_components": json.dumps(chosen, separators=(",", ":")),
    }


def capture_fields(
    baseline: BaselineAmounts,
    metrics: Mapping[str, float],
    floor: float,
    tolerance: float,
    cap: float,
) -> dict[str, Any]:
    total_value, total_loss = baseline.total("value"), baseline.total("loss")
    capture = baseline.selected("loss") / total_loss
    budget = baseline.selected("value") / total_value
    capture_met = metrics["retained"] >= floor - tolerance
    cap_met = metrics["budget"] <= cap + tolerance
    return {
        "baseline_loss_capture_fraction": capture,
        "loss_capture_fraction": metrics["capture"],
        "retained_loss_capture_fraction": metrics["retained"],
        "baseline_captured_loss": capture * total_loss,
        "captured_loss": metrics["capture"] * total_loss,
        "test_total_loss": total_loss,
        "test_total_value": total_value,
        "baseline_blocked_value_fraction": budget,
        "blocked_value_fraction": metrics["budget"],
        "baseline_blocked_value": budget * total_value,
        "blocked_value": metrics["budget"] * total_value,
        "validation_retained_capture_fraction": metrics["validation_retained"],
        "validation_blocked_value_fraction": metrics["validation_budget"],
        "capture_floor_met": capture_met,
        "value_cap_met": cap_met,
        "both_constraints_met": capture_met and cap_met,
        "validation_capture_floor_met": metrics["validation_retained"] >= floor - 1e-7,
        "validation_value_cap_met": metrics["validation_budget"] <= cap + 1e-7,
    }


def objection_fields(
    base: Mapping[str, float],
    policy: Mapping[str, float],
    reported_gap: float,
    closure: float,
) -> dict[str, Any]:
    return {
        **policy,
        **{f"baseline_{name}": value for name, value in base.items()},
        "absolute_gap_reduction": base["absolute_gap"] - policy["absolute_gap"],
        "reported_baseline_absolute_gap": reported_gap,
        "closure": closure,
        "aggregate_objection_mass_change": policy["aggregate_objection_mass"]
        - base["aggregate_objection_mass"],
        "aggregate_objection_level_change": policy["aggregate_objection_level"]
        - base["aggregate_objection_level"],
    }


def group_mass_fields(
    masses: list[dict[str, Any]], baseline: list[dict[str, Any]]
) -> dict[str, float]:
    output = {}
    for group_index, mass in enumerate(masses):
        output.update(
            {f"group_{group_index}_{name}": mass[name] for name in MASS_NAMES}
        )
        output[f"baseline_group_{group_index}_complaint_mass"] = baseline[group_index][
            "complaint_mass"
        ]
    return output


def outcome_row(
    key: CaseKey,
    case: Mapping[str, Any],
    floor: float,
    family: str,
    baseline: BaselineAmounts,
    comparison: Mapping[str, str],
    points: MassPoints,
    tolerance: float,
    cap: float,
) -> dict[str, Any]:
    chosen = components(case, floor, family)
    base_masses = ordered_masses(baseline.masses(key[2]), case["groups"])
    masses = (
        base_masses
        if family == "baseline"
        else combine_masses(case, key, chosen, points)
    )
    base, policy = mass_metrics(base_masses), mass_metrics(masses)
    metrics = selected_metrics(comparison, case, floor, family, chosen)
    total_value, total_loss = baseline.total("value"), baseline.total("loss")
    baseline_capture, baseline_budget = (
        baseline.selected("loss") / total_loss,
        baseline.selected("value") / total_value,
    )
    if family == "baseline":
        metrics.update(capture=baseline_capture, budget=baseline_budget)
    row = identity_fields(key, case, floor, family, comparison, base, chosen)
    row.update(
        objection_fields(
            base, policy, float(comparison["baseline_test_gap"]), metrics["closure"]
        )
    )
    row.update(effect_flags(base, policy, tolerance))
    row.update(capture_fields(baseline, metrics, floor, tolerance, cap))
    row.update(group_mass_fields(masses, base_masses))
    return row


def build_outcomes(
    cases: Mapping[tuple[str, str, str], Mapping[str, Any]],
    baselines: Mapping[tuple[str, str], BaselineAmounts],
    comparisons: Mapping[tuple[str, str, str, float], Mapping[str, str]],
    points: Mapping[tuple[str, str, str, int, str], list[dict[str, Any]]],
    integrity: Integrity,
    tolerance: float,
    cap: float,
) -> list[dict[str, Any]]:
    output = []
    expected_keys = set()
    families = ("baseline", "group_blind", "group_aware", "group_blind_mixture")
    for key, case in sorted(cases.items()):
        floors = sorted(float(value) for value in case["lp"])
        for floor in floors:
            comparison_key = (*key, floor)
            expected_keys.add(comparison_key)
            comparison = comparisons[comparison_key]
            for family in families:
                row = outcome_row(
                    key,
                    case,
                    floor,
                    family,
                    baselines[key[:2]],
                    comparison,
                    points,
                    tolerance,
                    cap,
                )
                chosen = components(case, floor, family)
                metrics = selected_metrics(comparison, case, floor, family, chosen)
                masses = (
                    baselines[key[:2]].masses(key[2])
                    if family == "baseline"
                    else combine_masses(case, key, chosen, points)
                )
                verify_outcome(row, comparison, metrics, masses, integrity)
                output.append(row)
    if expected_keys != set(comparisons):
        raise ValueError(
            "Comparison CSV and validation freeze have different cell/floor keys"
        )
    return output


def summary_row(
    key: tuple[str, str, float, str], rows: list[dict[str, Any]]
) -> dict[str, Any]:
    source, unit, floor, family = key
    flags = (
        "baseline_zero_gap",
        "gap_reduced",
        "any_group_increased",
        "gap_reduced_without_group_increase",
        "gap_reduced_with_group_increase",
        "gap_reduced_only_by_group_increase",
        "aggregate_objections_increased",
        "capture_floor_met",
        "value_cap_met",
        "both_constraints_met",
    )
    medians = (
        "absolute_gap",
        "absolute_gap_reduction",
        "aggregate_objection_level_change",
        "retained_loss_capture_fraction",
        "blocked_value_fraction",
    )
    output = {
        "source": source,
        "measurement_unit": unit,
        "capture_floor": floor,
        "policy_family": family,
        "n_cells": len(rows),
    }
    for name in flags:
        output[name + "_cells"] = sum(bool(row[name]) for row in rows)
    output["gap_reduced_without_increase_and_constraints_met_cells"] = sum(
        row["gap_reduced_without_group_increase"] and row["both_constraints_met"]
        for row in rows
    )
    for name in medians:
        output["median_" + name] = statistics.median(float(row[name]) for row in rows)
    return output


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, float, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        tail = (row["measurement_unit"], row["capture_floor"], row["policy_family"])
        grouped[(row["source"], *tail)].append(row)
        grouped[("all_sources", *tail)].append(row)
    return [summary_row(key, values) for key, values in sorted(grouped.items())]


def write_csv(
    path: Path, fields: tuple[str, ...], rows: Iterable[Mapping[str, Any]]
) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def report_intro(metadata: Mapping[str, Any]) -> list[str]:
    lines = [
        "# Frozen-policy group outcomes",
        "",
        f"Generator: `{metadata['generator']}`",
        f"Command: `{metadata['command_shell']}`",
        f"Input revision: `{metadata['input_revision']}`",
        "",
        "## Method",
        "",
        "We reconstruct the frozen baseline from committed candidate inputs and combine the existing selected group amounts with the frozen mixture weights. We retain all cells, including baseline-zero-gap cells. We compare each group with its own baseline objection level; a lower group gap does not by itself imply fewer objections for both groups.",
        "",
        "The measurement unit uses each group's total count, value, or loss as its denominator. Captured loss and blocked value include the validation-frozen thinning probability. We report actual held-out constraint satisfaction without adjusting test policies. The numerical effect tolerance is "
        + repr(metadata["effect_tolerance"])
        + ". These summaries describe existing policies; they do not establish feasible improvements from a new optimizer.",
        "",
        "## Integrity",
        "",
        f"We checked {metadata['integrity']['comparisons']} numeric comparisons against the frozen amounts and existing held-out outcomes. Every comparison passed. Input hashes and maximum absolute errors appear in `bandha_fairness_group_outcomes_provenance.json`.",
        "",
        "## Pooled outcomes at the 0.95 capture floor",
        "",
        "The denominators below count fitted cohort/seed cells. They are descriptive counts, without source-level significance tests.",
        "",
        "| Unit | Policy | Cells | Smaller gap | Smaller gap, neither group increased | Smaller gap, a group increased | Only group increases | Test capture floor met | Test value cap met | Both constraints met | Smaller gap, neither increased, both constraints met |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    return lines


def report_table(summary: list[dict[str, Any]]) -> list[str]:
    selected = [
        row
        for row in summary
        if row["source"] == "all_sources"
        and row["capture_floor"] == 0.95
        and row["policy_family"] != "baseline"
    ]
    names = (
        "measurement_unit",
        "policy_family",
        "n_cells",
        "gap_reduced_cells",
        "gap_reduced_without_group_increase_cells",
        "gap_reduced_with_group_increase_cells",
        "gap_reduced_only_by_group_increase_cells",
        "capture_floor_met_cells",
        "value_cap_met_cells",
        "both_constraints_met_cells",
        "gap_reduced_without_increase_and_constraints_met_cells",
    )
    return [
        "| " + " | ".join(str(row[name]) for name in names) + " |" for row in selected
    ]


def report_definitions() -> list[str]:
    return [
        "",
        "## Field definitions",
        "",
        "- `D0` and `D1` divide each group's realized objection amount by that group's total amount in the chosen unit.",
        "- `absolute_gap_reduction` subtracts the selected absolute gap from the baseline absolute gap.",
        "- `gap_reduced_without_group_increase` requires a smaller absolute gap and neither group's objection level to increase beyond the stated tolerance.",
        "- `gap_reduced_only_by_group_increase` requires a smaller absolute gap, no decrease beyond tolerance for the initially higher-objection group, and an increase for the initially lower-objection group.",
        "- `baseline_zero_gap` marks gaps within the stated numerical tolerance; we retain these cells.",
        "- `closure` preserves the existing held-out CSV's convention. Absolute group outcomes and classification do not use closure for eligibility.",
        "- `all_sources` pools cells for descriptive summaries. Each source also has a separate summary row in the CSV.",
        "",
        "## Evidence status",
        "",
        "These generated diagnostics require a committed generator, outputs, and an entry in `EXPERIMENT_PROVENANCE.md` before the paper uses their numerical evidence. The generator preserves the original experiment artifacts.",
        "",
    ]


def report_text(summary: list[dict[str, Any]], metadata: Mapping[str, Any]) -> str:
    return "\n".join(
        report_intro(metadata) + report_table(summary) + report_definitions()
    )


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-dir", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--effect-tolerance", type=float, default=1e-10)
    parser.add_argument("--consistency-relative-tolerance", type=float, default=1e-9)
    parser.add_argument("--consistency-absolute-tolerance", type=float, default=1e-10)
    parser.add_argument("--value-cap", type=float, default=0.10)
    return parser.parse_args()


def run_metadata(
    args: argparse.Namespace,
    revision: str,
    manifests: list[dict[str, Any]],
    integrity: Integrity,
    counts: dict[str, int],
) -> dict[str, Any]:
    command = ["python3", "scripts/bandha_fairness_group_outcomes.py", *sys.argv[1:]]
    return {
        "generator": "scripts/bandha_fairness_group_outcomes.py",
        "generator_sha256": digest(Path(__file__)),
        "input_revision": revision,
        "python": platform.python_version(),
        "command": command,
        "command_shell": shlex.join(command),
        "inputs": manifests,
        "effect_tolerance": args.effect_tolerance,
        "value_cap": args.value_cap,
        "integrity": {
            "comparisons": integrity.comparisons,
            "relative_tolerance": integrity.relative_tolerance,
            "absolute_tolerance": integrity.absolute_tolerance,
            "maximum_absolute_errors": integrity.maximum_absolute_errors,
        },
        **counts,
        "evidence_status": "Generator, outputs, and provenance index must be committed before paper use.",
    }


def write_outputs(
    root: Path,
    outcomes: list[dict[str, Any]],
    summary: list[dict[str, Any]],
    metadata: dict[str, Any],
) -> None:
    output = root / "results" / "bandha_fairness_group_outcomes"
    output.mkdir(exist_ok=True)
    csv_root = root / "results" / "csvs"
    outcome_path = csv_root / "bandha_fairness_group_outcomes.csv"
    summary_path = csv_root / "bandha_fairness_group_outcomes_summary.csv"
    write_csv(outcome_path, OUTCOME_FIELDS, outcomes)
    write_csv(summary_path, SUMMARY_FIELDS, summary)
    report_path = output / "bandha_fairness_group_outcomes_report.md"
    report_path.write_text(report_text(summary, metadata))
    metadata["outputs"] = {
        str(path.relative_to(root)): digest(path)
        for path in (outcome_path, summary_path, report_path)
    }
    provenance = output / "bandha_fairness_group_outcomes_provenance.json"
    provenance.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "outcomes": len(outcomes),
                "summaries": len(summary),
                "comparisons": metadata["integrity"]["comparisons"],
                "provenance": str(provenance.relative_to(root)),
            },
            sort_keys=True,
        )
    )


def main() -> None:
    args = arguments()
    root = args.base_dir.resolve()
    revision = git_output(root, ["rev-parse", "HEAD"])
    frozen, manifests = load_inputs(root, revision)
    comparisons, points = load_comparison(root), load_mass_rows(root)
    cases = index_cases(frozen)
    baselines = reconstruct_baselines(root, cases)
    integrity = Integrity(
        args.consistency_relative_tolerance, args.consistency_absolute_tolerance
    )
    verify_mass_points(cases, baselines, points, integrity)
    outcomes = build_outcomes(
        cases,
        baselines,
        comparisons,
        points,
        integrity,
        args.effect_tolerance,
        args.value_cap,
    )
    summary = summarize(outcomes)
    counts = {
        "baseline_cells": len(baselines),
        "measurement_cases": len(cases),
        "comparison_rows": len(comparisons),
        "outcome_rows": len(outcomes),
        "summary_rows": len(summary),
    }
    metadata = run_metadata(args, revision, manifests, integrity, counts)
    write_outputs(root, outcomes, summary, metadata)


if __name__ == "__main__":
    main()
