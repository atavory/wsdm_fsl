"""Fit pointwise objection-safe contraction and add-only backfill rules.

Common selectors multiply every baseline objector probability by the same s.
Nonobjector probabilities preserve the baseline and add a frozen score-cut
mixture. Targeted controls restrict objector cuts to the baseline blocked set.
We fit on validation outcomes only and freeze every rule before C/T use.
"""

from __future__ import annotations

import argparse
import csv
import json
import logging
import math
import platform
import shlex
import sys
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import bandha_direct_constrained_selector as direct
import bandha_empirical_cut_selector as empirical
import bandha_fairness_group_outcomes as outcomes
import numpy as np
import scipy
from numpy.typing import NDArray
from scipy.optimize import linprog, OptimizeResult


LOGGER: logging.Logger = logging.getLogger(__name__)
GENERATOR = "scripts/bandha_objection_safe_selector.py"
PROTOCOL = "bandha_objection_safe_protocol_20261105.md"
GAMMAS = (0.90, 0.75, 0.50, 0.25, 0.0)
BUDGETS = (0.10, 0.095)
MARGINS = (0.0, 0.05)
CAPTURE_TARGETS = (0.90, 0.95, 0.98, 1.0)
COMMON_KINDS = ("safe_common", "max_removal")
CAPTURE_FLOOR = 0.95
SOLVER_TOLERANCE = 1e-10
TARGETED_PROGRAM_SCALE = 1e4
TARGETED_NEGATIVE_CLIP_TOLERANCE = 1e-10
COMMON_WEIGHT_CLIP_TOLERANCE = 1e-10
REMOVAL_SOLVER_METHOD = "highs-ipm"
CHECK_TOLERANCE = 1e-8
EFFECT_TOLERANCE = 1e-10
CellKey = tuple[str, str, str]
FloatArray = NDArray[np.float64]


class SafeNumericalError(RuntimeError):
    """A fit, compression, pointwise safety, or dual certificate is invalid."""


@dataclass
class SafeCell:
    scope: direct.Scope
    batch: empirical.ValidationBatch
    pi0: FloatArray
    totals: dict[str, Any]
    baseline: dict[str, Any]
    nonobjector_cost: float
    nonobjector_capture: float
    objector_cost: float
    objector_capture: float
    q0_raw_cuts: list[empirical.Cut]
    q0_hull: list[empirical.Cut]
    objector_raw_cuts: tuple[list[empirical.Cut], list[empirical.Cut]]
    objector_hulls: tuple[list[empirical.Cut], list[empirical.Cut]]


@dataclass(frozen=True)
class CommonProblem:
    cost: FloatArray
    capture: FloatArray
    equality: FloatArray
    remaining: float
    constant_capture: float
    gamma: float


@dataclass(frozen=True)
class RemovalProblem:
    common: CommonProblem
    required_capture: float
    matrix: FloatArray
    rhs: FloatArray
    objective: FloatArray


@dataclass(frozen=True)
class RemovalSolution:
    weights: FloatArray | None
    upper: float | None
    certificate: dict[str, float]
    status: int


def baseline_probability(
    forecast: direct.Forecast, selector: Mapping[str, Any]
) -> float:
    return selector["baseline_alpha"] * float(
        forecast.ratio >= selector["baseline_threshold"] and forecast.ratio > 0.0
    )


def batch_baseline(
    batch: direct.PredictionBatch | empirical.ValidationBatch,
    selector: Mapping[str, Any],
) -> FloatArray:
    return (
        (batch.ratio >= selector["baseline_threshold"]) & (batch.ratio > 0.0)
    ).astype(float) * selector["baseline_alpha"]


def objector_cuts(cell: SafeCell, group: int) -> list[empirical.Cut]:
    mask = (
        cell.batch.objectable
        & (cell.batch.group == group)
        & (cell.batch.ratio >= cell.scope.baseline_threshold)
        & (cell.batch.ratio > 0.0)
    )
    batch = empirical.ValidationBatch(
        cell.batch.group[mask],
        cell.batch.ratio[mask],
        cell.batch.objectable[mask],
        cell.batch.value[mask] * cell.scope.baseline_alpha,
        cell.batch.loss[mask] * cell.scope.baseline_alpha,
    )
    return empirical.raw_bucket_cuts(batch, group + 1, cell.scope.baseline_threshold)


def initial_cell(scope: direct.Scope, batch: empirical.ValidationBatch) -> SafeCell:
    totals = empirical.totals(batch)
    identity = {
        "baseline_threshold": scope.baseline_threshold,
        "baseline_alpha": scope.baseline_alpha,
    }
    pi0 = batch_baseline(batch, identity)
    nonobj = ~batch.objectable
    nonobj_cost = math.fsum((pi0 * batch.value)[nonobj])
    nonobj_capture = math.fsum((pi0 * batch.loss)[nonobj])
    obj_cost = math.fsum((pi0 * batch.value)[~nonobj])
    obj_capture = math.fsum((pi0 * batch.loss)[~nonobj])
    increment = empirical.ValidationBatch(
        batch.group,
        batch.ratio,
        batch.objectable,
        batch.value * (1.0 - pi0),
        batch.loss * (1.0 - pi0),
    )
    q0_raw = empirical.raw_bucket_cuts(increment, 0, scope.baseline_threshold)
    q0_hull = empirical.upper_hull(q0_raw, totals)
    return SafeCell(
        scope,
        batch,
        pi0,
        totals,
        empirical.moments(batch, pi0, totals),
        nonobj_cost,
        nonobj_capture,
        obj_cost,
        obj_capture,
        q0_raw,
        q0_hull,
        ([], []),
        ([], []),
    )


def build_cell(scope: direct.Scope, batch: empirical.ValidationBatch) -> SafeCell:
    cell = initial_cell(scope, batch)
    raw = tuple(objector_cuts(cell, group) for group in (0, 1))
    cell.objector_raw_cuts = raw
    cell.objector_hulls = tuple(
        empirical.upper_hull(points, cell.totals) for points in raw
    )
    empirical.hull_receipt(cell.q0_raw_cuts, cell.q0_hull, cell.totals)
    for points, hull in zip(raw, cell.objector_hulls):
        empirical.hull_receipt(points, hull, cell.totals)
    return cell


def identity(
    cell: SafeCell, kind: str, gamma: float, budget: float, margin: float
) -> dict[str, Any]:
    scope = cell.scope
    baseline = cell.baseline
    return {
        "kind": kind,
        "dataset": scope.key[0],
        "seed": scope.key[1],
        "measurement_unit": "value",
        "source": scope.source,
        "input": scope.relative_input,
        "groups": list(scope.groups),
        "gamma": gamma,
        "design_budget": budget,
        "margin": margin,
        "capture_floor": CAPTURE_FLOOR,
        "capture_target": None,
        "rho": None,
        "capture_goal_infeasible": False,
        "objective_kind": "maximize_capture",
        "baseline_index": scope.baseline_index,
        "baseline_threshold": scope.baseline_threshold,
        "baseline_alpha": scope.baseline_alpha,
        "reference": baseline,
        "epsilon": gamma * baseline["absolute_gap"],
        "theta_B_V": (
            cell.objector_capture / baseline["captured_loss"]
            if baseline["captured_loss"] > 0.0
            else None
        ),
        "theta_A_V": (
            cell.objector_cost / baseline["blocked_value"]
            if baseline["blocked_value"] > 0.0
            else None
        ),
    }


def null_cut_rule() -> dict[str, Any]:
    return {
        "thresholds": [None, None],
        "right_weight": 0.0,
        "hull_indices": None,
        "hull_size": 0,
        "expected_cost": 0.0,
        "expected_capture": 0.0,
    }


def resource_failure(
    cell: SafeCell, kind: str, gamma: float, budget: float, margin: float
) -> dict[str, Any] | None:
    excess = cell.nonobjector_cost / cell.totals["value"] - budget
    if excess <= CHECK_TOLERANCE:
        return None
    if budget == 0.10:
        raise SafeNumericalError(
            "Baseline nonobjector value exceeds the original feasible 0.10 cap"
        )
    rule = {
        **identity(cell, kind, gamma, budget, margin),
        "defined": True,
        "selection_feasible": False,
        "support_status": "resource_infeasible_minimum_value_anchor",
        "solver_status": None,
        "resource_infeasible": True,
        "safe_anchor_fallback": True,
        "contraction_s": 0.0,
        "q0_rule": null_cut_rule(),
        "objector_rules": [null_cut_rule(), null_cut_rule()],
        "validation_resource_excess": excess,
    }
    rule["validation"] = validation_fields(cell, rule, None)
    rule["safety_receipt"] = pointwise_receipt(cell, rule)
    return rule


def common_problem(cell: SafeCell, gamma: float, budget: float) -> CommonProblem:
    hull = cell.q0_hull
    value_scale, loss_scale = cell.totals["value"], cell.totals["loss_scale"]
    cost = (
        np.asarray([point.cost for point in hull] + [cell.objector_cost]) / value_scale
    )
    capture = (
        np.asarray([point.capture for point in hull] + [cell.objector_capture])
        / loss_scale
    )
    remaining = budget - cell.nonobjector_cost / value_scale
    equality = np.r_[np.ones(len(hull)), 0.0]
    return CommonProblem(
        cost, capture, equality, remaining, cell.nonobjector_capture / loss_scale, gamma
    )


def common_certificate(
    problem: CommonProblem, result: OptimizeResult
) -> tuple[float, dict[str, float]]:
    multiplier = max(0.0, -float(result.ineqlin.marginals[0]))
    profit = problem.capture - multiplier * problem.cost
    upper = (
        problem.constant_capture
        + multiplier * problem.remaining
        + float(np.max(profit[:-1]))
        + problem.gamma * max(float(profit[-1]), 0.0)
    )
    primal = problem.constant_capture + float(problem.capture @ result.x)
    errors = {
        "simplex_error": abs(float(problem.equality @ result.x) - 1.0),
        "budget_error": max(0.0, float(problem.cost @ result.x) - problem.remaining),
        "negative_weight_error": max(0.0, -float(result.x.min())),
        "s_box_error": max(0.0, float(result.x[-1]) - problem.gamma),
        "independent_dual_gap": abs(upper - primal),
    }
    if max(errors.values()) > CHECK_TOLERANCE:
        raise SafeNumericalError(
            f"Common-safe simplex/box certificate failed: {errors}"
        )
    return upper, errors


def normalize_common_weights(problem: CommonProblem, raw: FloatArray) -> FloatArray:
    tolerance = COMMON_WEIGHT_CLIP_TOLERANCE
    if not np.isfinite(raw).all() or np.min(raw) < -tolerance:
        raise SafeNumericalError(
            "Common weights contain nonfinite or material negatives"
        )
    if raw[-1] > problem.gamma + tolerance:
        raise SafeNumericalError("Common objector factor materially exceeds its bound")
    weights = np.maximum(raw, 0.0)
    total = math.fsum(weights[:-1])
    if not math.isfinite(total) or total <= 0.0:
        raise SafeNumericalError("Common backfill lacks positive simplex mass")
    weights[:-1] /= total
    weights[-1] = min(problem.gamma, max(0.0, float(raw[-1])))
    return weights


def common_raw_diagnostics(
    common: CommonProblem,
    matrix: FloatArray,
    rhs: FloatArray,
    raw: FloatArray,
    weights: FloatArray,
) -> dict[str, float]:
    correction = weights - raw
    return {
        "raw_simplex_error": abs(float(common.equality @ raw) - 1.0),
        "raw_negative_weight_error": float(np.max(-raw, initial=0.0)),
        "raw_s_box_error": max(0.0, -float(raw[-1]), float(raw[-1]) - common.gamma),
        "raw_constraint_error": float(
            np.max(np.maximum(matrix @ raw - rhs, 0.0), initial=0.0)
        ),
        "raw_normalized_capture": common.constant_capture + float(common.capture @ raw),
        "maximum_weight_correction": float(np.max(np.abs(correction), initial=0.0)),
        "weight_correction_l1": math.fsum(np.abs(correction)),
        "maximum_original_moment_change": float(
            np.max(np.abs(matrix @ correction), initial=0.0)
        ),
        "normalized_capture_change": float(common.capture @ correction),
        "s_correction": float(correction[-1]),
    }


def certify_common_weights(
    problem: CommonProblem, result: OptimizeResult
) -> tuple[FloatArray, float, dict[str, float]]:
    if not np.isfinite(result.ineqlin.marginals).all():
        raise SafeNumericalError("Common inequality multipliers are nonfinite")
    weights = normalize_common_weights(problem, result.x)
    certified = OptimizeResult(result)
    certified.x = weights
    certified.fun = -float(problem.capture @ weights)
    upper, receipt = common_certificate(problem, certified)
    receipt.update(
        common_raw_diagnostics(
            problem,
            np.atleast_2d(problem.cost),
            np.asarray([problem.remaining]),
            result.x,
            weights,
        )
    )
    return weights, upper, receipt


def solve_common(
    cell: SafeCell, gamma: float, budget: float
) -> tuple[FloatArray, float, dict[str, float]]:
    problem = common_problem(cell, gamma, budget)
    bounds = [(0.0, None)] * len(cell.q0_hull) + [(0.0, gamma)]
    result = linprog(
        -problem.capture,
        A_ub=[problem.cost],
        b_ub=[problem.remaining],
        A_eq=[problem.equality],
        b_eq=[1.0],
        bounds=bounds,
        method="highs-ds",
        options={
            "presolve": False,
            "primal_feasibility_tolerance": SOLVER_TOLERANCE,
            "dual_feasibility_tolerance": SOLVER_TOLERANCE,
        },
    )
    if result.status != 0 or not np.isfinite(result.x).all():
        raise SafeNumericalError(
            f"Common-safe LP failed: {cell.scope.key}, gamma={gamma}, "
            f"budget={budget}: {result.message}"
        )
    try:
        return certify_common_weights(problem, result)
    except SafeNumericalError as error:
        raise SafeNumericalError(
            f"Common verification failed: {cell.scope.key}, gamma={gamma}, "
            f"budget={budget}: {error}"
        ) from error


def compress_hull(
    hull: list[empirical.Cut], weights: FloatArray, cell: SafeCell
) -> dict[str, Any]:
    cost = math.fsum(float(weight) * point.cost for weight, point in zip(weights, hull))
    capture = math.fsum(
        float(weight) * point.capture for weight, point in zip(weights, hull)
    )
    left, right, mix = empirical.interpolate(hull, cost)
    actual_cost = (1.0 - mix) * hull[left].cost + mix * hull[right].cost
    actual_capture = (1.0 - mix) * hull[left].capture + mix * hull[right].capture
    if (
        abs(actual_cost - cost) / cell.totals["value"] > CHECK_TOLERANCE
        or actual_capture < capture - CHECK_TOLERANCE * cell.totals["loss_scale"]
    ):
        raise SafeNumericalError(
            "Safe hull compression changed cost or reduced capture"
        )
    return {
        "thresholds": [hull[left].threshold, hull[right].threshold],
        "right_weight": mix,
        "hull_indices": [left, right],
        "hull_size": len(hull),
        "expected_cost": actual_cost,
        "expected_capture": actual_capture,
        "adjacent_or_same": right - left in (0, 1),
    }


def fit_common(cell: SafeCell, gamma: float, budget: float) -> dict[str, Any]:
    failure = resource_failure(cell, "safe_common", gamma, budget, 0.0)
    if failure is not None:
        return failure
    weights, upper, certificate = solve_common(cell, gamma, budget)
    rule = {
        **identity(cell, "safe_common", gamma, budget, 0.0),
        "defined": True,
        "selection_feasible": True,
        "support_status": "valid",
        "solver_status": 0,
        "simplex_reconstructed": True,
        "resource_infeasible": False,
        "safe_anchor_fallback": False,
        "contraction_s": min(gamma, max(0.0, float(weights[-1]))),
        "q0_rule": compress_hull(cell.q0_hull, weights[:-1], cell),
        "certificate": certificate,
    }
    rule["validation"] = validation_fields(cell, rule, upper)
    rule["safety_receipt"] = pointwise_receipt(cell, rule)
    return rule


def removal_problem(cell: SafeCell, rho: float, budget: float) -> RemovalProblem:
    common = common_problem(cell, 1.0, budget)
    required = (
        rho * cell.baseline["captured_loss"] - cell.nonobjector_capture
    ) / cell.totals["loss_scale"]
    objective = np.zeros(len(common.cost))
    objective[-1] = -1.0
    return RemovalProblem(
        common,
        required,
        np.vstack((common.cost, -common.capture)),
        np.asarray((common.remaining, -required)),
        objective,
    )


def solve_removal(problem: RemovalProblem) -> OptimizeResult:
    bounds = [(0.0, None)] * (len(problem.objective) - 1) + [(0.0, 1.0)]
    result = linprog(
        -problem.objective,
        A_ub=problem.matrix,
        b_ub=problem.rhs,
        A_eq=[problem.common.equality],
        b_eq=[1.0],
        bounds=bounds,
        method=REMOVAL_SOLVER_METHOD,
        options={
            "presolve": False,
            "primal_feasibility_tolerance": SOLVER_TOLERANCE,
            "dual_feasibility_tolerance": SOLVER_TOLERANCE,
        },
    )
    if result.status == 2:
        return result
    if result.status != 0 or not np.isfinite(result.x).all():
        raise SafeNumericalError(
            f"Max-removal LP failed unexpectedly: {result.message}"
        )
    return result


def removal_certificate(
    problem: RemovalProblem, result: OptimizeResult
) -> tuple[float, dict[str, float]]:
    dual = -np.asarray(result.ineqlin.marginals)
    if np.min(dual) < -CHECK_TOLERANCE:
        raise SafeNumericalError("Negative max-removal inequality multiplier")
    dual = np.maximum(dual, 0.0)
    profit = problem.objective - problem.matrix.T @ dual
    upper = (
        float(dual @ problem.rhs)
        + float(np.max(profit[:-1]))
        + max(0.0, float(profit[-1]))
    )
    primal = float(problem.objective @ result.x)
    errors = {
        "simplex_error": abs(float(problem.common.equality @ result.x) - 1.0),
        "constraint_error": float(
            np.max(
                np.maximum(problem.matrix @ result.x - problem.rhs, 0.0), initial=0.0
            )
        ),
        "negative_weight_error": max(0.0, -float(result.x.min())),
        "s_box_error": max(0.0, float(result.x[-1]) - 1.0),
        "independent_dual_gap": abs(upper - primal),
    }
    if max(errors.values()) > CHECK_TOLERANCE:
        raise SafeNumericalError(
            f"Max-removal simplex/box/capture certificate failed: {errors}"
        )
    return upper, errors


def certify_removal_weights(
    problem: RemovalProblem, result: OptimizeResult
) -> RemovalSolution:
    if not np.isfinite(result.ineqlin.marginals).all():
        raise SafeNumericalError("Max-removal inequality multipliers are nonfinite")
    weights = normalize_common_weights(problem.common, result.x)
    certified = OptimizeResult(result)
    certified.x = weights
    certified.fun = -float(problem.objective @ weights)
    upper, receipt = removal_certificate(problem, certified)
    receipt.update(
        common_raw_diagnostics(
            problem.common,
            problem.matrix,
            problem.rhs,
            result.x,
            weights,
        )
    )
    return RemovalSolution(weights, upper, receipt, 0)


def solve_max_removal(cell: SafeCell, rho: float, budget: float) -> RemovalSolution:
    """Solve a supplied population's LP; the caller handles resource infeasibility."""
    problem = removal_problem(cell, rho, budget)
    try:
        result = solve_removal(problem)
        if result.status == 2:
            return RemovalSolution(None, None, {}, 2)
        return certify_removal_weights(problem, result)
    except SafeNumericalError as error:
        raise SafeNumericalError(
            f"Max-removal verification failed: {cell.scope.key}, rho={rho}, "
            f"budget={budget}: {error}"
        ) from error


def removal_identity(cell: SafeCell, rho: float, budget: float) -> dict[str, Any]:
    rule = identity(cell, "max_removal", 1.0, budget, 0.0)
    rule.update(
        {
            "gamma": None,
            "epsilon": None,
            "capture_target": rho,
            "rho": rho,
            "capture_floor": rho,
            "objective_kind": "minimize_common_objector_factor",
            "tie_selection": "first_deterministic_solver_vertex_then_adjacent_hull",
        }
    )
    return rule


def finish_removal(
    cell: SafeCell, rule: dict[str, Any], upper: float | None
) -> dict[str, Any]:
    rule["validation"] = validation_fields(cell, rule, upper)
    rule["safety_receipt"] = pointwise_receipt(cell, rule)
    return rule


def capture_goal_fallback(cell: SafeCell, rho: float, budget: float) -> dict[str, Any]:
    fallback = fit_common(cell, 1.0, budget)
    achieved = fallback["validation"]["normalized_capture"]
    goal = rho * cell.baseline["captured_loss"] / cell.totals["loss_scale"]
    if fallback["resource_infeasible"] or achieved >= goal - CHECK_TOLERANCE:
        raise SafeNumericalError(
            "An infeasible capture-goal LP contradicts the independent maximum-capture bound"
        )
    upper = fallback["validation"]["independent_dual_upper_bound"]
    fallback.update(removal_identity(cell, rho, budget))
    fallback.update(
        {
            "selection_feasible": False,
            "support_status": "capture_goal_infeasible_best_capture_fallback",
            "solver_status": 2,
            "fallback_solver_status": 0,
            "solver_method": REMOVAL_SOLVER_METHOD,
            "fallback_solver_method": "highs-ds",
            "capture_goal_infeasible": True,
            "fallback_kind": "best_capture_resource_feasible",
            "objective_kind": "maximize_capture_after_infeasible_goal",
        }
    )
    return finish_removal(cell, fallback, upper)


def fit_max_removal(cell: SafeCell, rho: float, budget: float) -> dict[str, Any]:
    failure = resource_failure(cell, "max_removal", 1.0, budget, 0.0)
    if failure is not None:
        failure.update(removal_identity(cell, rho, budget))
        failure["capture_goal_infeasible"] = None
        return finish_removal(cell, failure, None)
    solution = solve_max_removal(cell, rho, budget)
    if solution.status == 2:
        return capture_goal_fallback(cell, rho, budget)
    weights = solution.weights
    if weights is None:
        raise SafeNumericalError("A solved max-removal LP lacks frozen weights")
    rule = {
        **removal_identity(cell, rho, budget),
        "defined": True,
        "selection_feasible": True,
        "support_status": "valid",
        "solver_status": 0,
        "simplex_reconstructed": True,
        "solver_method": REMOVAL_SOLVER_METHOD,
        "resource_infeasible": False,
        "safe_anchor_fallback": False,
        "contraction_s": min(1.0, max(0.0, float(weights[-1]))),
        "q0_rule": compress_hull(cell.q0_hull, weights[:-1], cell),
        "certificate": solution.certificate,
    }
    return finish_removal(cell, rule, solution.upper)


def scaled_cuts(points: list[empirical.Cut], factor: float) -> list[empirical.Cut]:
    return [
        empirical.Cut(
            point.threshold, point.cost * factor, point.capture * factor, point.count
        )
        for point in points
    ]


def targeted_problem(
    cell: SafeCell, gamma: float, budget: float, margin: float
) -> empirical.EmpiricalLP:
    hulls = (
        cell.q0_hull,
        scaled_cuts(cell.objector_hulls[0], 1.0 - margin),
        scaled_cuts(cell.objector_hulls[1], 1.0 - margin),
    )
    raw = (
        cell.q0_raw_cuts,
        scaled_cuts(cell.objector_raw_cuts[0], 1.0 - margin),
        scaled_cuts(cell.objector_raw_cuts[1], 1.0 - margin),
    )
    bank = empirical.HullBank(
        cell.scope, cell.batch, hulls, raw, cell.totals, cell.baseline
    )
    problem = empirical.make_lp(bank, gamma, margin)
    problem.rhs[0] = budget - cell.nonobjector_cost / cell.totals["value"]
    return problem


def solve_targeted(problem: empirical.EmpiricalLP) -> OptimizeResult:
    """Improve numerical conditioning without changing the empirical LP."""
    scale = TARGETED_PROGRAM_SCALE
    result = linprog(
        -problem.capture * scale,
        A_ub=problem.matrix * scale,
        b_ub=problem.rhs * scale,
        A_eq=problem.equality * scale,
        b_eq=np.ones(3) * scale,
        bounds=(0.0, None),
        method="highs-ds",
        options={
            "presolve": False,
            "primal_feasibility_tolerance": SOLVER_TOLERANCE,
            "dual_feasibility_tolerance": SOLVER_TOLERANCE,
        },
    )
    if result.status != 0 or not np.isfinite(result.x).all():
        raise SafeNumericalError(f"Targeted-safe LP failed: {result.message}")
    # Scaling both objective and constraint rows leaves their duals unchanged.
    result.fun /= scale
    result.ineqlin.residual /= scale
    result.eqlin.residual /= scale
    result.lower.marginals /= scale
    result.upper.marginals /= scale
    return result


def targeted_raw_errors(
    problem: empirical.EmpiricalLP, weights: FloatArray
) -> dict[str, float]:
    return {
        "raw_simplex_error": float(
            np.max(np.abs(problem.equality @ weights - 1.0), initial=0.0)
        ),
        "raw_negative_weight_error": float(np.max(-weights, initial=0.0)),
        "raw_constraint_error": float(
            np.max(np.maximum(problem.matrix @ weights - problem.rhs, 0.0), initial=0.0)
        ),
        "raw_normalized_capture": float(problem.capture @ weights),
    }


def normalize_targeted_weights(
    problem: empirical.EmpiricalLP, raw: FloatArray
) -> FloatArray:
    if not np.isfinite(raw).all() or np.min(raw) < -TARGETED_NEGATIVE_CLIP_TOLERANCE:
        raise SafeNumericalError(
            "Targeted weights contain nonfinite or material negatives"
        )
    weights = np.maximum(raw, 0.0)
    for bucket in range(3):
        mask = problem.vertex_bucket == bucket
        total = math.fsum(weights[mask])
        if not math.isfinite(total) or total <= 0.0:
            raise SafeNumericalError("A targeted bucket lacks positive simplex mass")
        weights[mask] /= total
    return weights


def certify_targeted_weights(
    problem: empirical.EmpiricalLP, result: OptimizeResult
) -> tuple[FloatArray, float, dict[str, float]]:
    raw = result.x
    weights = normalize_targeted_weights(problem, raw)
    receipt = empirical.weight_receipt(problem, weights)
    if not np.isfinite(result.ineqlin.marginals).all():
        raise SafeNumericalError("Targeted inequality multipliers are nonfinite")
    certified = OptimizeResult(result)
    certified.x = weights
    certified.fun = -float(problem.capture @ weights)
    _, upper = empirical.dual_upper_bound(problem, certified)
    if not math.isfinite(upper):
        raise SafeNumericalError("Targeted independent dual bound is nonfinite")
    correction = weights - raw
    receipt.update(targeted_raw_errors(problem, raw))
    receipt.update(
        {
            "maximum_weight_correction": float(np.max(np.abs(correction), initial=0.0)),
            "weight_correction_l1": math.fsum(np.abs(correction)),
            "maximum_original_moment_change": float(
                np.max(np.abs(problem.matrix @ correction), initial=0.0)
            ),
            "normalized_capture_change": float(problem.capture @ correction),
            "independent_probability_dual_gap": abs(
                upper - float(problem.capture @ weights)
            ),
        }
    )
    return weights, upper, receipt


def fit_targeted(
    cell: SafeCell, gamma: float, budget: float, margin: float
) -> dict[str, Any]:
    failure = resource_failure(cell, "safe_targeted", gamma, budget, margin)
    if failure is not None:
        return failure
    problem = targeted_problem(cell, gamma, budget, margin)
    result = solve_targeted(problem)
    try:
        weights, variable_upper, certificate = certify_targeted_weights(problem, result)
    except (empirical.EmpiricalNumericalError, SafeNumericalError) as error:
        raise SafeNumericalError(
            f"Targeted LP failed verification: {cell.scope.key}, gamma={gamma}, "
            f"budget={budget}, margin={margin}: {error}"
        ) from error
    cuts = [empirical.compress_bucket(problem, weights, bucket) for bucket in range(3)]
    upper = cell.nonobjector_capture / cell.totals["loss_scale"] + variable_upper
    rule = {
        **identity(cell, "safe_targeted", gamma, budget, margin),
        "defined": True,
        "selection_feasible": True,
        "support_status": "valid",
        "solver_status": 0,
        "solver_scale": TARGETED_PROGRAM_SCALE,
        "simplex_reconstructed": True,
        "resource_infeasible": False,
        "safe_anchor_fallback": False,
        "q0_rule": cuts[0],
        "objector_rules": cuts[1:],
        "certificate": certificate,
    }
    rule["validation"] = validation_fields(cell, rule, upper)
    rule["safety_receipt"] = pointwise_receipt(cell, rule)
    return rule


def cut_probability(ratio: float, rule: Mapping[str, Any]) -> float:
    left, right = rule["thresholds"]
    return (1.0 - rule["right_weight"]) * float(
        left is not None and ratio >= left
    ) + rule["right_weight"] * float(right is not None and ratio >= right)


def probability(forecast: direct.Forecast, selector: Mapping[str, Any]) -> float:
    base = baseline_probability(forecast, selector)
    if not forecast.objectable:
        return base + (1.0 - base) * cut_probability(
            forecast.ratio, selector["q0_rule"]
        )
    if selector["resource_infeasible"]:
        return 0.0
    if selector["kind"] in COMMON_KINDS:
        return selector["contraction_s"] * base
    if forecast.ratio < selector["baseline_threshold"] or forecast.ratio <= 0.0:
        return 0.0
    return (
        (1.0 - selector["margin"])
        * selector["baseline_alpha"]
        * cut_probability(forecast.ratio, selector["objector_rules"][forecast.group])
    )


def batch_cut(ratios: FloatArray, rule: Mapping[str, Any]) -> FloatArray:
    left, right = rule["thresholds"]
    a = (ratios >= left).astype(float) if left is not None else np.zeros(len(ratios))
    b = (ratios >= right).astype(float) if right is not None else np.zeros(len(ratios))
    return (1.0 - rule["right_weight"]) * a + rule["right_weight"] * b


def batch_probability(
    batch: direct.PredictionBatch | empirical.ValidationBatch,
    selector: Mapping[str, Any],
) -> FloatArray:
    base = batch_baseline(batch, selector)
    result = base + (1.0 - base) * batch_cut(batch.ratio, selector["q0_rule"])
    q = batch.objectable
    if selector["resource_infeasible"]:
        result[q] = 0.0
    elif selector["kind"] in COMMON_KINDS:
        result[q] = selector["contraction_s"] * base[q]
    else:
        for group in (0, 1):
            mask = q & (batch.group == group)
            result[mask] = (
                (1.0 - selector["margin"])
                * base[mask]
                * batch_cut(batch.ratio[mask], selector["objector_rules"][group])
            )
    return result


def validation_errors(
    cell: SafeCell,
    selector: Mapping[str, Any],
    actual: Mapping[str, float],
    upper: float | None,
) -> tuple[list[float], float, float | None]:
    budget_error = max(
        0.0, actual["blocked_value_fraction"] - selector["design_budget"]
    )
    gap_error = (
        max(0.0, actual["absolute_gap"] - selector["epsilon"])
        if selector["epsilon"] is not None
        else 0.0
    )
    factor = (
        1.0 - selector["margin"]
        if selector["kind"] == "safe_targeted"
        else selector["contraction_s"]
    )
    group_limits = [factor * cell.baseline[f"D{group}"] for group in (0, 1)]
    cap_error = max(
        max(0.0, actual[f"D{group}"] - group_limits[group]) for group in (0, 1)
    )
    objective = (
        -selector["contraction_s"]
        if selector["objective_kind"] == "minimize_common_objector_factor"
        else actual["normalized_capture"]
    )
    dual_gap = abs(upper - objective) if upper is not None else None
    target = selector["capture_target"]
    capture_error = (
        max(0.0, target * cell.baseline["captured_loss"] - actual["captured_loss"])
        / cell.totals["loss_scale"]
        if target is not None
        else 0.0
    )
    return (
        group_limits,
        max(budget_error, gap_error, cap_error, capture_error, dual_gap or 0.0),
        dual_gap,
    )


def validation_fields(
    cell: SafeCell, selector: Mapping[str, Any], upper: float | None
) -> dict[str, Any]:
    pi = batch_probability(cell.batch, selector)
    actual = empirical.moments(cell.batch, pi, cell.totals)
    group_limits, maximum, dual_gap = validation_errors(cell, selector, actual, upper)
    if selector["selection_feasible"] and maximum > CHECK_TOLERANCE:
        raise SafeNumericalError(
            f"Safe frozen rule fails original constraints or independent bound: "
            f"{cell.scope.key}, kind={selector['kind']}, rho={selector['rho']}, "
            f"gamma={selector['gamma']}, budget={selector['design_budget']}, "
            f"margin={selector['margin']}"
        )
    baseline = cell.baseline["captured_loss"]
    return {
        **actual,
        "baseline_capture_positive": baseline > 0.0,
        "retained_capture_fraction": (
            actual["captured_loss"] / baseline if baseline > 0.0 else None
        ),
        "capture_floor_met": actual["captured_loss"]
        >= (selector["capture_floor"] - EFFECT_TOLERANCE) * baseline,
        "capture_target_met": (
            actual["captured_loss"]
            >= (selector["capture_target"] - EFFECT_TOLERANCE) * baseline
            if selector["capture_target"] is not None
            else None
        ),
        "design_budget_met": actual["blocked_value_fraction"]
        <= selector["design_budget"] + EFFECT_TOLERANCE,
        "group_0_limit": group_limits[0],
        "group_1_limit": group_limits[1],
        "original_constraints_met": selector["selection_feasible"]
        and maximum <= CHECK_TOLERANCE,
        "max_constraint_error": maximum,
        "independent_dual_upper_bound": upper,
        "independent_two_sided_dual_gap": dual_gap,
    }


def pointwise_errors(cell: SafeCell, pi: FloatArray, factor: float) -> dict[str, float]:
    q = cell.batch.objectable
    return {
        "q0_baseline_preservation_error": float(
            np.max(np.maximum(cell.pi0[~q] - pi[~q], 0.0), initial=0.0)
        ),
        "objector_upper_error": float(
            np.max(np.maximum(pi[q] - factor * cell.pi0[q], 0.0), initial=0.0)
        ),
        "probability_bound_error": float(
            max(np.max(-pi, initial=0.0), np.max(pi - 1.0, initial=0.0))
        ),
    }


def pointwise_receipt(cell: SafeCell, selector: Mapping[str, Any]) -> dict[str, float]:
    pi = batch_probability(cell.batch, selector)
    q = cell.batch.objectable
    factor = (
        0.0
        if selector["resource_infeasible"]
        else (
            selector["contraction_s"]
            if selector["kind"] in COMMON_KINDS
            else 1.0 - selector["margin"]
        )
    )
    errors = pointwise_errors(cell, pi, factor)
    if selector["kind"] in COMMON_KINDS or selector["resource_infeasible"]:
        errors["common_objector_identity_error"] = float(
            np.max(np.abs(pi[q] - factor * cell.pi0[q]), initial=0.0)
        )
        errors["dominance_vs_uniform_at_s_error"] = float(
            np.max(np.maximum(factor * cell.pi0 - pi, 0.0), initial=0.0)
        )
        selective = cell.pi0 * np.where(q, factor, 1.0)
        errors["dominance_vs_selective_at_s_error"] = float(
            np.max(np.maximum(selective - pi, 0.0), initial=0.0)
        )
    if max(errors.values()) > CHECK_TOLERANCE:
        raise SafeNumericalError("Frozen policy violates its pointwise safety contract")
    return errors


def cell_manifest(cell: SafeCell, receipt: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "dataset": cell.scope.key[0],
        "seed": cell.scope.key[1],
        "input": cell.scope.relative_input,
        "groups": list(cell.scope.groups),
        "baseline": cell.baseline,
        "nonobjector_baseline_cost": cell.nonobjector_cost,
        "nonobjector_baseline_capture": cell.nonobjector_capture,
        "objector_baseline_cost": cell.objector_cost,
        "objector_baseline_capture": cell.objector_capture,
        "q0_raw_cuts": [asdict(point) for point in cell.q0_raw_cuts],
        "q0_hull": [asdict(point) for point in cell.q0_hull],
        "objector_hulls": [
            [asdict(point) for point in hull] for hull in cell.objector_hulls
        ],
        "baseline_verification": receipt,
    }


def selector_row(selector: Mapping[str, Any]) -> dict[str, Any]:
    names = (
        "kind",
        "dataset",
        "seed",
        "source",
        "measurement_unit",
        "gamma",
        "rho",
        "capture_target",
        "design_budget",
        "margin",
        "capture_floor",
        "objective_kind",
        "defined",
        "selection_feasible",
        "support_status",
        "solver_status",
        "solver_method",
        "solver_scale",
        "resource_infeasible",
        "capture_goal_infeasible",
        "safe_anchor_fallback",
        "contraction_s",
        "theta_A_V",
        "theta_B_V",
        "epsilon",
        "baseline_threshold",
        "baseline_alpha",
        "baseline_index",
    )
    result = {name: selector.get(name) for name in names}
    result.update(targeted_solver_fields(selector))
    result.update(common_solver_fields(selector))
    result.update(
        {
            "validation_baseline_" + name: value
            for name, value in selector["reference"].items()
        }
    )
    result.update(
        {"validation_" + name: value for name, value in selector["validation"].items()}
    )
    result["q0_thresholds_json"] = json.dumps(selector["q0_rule"]["thresholds"])
    result["q0_right_weight"] = selector["q0_rule"]["right_weight"]
    result["objector_rules_json"] = json.dumps(
        selector.get("objector_rules"), separators=(",", ":")
    )
    return result


def targeted_solver_fields(selector: Mapping[str, Any]) -> dict[str, Any]:
    names = (
        "raw_simplex_error",
        "raw_negative_weight_error",
        "raw_constraint_error",
        "maximum_weight_correction",
        "weight_correction_l1",
        "maximum_original_moment_change",
        "normalized_capture_change",
        "independent_probability_dual_gap",
    )
    certificate = (
        selector.get("certificate", {}) if selector["kind"] == "safe_targeted" else {}
    )
    return {"targeted_" + name: certificate.get(name) for name in names}


def common_solver_fields(selector: Mapping[str, Any]) -> dict[str, Any]:
    names = (
        "raw_simplex_error",
        "raw_negative_weight_error",
        "raw_s_box_error",
        "raw_constraint_error",
        "maximum_weight_correction",
        "weight_correction_l1",
        "maximum_original_moment_change",
        "normalized_capture_change",
        "s_correction",
    )
    certificate = (
        selector.get("certificate", {}) if selector["kind"] in COMMON_KINDS else {}
    )
    return {"common_" + name: certificate.get(name) for name in names}


def code_identities(root: Path, verification: bool) -> list[dict[str, Any]]:
    names = (
        GENERATOR,
        empirical.GENERATOR,
        direct.GENERATOR,
        "scripts/bandha_fairness_group_outcomes.py",
    )
    if verification:
        return [
            {"path": name, "sha256": outcomes.digest(root / name)} for name in names
        ]
    return [outcomes.committed_input(root, name, "HEAD") for name in names]


def fit_all(cells: Mapping[CellKey, SafeCell]) -> list[dict[str, Any]]:
    result = []
    for key, cell in cells.items():
        for rho in CAPTURE_TARGETS:
            result.extend(fit_max_removal(cell, rho, budget) for budget in BUDGETS)
        for gamma in GAMMAS:
            for budget in BUDGETS:
                result.append(fit_common(cell, gamma, budget))
                result.extend(
                    fit_targeted(cell, gamma, budget, margin) for margin in MARGINS
                )
        LOGGER.info("Completed safe-selector validation cell: %s", key)
    return result


def write_outputs(root: Path, prefix: str, metadata: dict[str, Any]) -> None:
    directory = root / "results/csvs"
    path = directory / f"{prefix}_validation_selections.csv"
    rows = [selector_row(row) for row in metadata["selectors"]]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    metadata["outputs"] = [
        {"path": str(path.relative_to(root)), "sha256": outcomes.digest(path)}
    ]
    (directory / f"{prefix}_validation_freeze.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--input-revision", default="HEAD")
    parser.add_argument("--output-prefix", default="bandha_objection_safe")
    parser.add_argument("--verification-only", action="store_true")
    parser.add_argument("--canary-cell", action="append", default=[])
    result = parser.parse_args()
    if not result.output_prefix.startswith("bandha_objection_safe") or any(
        value not in "abcdefghijklmnopqrstuvwxyz0123456789_"
        for value in result.output_prefix
    ):
        raise ValueError("Outputs must stay in the objection-safe area")
    if result.canary_cell and not result.verification_only:
        raise ValueError("Partial-cell runs must be verification-only")
    return result


def freeze_header(
    args: argparse.Namespace,
    revision: str,
    inputs: list[dict[str, Any]],
    code: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "generator": GENERATOR,
        "schema_version": 1,
        "phase": "select",
        "complete": True,
        "verification_only": args.verification_only,
        "input_revision": revision,
        "inputs": inputs,
        "implementation": code,
        "protocol": inputs[-1],
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "command": [sys.executable, *sys.argv],
        "command_shell": shlex.join([sys.executable, *sys.argv]),
        "gamma_scope": list(GAMMAS),
        "capture_target_scope": list(CAPTURE_TARGETS),
        "design_budget_scope": list(BUDGETS),
        "margin_scope": list(MARGINS),
        "primary_kind": "max_removal",
        "primary_capture_target": 0.95,
        "primary_design_budget": 0.10,
        "capture_floor": CAPTURE_FLOOR,
        "solver_tolerance": SOLVER_TOLERANCE,
        "checked_tolerance": CHECK_TOLERANCE,
        "targeted_program_scale": TARGETED_PROGRAM_SCALE,
        "targeted_probability_reconstruction": "clip_tiny_negatives_then_normalize_each_bucket",
        "targeted_negative_clip_tolerance": TARGETED_NEGATIVE_CLIP_TOLERANCE,
        "common_probability_reconstruction": "normalize_backfill_simplex_and_clip_s_roundoff",
        "common_weight_clip_tolerance": COMMON_WEIGHT_CLIP_TOLERANCE,
        "removal_solver_method": REMOVAL_SOLVER_METHOD,
        "heldout_numeric_outcomes_parsed": False,
        "heldout_outcomes_parsed": False,
        "final_outcomes_used_for_selection": False,
    }


def validate_frozen_inputs(
    root: Path,
    inputs: list[dict[str, Any]],
    code: list[dict[str, Any]],
    verification: bool,
) -> None:
    if code_identities(root, verification) != code:
        raise ValueError("Code changed during safe-selector validation fit")
    for item in inputs:
        if outcomes.digest(root / item["path"]) != item["sha256"]:
            raise ValueError("Frozen inputs or protocol changed during fit")


def main() -> None:
    args = arguments()
    root = args.root.resolve()
    revision = outcomes.git_output(root, ["rev-parse", args.input_revision])
    protocol = outcomes.committed_input(root, PROTOCOL, "HEAD")
    code = code_identities(root, args.verification_only)
    scopes, inputs = direct.load_scopes(root, revision)
    if args.canary_cell:
        wanted = {tuple(item.rsplit(":", 1)) for item in args.canary_cell}
        scopes = {key: value for key, value in scopes.items() if key[:2] in wanted}
        if {key[:2] for key in scopes} != wanted:
            raise ValueError("Unknown canary cell")
    batches = empirical.load_validation(root, scopes)
    cells = {key: build_cell(scope, batches[key]) for key, scope in scopes.items()}
    expected = empirical.baseline_references(root)
    receipts = {
        key: empirical.verify_baseline(cell, expected[key])
        for key, cell in cells.items()
    }
    selectors = fit_all(cells)
    inputs.append(protocol)
    metadata = freeze_header(args, revision, inputs, code)
    metadata.update(
        {
            "n_cells": len(cells),
            "n_selectors": len(selectors),
            "n_sources": len({cell.scope.source for cell in cells.values()}),
            "n_variants_per_cell": 38,
            "cells": [
                cell_manifest(cell, receipts[key]) for key, cell in cells.items()
            ],
            "selectors": selectors,
        }
    )
    validate_frozen_inputs(root, inputs, code, args.verification_only)
    if not args.verification_only and (len(cells) != 240 or len(selectors) != 9120):
        raise ValueError("The final safe-selector study omits declared cells/arms")
    write_outputs(root, args.output_prefix, metadata)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    main()
