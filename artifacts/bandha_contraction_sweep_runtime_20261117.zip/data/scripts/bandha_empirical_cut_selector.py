"""Fit empirical maximum-capture mixtures of three nested cut families.

We fit only on validation outcomes, after filtering the split. Serving uses
fixed ratio, group, and objection fields with at most two adjacent hull cuts
in each of three buckets. No future value, loss, ordering, or budget enters
the frozen rule. The original baseline comparator stays unchanged.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import logging
import math
import platform
import shlex
import sys
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import bandha_direct_constrained_selector as direct
import bandha_fairness_group_outcomes as outcomes
import numpy as np
import scipy
from numpy.typing import NDArray
from scipy.optimize import linprog, OptimizeResult
from scipy.sparse import csr_matrix


LOGGER: logging.Logger = logging.getLogger(__name__)
GENERATOR = "scripts/bandha_empirical_cut_selector.py"
PROTOCOL = "bandha_empirical_cut_protocol_20261104.md"
GAMMAS = (1.0, 0.75, 0.50, 0.25, 0.0)
MARGINS = (0.0, 0.05)
VALUE_CAP = 0.10
CAPTURE_FLOOR = 0.95
SOLVER_TOLERANCE = 1e-10
CHECK_TOLERANCE = 1e-8
EFFECT_TOLERANCE = 1e-10
CellKey = tuple[str, str, str]
FloatArray = NDArray[np.float64]
BUCKETS = ("pooled_nonobjectable", "group_0_objectable", "group_1_objectable")


class EmpiricalNumericalError(RuntimeError):
    """A hull, LP, compression, or serving certificate is invalid."""


@dataclass(frozen=True)
class Cut:
    threshold: float | None
    cost: float
    capture: float
    count: int


@dataclass
class ValidationBatch:
    group: NDArray[np.int64]
    ratio: FloatArray
    objectable: NDArray[np.bool_]
    value: FloatArray
    loss: FloatArray

    @property
    def size(self) -> int:
        return len(self.value)


@dataclass
class HullBank:
    scope: direct.Scope
    batch: ValidationBatch
    hulls: tuple[list[Cut], list[Cut], list[Cut]]
    raw_cuts: tuple[list[Cut], list[Cut], list[Cut]]
    totals: dict[str, Any]
    baseline: dict[str, Any]


@dataclass
class EmpiricalLP:
    bank: HullBank
    gamma: float
    margin: float
    vertex_bucket: NDArray[np.int64]
    vertex_index: NDArray[np.int64]
    capture: FloatArray
    matrix: csr_matrix
    rhs: FloatArray
    equality: csr_matrix


def bucket_ids(
    group: NDArray[np.int64], objectable: NDArray[np.bool_]
) -> NDArray[np.int64]:
    return np.where(objectable, group + 1, 0).astype(np.int64)


def validation_rows(
    root: Path, relative: str, scopes: Mapping[CellKey, direct.Scope]
) -> dict[CellKey, list[tuple]]:
    result: dict[CellKey, list[tuple]] = defaultdict(list)
    with gzip.open(root / relative, "rt", newline="") as handle:
        reader = csv.DictReader(handle)
        compact = "d" in (reader.fieldnames or ())
        for row in reader:
            dataset, seed, split, target = outcomes.candidate_key(row, compact)
            key = (dataset, str(seed), "value")
            if (
                split.lower() != "validation"
                or not math.isclose(target, VALUE_CAP)
                or key not in scopes
            ):
                continue
            forecast = direct.forecast_record(row, compact, scopes[key].groups)
            value = float(row["A"] if compact else row["value"])
            loss = float(row["B"] if compact else row["loss"])
            if not math.isfinite(value) or not math.isfinite(loss):
                raise ValueError("Nonfinite validation outcome")
            result[key].append(
                (
                    forecast.group,
                    forecast.ratio,
                    forecast.objectable,
                    max(value, 0.0),
                    max(loss, 0.0),
                )
            )
    return dict(result)


def validation_batch(values: list[tuple]) -> ValidationBatch:
    if not values:
        raise ValueError("Empty validation batch")
    array = np.asarray(values, dtype=np.float64)
    return ValidationBatch(
        array[:, 0].astype(np.int64),
        array[:, 1],
        array[:, 2].astype(bool),
        array[:, 3],
        array[:, 4],
    )


def load_validation(
    root: Path, scopes: Mapping[CellKey, direct.Scope]
) -> dict[CellKey, ValidationBatch]:
    inputs: dict[str, dict[CellKey, direct.Scope]] = defaultdict(dict)
    for key, scope in scopes.items():
        inputs[scope.relative_input][key] = scope
    result = {}
    for relative, cells in sorted(inputs.items()):
        loaded = validation_rows(root, relative, cells)
        if set(loaded) != set(cells):
            raise ValueError("A frozen cell lacks validation rows")
        result.update({key: validation_batch(values) for key, values in loaded.items()})
        LOGGER.info("Loaded validation outcomes only: %s", relative)
    return result


def totals(batch: ValidationBatch) -> dict[str, Any]:
    value = math.fsum(batch.value)
    loss = math.fsum(batch.loss)
    groups = [math.fsum(batch.value[batch.group == group]) for group in (0, 1)]
    if value <= 0.0 or any(group <= 0.0 for group in groups):
        raise ValueError("Validation group value support is unavailable")
    return {
        "value": value,
        "loss": loss,
        "loss_scale": loss if loss > 0.0 else 1.0,
        "group_value": groups,
    }


def moments(
    batch: ValidationBatch, pi: FloatArray, normalization: Mapping[str, Any]
) -> dict[str, float]:
    cost = math.fsum(batch.value * pi)
    capture = math.fsum(batch.loss * pi)
    levels = [
        math.fsum((batch.value * batch.objectable * pi)[batch.group == group])
        / normalization["group_value"][group]
        for group in (0, 1)
    ]
    return {
        "blocked_value": cost,
        "blocked_value_fraction": cost / normalization["value"],
        "captured_loss": capture,
        "normalized_capture": capture / normalization["loss_scale"],
        "D0": levels[0],
        "D1": levels[1],
        "absolute_gap": abs(levels[1] - levels[0]),
    }


def pure_cut(
    batch: ValidationBatch, bucket: int, threshold: float | None
) -> FloatArray:
    if threshold is None:
        return np.zeros(batch.size, dtype=np.float64)
    return (
        (bucket_ids(batch.group, batch.objectable) == bucket)
        & (batch.ratio >= threshold)
    ).astype(np.float64)


def raw_bucket_cuts(
    batch: ValidationBatch, bucket: int, baseline_threshold: float
) -> list[Cut]:
    mask = bucket_ids(batch.group, batch.objectable) == bucket
    ratio, value, loss = batch.ratio[mask], batch.value[mask], batch.loss[mask]
    if not len(ratio):
        return [Cut(None, 0.0, 0.0, 0)]
    order = np.argsort(-ratio, kind="stable")
    ratio, value, loss = ratio[order], value[order], loss[order]
    cost = np.cumsum(value, dtype=np.float64)
    capture = np.cumsum(loss, dtype=np.float64)
    ends = np.r_[np.flatnonzero(ratio[:-1] != ratio[1:]), len(ratio) - 1]
    result = [Cut(None, 0.0, 0.0, 0)]
    result.extend(
        Cut(
            float(ratio[index]),
            float(cost[index]),
            float(capture[index]),
            int(index + 1),
        )
        for index in ends
    )
    selected = ratio >= baseline_threshold
    result.append(
        Cut(
            baseline_threshold,
            math.fsum(value[selected]),
            math.fsum(loss[selected]),
            int(np.sum(selected)),
        )
    )
    return result


def best_same_cost(points: Iterable[Cut]) -> list[Cut]:
    result: dict[float, Cut] = {}
    for point in points:
        existing = result.get(point.cost)
        if existing is None or point.capture > existing.capture:
            result[point.cost] = point
        elif point.capture == existing.capture and point.count < existing.count:
            result[point.cost] = point
    return [result[cost] for cost in sorted(result)]


def upper_hull(points: list[Cut], normalization: Mapping[str, Any]) -> list[Cut]:
    hull = []
    for point in best_same_cost(points):
        while len(hull) >= 2:
            left, middle = hull[-2], hull[-1]
            x0 = (middle.cost - left.cost) / normalization["value"]
            x1 = (point.cost - middle.cost) / normalization["value"]
            y0 = (middle.capture - left.capture) / normalization["loss_scale"]
            y1 = (point.capture - middle.capture) / normalization["loss_scale"]
            if x0 * y1 - y0 * x1 < 0.0:
                break
            hull.pop()
        hull.append(point)
    return hull


def interpolate(hull: list[Cut], cost: float) -> tuple[int, int, float]:
    costs = np.asarray([point.cost for point in hull])
    if cost <= costs[0]:
        return 0, 0, 0.0
    if cost >= costs[-1]:
        return len(hull) - 1, len(hull) - 1, 0.0
    right = int(np.searchsorted(costs, cost, side="left"))
    if cost == costs[right]:
        return right, right, 0.0
    left = right - 1
    weight = (cost - costs[left]) / (costs[right] - costs[left])
    return left, right, float(weight)


def hull_receipt(
    raw: list[Cut], hull: list[Cut], normalization: Mapping[str, Any]
) -> dict[str, Any]:
    if hull[0].cost != min(point.cost for point in raw) or hull[-1].cost != max(
        point.cost for point in raw
    ):
        raise EmpiricalNumericalError("Upper hull lost a full-cost endpoint")
    errors = []
    for point in raw:
        left, right, weight = interpolate(hull, point.cost)
        capture = (1.0 - weight) * hull[left].capture + weight * hull[right].capture
        errors.append(max(0.0, point.capture - capture) / normalization["loss_scale"])
    maximum = max(errors, default=0.0)
    if maximum > CHECK_TOLERANCE:
        raise EmpiricalNumericalError(
            "Hull lies below an original cut at the same cost"
        )
    return {
        "raw_cuts": len(raw),
        "hull_vertices": len(hull),
        "minimum_cost": hull[0].cost,
        "maximum_cost": hull[-1].cost,
        "maximum_hull_coverage_error": maximum,
    }


def build_bank(scope: direct.Scope, batch: ValidationBatch) -> HullBank:
    normalization = totals(batch)
    baseline_pi = (
        (batch.ratio >= scope.baseline_threshold) & (batch.ratio > 0.0)
    ).astype(np.float64) * scope.baseline_alpha
    baseline = moments(batch, baseline_pi, normalization)
    raw = tuple(
        raw_bucket_cuts(batch, bucket, scope.baseline_threshold) for bucket in range(3)
    )
    hulls = tuple(upper_hull(points, normalization) for points in raw)
    for points, hull in zip(raw, hulls):
        hull_receipt(points, hull, normalization)
    return HullBank(scope, batch, hulls, raw, normalization, baseline)


def baseline_references(root: Path) -> dict[CellKey, Mapping[str, Any]]:
    with gzip.open(root / direct.INPUT_FREEZE, "rt") as handle:
        frozen = json.load(handle)
    return {
        (case["dataset"], str(case["seed"]), "value"): case
        for case in frozen["cases"]
        if case["currency"] == "value"
    }


def verify_baseline_group(
    bank: HullBank,
    pi: FloatArray,
    group: int,
    mass: Mapping[str, Any],
    integrity: outcomes.Integrity,
) -> None:
    mask = bank.batch.group == group
    selected = math.fsum((bank.batch.value * pi)[mask])
    complaint = math.fsum((bank.batch.value * pi * bank.batch.objectable)[mask])
    pairs = (
        (bank.totals["group_value"][group], mass["total_mass"], "group_total"),
        (selected, mass["selected_mass"], "baseline_selected_value"),
        (complaint, mass["complaint_mass"], "baseline_complaint_value"),
        (
            bank.baseline[f"D{group}"],
            mass["complaint_mass"] / mass["total_mass"],
            "baseline_group_level",
        ),
    )
    for actual, expected, name in pairs:
        integrity.equal(actual, expected, name, bank.scope.key)


def verify_baseline(bank: HullBank, reference: Mapping[str, Any]) -> dict[str, Any]:
    expected = reference["baseline"]
    groups = tuple(reference["groups"])
    if groups != bank.scope.groups:
        raise EmpiricalNumericalError(
            "Baseline group ordering differs from the original freeze"
        )
    pi = (
        (bank.batch.ratio >= bank.scope.baseline_threshold) & (bank.batch.ratio > 0.0)
    ).astype(float) * bank.scope.baseline_alpha
    original_masses = outcomes.ordered_masses(expected["masses"], groups)
    integrity = outcomes.Integrity(1e-11, 1e-8)
    integrity.equal(
        bank.baseline["blocked_value_fraction"],
        expected["budget"],
        "baseline_budget",
        bank.scope.key,
    )
    fraction = (
        bank.baseline["captured_loss"] / bank.totals["loss"]
        if bank.totals["loss"] > 0.0
        else 0.0
    )
    integrity.equal(
        fraction, expected["capture"], "baseline_capture_fraction", bank.scope.key
    )
    for group, mass in enumerate(original_masses):
        verify_baseline_group(bank, pi, group, mass, integrity)
    return {
        "comparisons": integrity.comparisons,
        "maximum_errors": integrity.maximum_absolute_errors,
        "original_baseline_preserved": True,
    }


def make_lp(bank: HullBank, gamma: float, margin: float) -> EmpiricalLP:
    if not 0.0 <= gamma <= 1.0 or not 0.0 <= margin <= 1.0:
        raise ValueError("Gamma and margin must lie in the unit interval")
    bucket = np.asarray(
        [group for group, hull in enumerate(bank.hulls) for _ in hull], dtype=np.int64
    )
    index = np.asarray(
        [position for hull in bank.hulls for position in range(len(hull))],
        dtype=np.int64,
    )
    cost = np.asarray([point.cost for hull in bank.hulls for point in hull])
    capture = (
        np.asarray([point.capture for hull in bank.hulls for point in hull])
        / bank.totals["loss_scale"]
    )
    d0 = np.where(bucket == 1, cost / bank.totals["group_value"][0], 0.0)
    d1 = np.where(bucket == 2, cost / bank.totals["group_value"][1], 0.0)
    matrix = csr_matrix(
        np.vstack((cost / bank.totals["value"], d1 - d0, d0 - d1, d0, d1))
    )
    epsilon = gamma * bank.baseline["absolute_gap"]
    rhs = np.asarray(
        (
            VALUE_CAP,
            epsilon,
            epsilon,
            (1.0 - margin) * bank.baseline["D0"],
            (1.0 - margin) * bank.baseline["D1"],
        )
    )
    equality = csr_matrix(
        np.asarray([bucket == group for group in range(3)], dtype=np.float64)
    )
    return EmpiricalLP(
        bank, gamma, margin, bucket, index, capture, matrix, rhs, equality
    )


def solve(problem: EmpiricalLP) -> OptimizeResult:
    result = linprog(
        -problem.capture,
        A_ub=problem.matrix,
        b_ub=problem.rhs,
        A_eq=problem.equality,
        b_eq=np.ones(3),
        bounds=(0.0, None),
        method="highs-ds",
        options={
            "presolve": False,
            "primal_feasibility_tolerance": SOLVER_TOLERANCE,
            "dual_feasibility_tolerance": SOLVER_TOLERANCE,
        },
    )
    if result.status != 0 or not np.isfinite(result.x).all():
        raise EmpiricalNumericalError(
            f"Hull LP failed despite zero-cost support: {result.status}, {result.message}"
        )
    return result


def weight_receipt(problem: EmpiricalLP, weights: FloatArray) -> dict[str, float]:
    errors = {
        "simplex_error": float(
            np.max(np.abs(problem.equality @ weights - 1.0), initial=0.0)
        ),
        "negative_weight_error": float(np.max(np.maximum(-weights, 0.0), initial=0.0)),
        "constraint_error": float(
            np.max(np.maximum(problem.matrix @ weights - problem.rhs, 0.0), initial=0.0)
        ),
    }
    if max(errors.values()) > CHECK_TOLERANCE:
        raise EmpiricalNumericalError(f"Original LP constraints failed: {errors}")
    return errors


def dual_upper_bound(
    problem: EmpiricalLP, result: OptimizeResult
) -> tuple[FloatArray, float]:
    dual = -np.asarray(result.ineqlin.marginals)
    if np.min(dual) < -CHECK_TOLERANCE:
        raise EmpiricalNumericalError("Negative upper-inequality multiplier")
    dual = np.maximum(dual, 0.0)
    profit = problem.capture - problem.matrix.T @ dual
    upper = float(dual @ problem.rhs) + math.fsum(
        float(np.max(profit[problem.vertex_bucket == bucket])) for bucket in range(3)
    )
    primal = float(problem.capture @ result.x)
    if abs(upper - primal) > CHECK_TOLERANCE:
        raise EmpiricalNumericalError(
            "Independent three-simplex dual bound disagrees with the optimum"
        )
    return dual, upper


def compress_bucket(
    problem: EmpiricalLP, weights: FloatArray, bucket: int
) -> dict[str, Any]:
    mask = problem.vertex_bucket == bucket
    hull = problem.bank.hulls[bucket]
    expected_cost = math.fsum(
        float(weight) * point.cost for weight, point in zip(weights[mask], hull)
    )
    original_capture = math.fsum(
        float(weight) * point.capture for weight, point in zip(weights[mask], hull)
    )
    outside = max(0.0, hull[0].cost - expected_cost, expected_cost - hull[-1].cost)
    if outside / problem.bank.totals["value"] > CHECK_TOLERANCE:
        raise EmpiricalNumericalError("Mixture cost lies outside the full hull range")
    left, right, mix = interpolate(hull, expected_cost)
    cost = (1.0 - mix) * hull[left].cost + mix * hull[right].cost
    capture = (1.0 - mix) * hull[left].capture + mix * hull[right].capture
    if (
        abs(cost - expected_cost) / problem.bank.totals["value"] > CHECK_TOLERANCE
        or capture
        < original_capture - CHECK_TOLERANCE * problem.bank.totals["loss_scale"]
    ):
        raise EmpiricalNumericalError(
            "Adjacent-hull compression changes cost or loses capture"
        )
    return {
        "bucket": bucket,
        "hull_indices": [left, right],
        "hull_size": len(hull),
        "thresholds": [hull[left].threshold, hull[right].threshold],
        "right_weight": mix,
        "expected_cost": cost,
        "expected_capture": capture,
        "original_lp_cost": expected_cost,
        "original_lp_capture": original_capture,
        "adjacent_or_same": right - left in (0, 1),
    }


def probability(forecast: direct.Forecast, selector: Mapping[str, Any]) -> float:
    if not selector["defined"]:
        raise EmpiricalNumericalError("Undefined empirical cut policy")
    bucket = forecast.group + 1 if forecast.objectable else 0
    rule = selector["bucket_rules"][bucket]
    left, right = rule["thresholds"]
    lower = float(left is not None and forecast.ratio >= left)
    upper = float(right is not None and forecast.ratio >= right)
    return (1.0 - rule["right_weight"]) * lower + rule["right_weight"] * upper


def batch_probability(
    forecasts: direct.PredictionBatch | ValidationBatch, selector: Mapping[str, Any]
) -> FloatArray:
    if not selector["defined"]:
        raise EmpiricalNumericalError("Undefined empirical cut policy")
    result = np.zeros(len(forecasts.ratio), dtype=np.float64)
    buckets = bucket_ids(forecasts.group, forecasts.objectable)
    for rule in selector["bucket_rules"]:
        mask = buckets == rule["bucket"]
        left, right = rule["thresholds"]
        lower = (
            (forecasts.ratio[mask] >= left).astype(float)
            if left is not None
            else np.zeros(int(np.sum(mask)))
        )
        upper = (
            (forecasts.ratio[mask] >= right).astype(float)
            if right is not None
            else np.zeros(int(np.sum(mask)))
        )
        result[mask] = (1.0 - rule["right_weight"]) * lower + rule[
            "right_weight"
        ] * upper
    return result


def validation_receipt(
    problem: EmpiricalLP, rules: list[dict[str, Any]], upper: float
) -> dict[str, Any]:
    cost = math.fsum(rule["expected_cost"] for rule in rules)
    capture = math.fsum(rule["expected_capture"] for rule in rules)
    d0 = rules[1]["expected_cost"] / problem.bank.totals["group_value"][0]
    d1 = rules[2]["expected_cost"] / problem.bank.totals["group_value"][1]
    lhs = np.asarray((cost / problem.bank.totals["value"], d1 - d0, d0 - d1, d0, d1))
    error = float(np.max(np.maximum(lhs - problem.rhs, 0.0), initial=0.0))
    gap = abs(upper - capture / problem.bank.totals["loss_scale"])
    if max(error, gap) > CHECK_TOLERANCE:
        raise EmpiricalNumericalError(
            "Compressed rule fails feasibility or independent optimality"
        )
    baseline = problem.bank.baseline["captured_loss"]
    return {
        "retained_capture_fraction": capture / baseline if baseline > 0.0 else None,
        "blocked_value_fraction": lhs[0],
        "D0": d0,
        "D1": d1,
        "absolute_gap": abs(d1 - d0),
        "captured_loss": capture,
        "group_0_limit": float(problem.rhs[3]),
        "group_1_limit": float(problem.rhs[4]),
        "original_constraints_met": True,
        "max_constraint_error": error,
        "independent_dual_upper_bound": upper,
        "independent_two_sided_dual_gap": gap,
    }


def serving_receipt(bank: HullBank, selector: Mapping[str, Any]) -> dict[str, float]:
    pi = batch_probability(bank.batch, selector)
    actual = moments(bank.batch, pi, bank.totals)
    expected = selector["validation"]
    errors = {
        name + "_error": abs(actual[name] - expected[name])
        for name in ("D0", "D1", "absolute_gap", "blocked_value_fraction")
    }
    errors["capture_error"] = (
        abs(actual["captured_loss"] - expected["captured_loss"])
        / bank.totals["loss_scale"]
    )
    if max(errors.values()) > CHECK_TOLERANCE:
        raise EmpiricalNumericalError(
            "Frozen thresholds do not replay the hull moments"
        )
    return errors


def selector_identity(
    scope: direct.Scope, gamma: float, margin: float
) -> dict[str, Any]:
    return {
        "kind": "empirical_cut",
        "dataset": scope.key[0],
        "seed": scope.key[1],
        "measurement_unit": "value",
        "source": scope.source,
        "input": scope.relative_input,
        "groups": list(scope.groups),
        "gamma": gamma,
        "margin": margin,
        "capture_floor": CAPTURE_FLOOR,
        "baseline_index": scope.baseline_index,
        "baseline_threshold": scope.baseline_threshold,
        "baseline_alpha": scope.baseline_alpha,
    }


def fit_selector(bank: HullBank, gamma: float, margin: float) -> dict[str, Any]:
    problem = make_lp(bank, gamma, margin)
    result = solve(problem)
    primal = weight_receipt(problem, result.x)
    dual, upper = dual_upper_bound(problem, result)
    rules = [compress_bucket(problem, result.x, bucket) for bucket in range(3)]
    validation = validation_receipt(problem, rules, upper)
    selector = {
        **selector_identity(bank.scope, gamma, margin),
        "defined": True,
        "support_status": "valid",
        "solver_status": 0,
        "bucket_rules": rules,
        "epsilon": float(problem.rhs[1]),
        "group_caps": [float(value) for value in problem.rhs[3:]],
        "group_value_totals": bank.totals["group_value"],
        "validation_value_total": bank.totals["value"],
        "validation_loss_total": bank.totals["loss"],
        "reference": bank.baseline,
        "validation": validation,
        "primal_receipt": primal,
        "dual_multipliers": dual.tolist(),
        "hull_receipts": [
            hull_receipt(raw, hull, bank.totals)
            for raw, hull in zip(bank.raw_cuts, bank.hulls)
        ],
    }
    selector["serving_receipt"] = serving_receipt(bank, selector)
    selector["fitted_capture_floor_met"] = (
        validation["captured_loss"]
        >= (CAPTURE_FLOOR - EFFECT_TOLERANCE) * bank.baseline["captured_loss"]
    )
    return selector


def hull_manifest(bank: HullBank) -> dict[str, Any]:
    return {
        "dataset": bank.scope.key[0],
        "seed": bank.scope.key[1],
        "input": bank.scope.relative_input,
        "buckets": [
            {
                "bucket": bucket,
                "name": BUCKETS[bucket],
                "raw_cut_count": len(bank.raw_cuts[bucket]),
                "vertices": [asdict(point) for point in bank.hulls[bucket]],
            }
            for bucket in range(3)
        ],
    }


def summary_row(selector: Mapping[str, Any]) -> dict[str, Any]:
    result = {
        name: selector[name]
        for name in (
            "kind",
            "dataset",
            "seed",
            "source",
            "measurement_unit",
            "gamma",
            "margin",
            "defined",
            "solver_status",
            "capture_floor",
            "epsilon",
            "fitted_capture_floor_met",
        )
    }
    result.update(
        {"validation_" + name: value for name, value in selector["validation"].items()}
    )
    result.update(
        {"reference_" + name: value for name, value in selector["reference"].items()}
    )
    for rule in selector["bucket_rules"]:
        bucket = rule["bucket"]
        result[f"bucket_{bucket}_left_threshold"] = rule["thresholds"][0]
        result[f"bucket_{bucket}_right_threshold"] = rule["thresholds"][1]
        result[f"bucket_{bucket}_right_weight"] = rule["right_weight"]
        result[f"bucket_{bucket}_hull_size"] = rule["hull_size"]
    return result


def write_outputs(root: Path, prefix: str, metadata: dict[str, Any]) -> None:
    directory = root / "results" / "csvs"
    csv_path = directory / f"{prefix}_validation_selections.csv"
    rows = [summary_row(selector) for selector in metadata["selectors"]]
    with csv_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    metadata["outputs"] = [
        {"path": str(csv_path.relative_to(root)), "sha256": outcomes.digest(csv_path)}
    ]
    path = directory / f"{prefix}_validation_freeze.json"
    path.write_text(
        json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )


def code_identities(root: Path, verification: bool) -> list[dict[str, Any]]:
    names = (GENERATOR, direct.GENERATOR, "scripts/bandha_fairness_group_outcomes.py")
    if not verification:
        return [outcomes.committed_input(root, name, "HEAD") for name in names]
    return [{"path": name, "sha256": outcomes.digest(root / name)} for name in names]


def study_metadata() -> dict[str, Any]:
    return {
        "gamma_scope": list(GAMMAS),
        "margin_scope": list(MARGINS),
        "primary_gamma": 0.5,
        "primary_margin": 0.0,
        "capture_floor": CAPTURE_FLOOR,
        "value_cap": VALUE_CAP,
        "solver_tolerance": SOLVER_TOLERANCE,
        "checked_tolerance": CHECK_TOLERANCE,
        "heldout_outcomes_parsed": False,
        "validation_outcomes_used_for_fit": True,
        "future_outcomes_used_for_policy": False,
        "buckets": list(BUCKETS),
        "objective": "maximum_validation_captured_loss_in_three_nested_cut_families",
        "same_cost_duplicates": "Maximum capture, then fewer selected validation candidates; the original comparator remains unchanged.",
        "cost_range": "Every hull retains both full-cost-range endpoints; no different-cost dominance filter.",
    }


def metadata(
    root: Path,
    revision: str,
    inputs: list[dict[str, Any]],
    selectors: list[dict[str, Any]],
    banks: Mapping[CellKey, HullBank],
    verification: bool,
    references: Mapping[CellKey, Mapping[str, Any]],
) -> dict[str, Any]:
    return {
        "generator": GENERATOR,
        "schema_version": 1,
        "phase": "select",
        "complete": True,
        "verification_only": verification,
        "input_revision": revision,
        "n_cells": len(banks),
        "n_selectors": len(selectors),
        "inputs": inputs,
        "implementation": code_identities(root, verification),
        "protocol": {"path": PROTOCOL, "sha256": outcomes.digest(root / PROTOCOL)},
        "command": [sys.executable, *sys.argv],
        "command_shell": shlex.join([sys.executable, *sys.argv]),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        **study_metadata(),
        "baseline_verification": [
            {"dataset": key[0], "seed": key[1], **value}
            for key, value in references.items()
        ],
        "hulls": [hull_manifest(bank) for bank in banks.values()],
        "selectors": selectors,
    }


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--input-revision", default="HEAD")
    parser.add_argument("--output-prefix", default="bandha_empirical_cut")
    parser.add_argument("--verification-only", action="store_true")
    parser.add_argument("--canary-cell", action="append", default=[])
    result = parser.parse_args()
    if not result.output_prefix.startswith("bandha_empirical_cut") or any(
        value not in "abcdefghijklmnopqrstuvwxyz0123456789_"
        for value in result.output_prefix
    ):
        raise ValueError("Outputs must remain in the empirical-cut area")
    if result.canary_cell and not result.verification_only:
        raise ValueError("Partial-cell canaries must be verification-only")
    return result


def main() -> None:
    args = arguments()
    root = args.root.resolve()
    revision = outcomes.git_output(root, ["rev-parse", args.input_revision])
    if not args.verification_only:
        outcomes.committed_input(root, GENERATOR, "HEAD")
    protocol = outcomes.committed_input(root, PROTOCOL, "HEAD")
    code = code_identities(root, args.verification_only)
    scopes, inputs = direct.load_scopes(root, revision)
    if args.canary_cell:
        requested = {tuple(value.rsplit(":", 1)) for value in args.canary_cell}
        scopes = {key: scope for key, scope in scopes.items() if key[:2] in requested}
        if {key[:2] for key in scopes} != requested:
            raise ValueError("Unknown verification cell")
    batches = load_validation(root, scopes)
    banks = {key: build_bank(scope, batches[key]) for key, scope in scopes.items()}
    expected = baseline_references(root)
    references = {
        key: verify_baseline(bank, expected[key]) for key, bank in banks.items()
    }
    selectors = [
        fit_selector(bank, gamma, margin)
        for bank in banks.values()
        for gamma in GAMMAS
        for margin in MARGINS
    ]
    inputs.append(protocol)
    result = metadata(
        root, revision, inputs, selectors, banks, args.verification_only, references
    )
    if result["implementation"] != code:
        raise ValueError("Code changed during validation selection")
    for item in inputs:
        if outcomes.digest(root / item["path"]) != item["sha256"]:
            raise ValueError("Frozen data or protocol changed during selection")
    if not args.verification_only and (len(banks) != 240 or len(selectors) != 2400):
        raise ValueError("Final selection omits a declared cell or target")
    write_outputs(root, args.output_prefix, result)
    LOGGER.info("Frozen empirical-cut selectors: %s", len(selectors))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    main()
