# Contraction budget and capture-floor sensitivity

Owner: bandha. User authorized this replay on 2026-11-17.
We fix this specification before fitting the new C policies or computing
their T outcomes. The original T data have already been examined, so this
study supplies exploratory sensitivity evidence.

## Scope

We use the current XGBoost primary's 24 settings, ten seeds and exact
training/V/C/T memberships. We reuse its frozen baseline and two raw-mean
predictions. We train no model and run no Fairlearn or reductions fit.

We evaluate all nine combinations of blocked-value cap beta in
`(0.05, 0.10, 0.20)` and capture floor rho in `(0.90, 0.95, 0.99)`.
Every combination retains all 240 cases. We compare common contraction
with uniform `rho*pi0` thinning on identical rows and under identical
criteria. The 0.10/0.95 combination must reproduce the existing primary.

## Budget-specific V calibration

For each beta, we use the original whole-score `threshold_for_mass`
procedure on V's frozen baseline score and value. We set the baseline
fractional multiplier by the original V budget formula. For harm and
net harm at lambda0=1, we apply the same threshold procedure to the frozen
mean scores and regenerate their binary columns in V, C and T. We retain
the original whole-score criterion tie convention, including possible
criterion-budget overshoot. We change no criterion definition or count.

A different beta changes both the baseline and the contested-candidate
set. Removal and capture-retention comparisons therefore use each beta's
own matched baseline and fixed criteria. We also retain absolute baseline
capture as a fraction of the subset's total loss, and realized baseline
blocked-value fractions, to make the cap sweep interpretable as a curve.

## C policy fitting and T evaluation

We build each beta's replacement cuts on V. C fits the smallest common
factor and replacement mixture under that beta and rho, using exactly
those V cuts and the existing `fit_max_removal` solver. Changing rho
requires new C parameters, while the baseline and criterion cuts remain
fixed within that beta. We retain the existing resource-infeasible anchor
and capture-infeasible best-capture fallback. Unexpected numerical errors
stop execution; no case is discarded.

We seal all 2,160 C policies before T evaluation. T changes no threshold,
factor, mixture, cap or floor. We verify original C seals and prediction
hashes, baseline/criterion reconstruction at beta 0.10, and the original
0.10/0.95 C and T outcomes. We check probability bounds, pointwise common
contraction, group nonincrease and all three objection aggregations.

## Summaries and interpretation

We keep all nine combinations and all feasibility failures. For each
combination we give defined-ratio support, removal, capture retention,
capture and value attainment, joint attainment, and C infeasibility counts.
We give both run means and equal-source summaries. We compute the paired
common-minus-thinning contrast across source-family means using the same
Student-t interval convention as the existing primary. Undefined ratios
remain explicit; inadequate family support receives no interval.

We make no independent-confirmation, global-optimality or causal claim.
No outcome, favorable or unfavorable, changes the primary 0.10/0.95
specification or which sweep points appear in the full result.

## Pre-registered prediction, before any sweep outcome exists

Owner: ushmoo. Written while only the 0.10/0.95 point is known. This sweep
is not only a robustness check: it is the first quantitative test of the
manuscript's claim that headroom, and not the objected share, is the
binding term of the capture bound. That claim can fail here.

Two facts make the floor sweep a sharp test. First, by Proposition 1 the
measured relative removal **equals** `1 - s`, so the bound caps the reported
number directly rather than some proxy for it. Second, within a fixed beta
both `sigma = B_q/B_0` and `h = H_B/B_0` are properties of the baseline and
the criteria alone and **do not depend on rho**. So across the three floors
at one beta the bound is exactly

    removal <= ((1 - rho) + h) / sigma ,    h, sigma constant in rho.

Calibrating `h` from the one known point, mean removal .4759 at rho .95 with
family-median sigma .567, gives `h` about .22 if that fit sits on the bound.
The two competing readings then separate by more than twentyfold:

| rho  | headroom reading | share-only reading (h = 0) |
| ---: | ---------------: | -------------------------: |
| .90  |            ~56%  |                      ~17.6% |
| .95  |            ~47%  |                       ~8.8% |
| .99  |            ~41%  |                       ~1.8% |

**What confirms the manuscript:** removal at rho .99 stays far above the
share-only ceiling, and removal falls roughly linearly in rho with slope no
steeper than `1/sigma`, about 1.8 points of removal per point of floor.

**What falsifies it:** removal at rho .99 collapses toward `(1-rho)/sigma`.
Then the objected share is the operative limit after all, the paragraph
titled "Headroom, not objection share, as the binding limit" is wrong as
written, and it gets rewritten rather than hedged.

Two honest qualifications. The bound is an upper bound, so a fit below it
at some rho is not a falsification by itself; only the collapse toward the
share-only ceiling is. And `h` was calibrated from a single point assuming
that fit is tight, so the table is an order-of-magnitude discriminator
between two readings, not a point forecast to be scored.

Across beta the test is weaker, since beta moves `sigma` and `h` together
and also redefines the contested set. The within-beta floor sweep is the
clean comparison; the cap sweep is descriptive.

## Artifacts

- Public runner: `fairness/bandha_contraction_sweep_20261117.py` in
  `github-yielding_fairness`.
- Original cache: `~/.cache/bandha_fsl_xgboost_20261113/`.
- New cache: `~/.cache/bandha_contraction_sweep_20261117/`.
- Frozen C/T CSVs and C freeze:
  `results/csvs/bandha_contraction_sweep_20261117/`.
- CSV-only generator: `scripts/bandha_contraction_sweep_summary_20261117.py`.
- Generated result: `results/bandha_contraction_sweep_20261117/`.

The runner's `fit` command precedes its separate `test` command. We commit
the protocol, runner and summary generator before the full execution and
bind their hashes in the new source identity. We update the result and
provenance indexes before adding manuscript evidence. Overleaf compiles
the manuscript.
