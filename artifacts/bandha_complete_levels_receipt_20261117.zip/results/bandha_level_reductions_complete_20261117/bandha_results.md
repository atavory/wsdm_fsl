# Completed direct-level reductions comparison

Generator: `scripts/bandha_complete_level_results_20261117.py`.

Both original objectives completed all 240 cases and T evaluation. We reused 180 value C seals and completed the remaining 60 with the corrected constant-classifier exporter. The 60 reruns reproduce the partial C predictions exactly. We authorized the value continuation after examining capture results; both arms are exploratory, and this timing remains explicit.

## Frozen T comparison

Means retain every case and resource failure. Value removal has 238 defined ratios; capture has 240. Joint attainment requires both business targets and every defined original count/value/loss group bound. Undefined group denominators contribute no constraint.

| Policy | Value removal | Capture | Original value levels safe | All defined levels safe | Joint attainment |
| --- | ---: | ---: | ---: | ---: | ---: |
| Thinning | 5.00% | 95.00% | 240 | 240 | 183 |
| Common contraction | 47.59% | 94.62% | 240 | 240 | 57 |
| Earlier gap EG + C calibration | -21.26% | 104.37% | 70 | 48 | 16 |
| Direct levels, capture objective, raw EG | 20.18% | 105.34% | 175 | 126 | 8 |
| Direct levels, capture objective, C calibration | 12.95% | 99.10% | 194 | 166 | 65 |
| Direct levels, value objective, raw EG | 71.43% | 51.07% | 217 | 214 | 8 |
| Direct levels, value objective, C calibration | 22.59% | 91.02% | 229 | 220 | 66 |

## Refinements among jointly compliant cases

- Direct levels, capture objective, C calibration: 65 compliant cases; 22 increase a value level after baseline-support refinement, and 17 after V-score-quintile refinement.
- Direct levels, value objective, C calibration: 66 compliant cases; 37 increase a value level after baseline-support refinement, and 31 after V-score-quintile refinement.

Finite group-level constraints do not imply bounds for every finer partition. These results also do not establish overall dominance of common contraction: means, capture, resource attainment, and level protection measure different outcomes.

## Validation and timing

480/480 fits satisfy the original training tolerance. The largest active calibrated C constraint violation is 1.33227e-15; capture-infeasible cases retain the original fallback. The earlier capture freeze and outputs remain unchanged. No objective, split, threshold or learner hyperparameter changed in the continuation.

The original value-arm withdrawal preceded capture evaluation. The later user instruction resumed that same arm after capture outcomes had been seen. We retain the old withdrawal and the partial files as history; the value arm is now complete. No independent confirmation or significance claim follows from this continuation.
