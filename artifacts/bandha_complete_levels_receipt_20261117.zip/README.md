# Completed direct-level reductions receipt

Both original objectives completed 240 cases, including T evaluation. The value continuation followed examination of the capture results. The archive preserves that timing and every resource failure.

Extract the archive and run, using Python stdlib:

```sh
python3 scripts/bandha_complete_level_results_20261117.py --root . --frozen results/csvs/bandha_level_reductions_complete_20261117 --output verification
```

The generated JSON and Markdown reproduce the complete comparison, both group-refinement checks, equal-source summaries and matched value-cap comparisons. Fitted models and original raw inputs remain in the experiment cache and are required for prediction reconstruction.
