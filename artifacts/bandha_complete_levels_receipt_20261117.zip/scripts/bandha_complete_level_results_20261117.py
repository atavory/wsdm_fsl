"""Generate the completed level comparison from frozen CSVs only."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics as st
import zipfile
from collections import defaultdict
from pathlib import Path


EPSILON = 1e-10
LABELS = {
    "thinning": "Thinning",
    "common": "Common contraction",
    "agarwal_eg_Ccal": "Earlier gap EG + C calibration",
    "levels_capture_raw": "Direct levels, capture objective, raw EG",
    "levels_capture_Ccal": "Direct levels, capture objective, C calibration",
    "levels_value_raw": "Direct levels, value objective, raw EG",
    "levels_value_Ccal": "Direct levels, value objective, C calibration",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open() as handle:
        return list(csv.DictReader(handle))


def yes(value):
    return str(value).lower() == "true"


def cell(row):
    return row["dataset"] + "__" + row["seed"]


def statuses(records):
    grouped = defaultdict(list)
    for row in records:
        grouped[cell(row)].append(row)
    result = {}
    for key, rows in grouped.items():
        if len(rows) != 3 or {r["unit"] for r in rows} != {"count", "value", "loss"}:
            raise ValueError("Expected exactly three aggregation rows: " + key)
        value = next(r for r in rows if r["unit"] == "value")
        changes = {
            (r["unit"], group): float(r[f"group_{group}_level"])
            - float(r[f"group_{group}_baseline"])
            for r in rows
            for group in (0, 1)
            if r[f"group_{group}_level"] != "" and r[f"group_{group}_baseline"] != ""
        }
        value_safe = all(
            ("value", g) in changes and changes["value", g] <= EPSILON for g in (0, 1)
        )
        safe = bool(changes) and max(changes.values()) <= EPSILON
        business = yes(value["capture_target_met"]) and yes(value["value_cap_met"])
        result[key] = {
            "business": business,
            "value_safe": value_safe,
            "all_defined_safe": safe,
            "all_six_defined": len(changes) == 6,
            "joint_value": business and value_safe,
            "joint_all_defined": business and safe,
        }
    return result


def summary(records):
    value = [r for r in records if r["unit"] == "value"]
    states = list(statuses(records).values())
    removals = [float(r["removal"]) for r in value if r["removal"] != ""]
    return {
        "cells": len(value),
        "value_removal_support": len(removals),
        "mean_value_removal_percent": 100 * st.mean(removals),
        "mean_capture_percent": 100
        * st.mean(float(r["capture_retained"]) for r in value),
        "value_cap_met": sum(yes(r["value_cap_met"]) for r in value),
        "capture_floor_met": sum(yes(r["capture_target_met"]) for r in value),
        **{
            key: sum(s[key] for s in states)
            for key in (
                "business",
                "value_safe",
                "all_defined_safe",
                "all_six_defined",
                "joint_value",
                "joint_all_defined",
            )
        },
        "positive_added_value_objections": sum(
            float(r["added_objection_mass"]) > 1e-8 for r in value
        ),
    }


def source_equal(records):
    grouped = defaultdict(list)
    for row in records:
        grouped[row["source"]].append(row)
    sources = [summary(rows) for rows in grouped.values()]
    return {
        "sources": len(sources),
        "mean_value_removal_percent": st.mean(
            s["mean_value_removal_percent"] for s in sources
        ),
        "mean_capture_percent": st.mean(s["mean_capture_percent"] for s in sources),
        "joint_all_defined_rate_percent": 100
        * st.mean(s["joint_all_defined"] / s["cells"] for s in sources),
    }


def tables(root, frozen, part):
    paths = [
        root / f"results/csvs/bandha_xgboost_20261113/main/{part}.csv",
        root / f"results/csvs/bandha_agarwal_original_train_20261114/bandha_{part}.csv",
        frozen / f"bandha_{part}.csv",
    ]
    result = defaultdict(list)
    for path in paths:
        for row in read_csv(path):
            method = row.get("policy") or row.get("family")
            if method in LABELS:
                result[method].append(row)
    if set(result) != set(LABELS) or any(
        len(statuses(rows)) != 240 for rows in result.values()
    ):
        raise ValueError("Incomplete or duplicated comparison")
    return dict(result), paths


def refinements(rows, comparison, part):
    grouped = defaultdict(list)
    for row in rows:
        if row["part"] == part:
            grouped[row["family"]].append(row)
    result = {}
    for method, moments in grouped.items():
        state = statuses(comparison[method])
        result[method] = {}
        for selection in (
            "all",
            "all_defined_safe",
            "joint_value",
            "joint_all_defined",
        ):
            selected = {
                key
                for key, status in state.items()
                if selection == "all" or status[selection]
            }
            result[method][selection] = {"cells": len(selected)}
            for partition in ("baseline_support", "V_score_quintile"):
                changes = [
                    r
                    for r in moments
                    if r["cell"] in selected and r["partition"] == partition
                ]
                increasing = {
                    r["cell"]
                    for r in changes
                    if (
                        float(r["after_objection_value"])
                        - float(r["before_objection_value"])
                    )
                    / float(r["total_value"])
                    > EPSILON
                }
                result[method][selection][partition + "_increases"] = len(increasing)
    return result


def matched_cap(comparison):
    common = {cell(r): r for r in comparison["common"] if r["unit"] == "value"}
    result = {}
    for method in ("levels_capture_Ccal", "levels_value_Ccal"):
        candidate = {cell(r): r for r in comparison[method] if r["unit"] == "value"}
        selected = {
            key
            for key in common
            if yes(common[key]["value_cap_met"])
            and yes(candidate[key]["value_cap_met"])
        }
        result[method] = {
            "cells": len(selected),
            "common": summary([r for r in comparison["common"] if cell(r) in selected]),
            "candidate": summary(
                [r for r in comparison[method] if cell(r) in selected]
            ),
        }
    return result


def training_summary(rows):
    result = {}
    for objective in ("capture", "value"):
        selected = [r for r in rows if r["objective"] == objective]
        if len(selected) != 240:
            raise ValueError("Missing fit diagnostics")
        result[objective] = {
            "fits": len(selected),
            "gap_converged": sum(yes(r["gap_converged"]) for r in selected),
            "maximum_training_gap": max(float(r["best_gap"]) for r in selected),
            "C_capture_floor_feasible": sum(
                r["C_status"] == "feasible_acquired_bank" for r in selected
            ),
            "C_maximum_active_violation": max(
                float(r["C_active_max_violation"]) for r in selected
            ),
            "feature_reconstruction_maximum_error": max(
                float(r["feature_reconstruction_max_error"]) for r in selected
            ),
            "refitted_in_continuation": sum(
                yes(r["refitted_in_continuation"]) for r in selected
            ),
            "partial_C_maximum_absolute_difference": max(
                float(r["partial_C_max_absolute_difference"]) for r in selected
            ),
        }
    return result


def markdown(result):
    converged = sum(r["gap_converged"] for r in result["training"].values())
    violation = max(
        r["C_maximum_active_violation"] for r in result["training"].values()
    )
    validation = f"{converged}/480 fits satisfy the original training tolerance. The largest active calibrated C constraint violation is {violation:.6g}; capture-infeasible cases retain the original fallback. The earlier capture freeze and outputs remain unchanged. No objective, split, threshold or learner hyperparameter changed in the continuation."
    lines = [
        "# Completed direct-level reductions comparison",
        "",
        "Generator: `scripts/bandha_complete_level_results_20261117.py`.",
        "",
        "Both original objectives completed all 240 cases and T evaluation. We reused 180 value C seals and completed the remaining 60 with the corrected constant-classifier exporter. The 60 reruns reproduce the partial C predictions exactly. We authorized the value continuation after examining capture results; both arms are exploratory, and this timing remains explicit.",
        "",
        "## Frozen T comparison",
        "",
        "Means retain every case and resource failure. Value removal has 238 defined ratios; capture has 240. Joint attainment requires both business targets and every defined original count/value/loss group bound. Undefined group denominators contribute no constraint.",
        "",
        "| Policy | Value removal | Capture | Original value levels safe | All defined levels safe | Joint attainment |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for method, name in LABELS.items():
        s = result["summaries"]["T"][method]
        lines.append(
            f"| {name} | {s['mean_value_removal_percent']:.2f}% | {s['mean_capture_percent']:.2f}% | {s['value_safe']} | {s['all_defined_safe']} | {s['joint_all_defined']} |"
        )
    lines.extend(["", "## Refinements among jointly compliant cases", ""])
    for method in ("levels_capture_Ccal", "levels_value_Ccal"):
        r = result["refinements"]["T"][method]["joint_all_defined"]
        lines.append(
            f"- {LABELS[method]}: {r['cells']} compliant cases; {r['baseline_support_increases']} increase a value level after baseline-support refinement, and {r['V_score_quintile_increases']} after V-score-quintile refinement."
        )
    lines.extend(
        [
            "",
            "Finite group-level constraints do not imply bounds for every finer partition. These results also do not establish overall dominance of common contraction: means, capture, resource attainment, and level protection measure different outcomes.",
            "",
            "## Validation and timing",
            "",
            validation,
            "",
            "The original value-arm withdrawal preceded capture evaluation. The later user instruction resumed that same arm after capture outcomes had been seen. We retain the old withdrawal and the partial files as history; the value arm is now complete. No independent confirmation or significance claim follows from this continuation.",
            "",
        ]
    )
    return "\n".join(lines)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--frozen", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path)
    return parser.parse_args()


def build_result(args, export):
    comparison, inputs = {}, []
    for part in ("C", "T"):
        comparison[part], paths = tables(args.root, args.frozen, part)
        inputs.extend(paths)
    moments = read_csv(args.frozen / "bandha_refinement_moments.csv")
    inputs.extend(
        [
            args.frozen / "bandha_refinement_moments.csv",
            args.frozen / "bandha_fit_diagnostics.csv",
            args.frozen / "bandha_EXPORT.json",
        ]
    )
    return {
        "scope": "Both original objectives; exploratory value continuation after capture T examination.",
        "inputs": {str(path.relative_to(args.root)): digest(path) for path in inputs},
        "generator_sha256": digest(Path(__file__)),
        "completion": export,
        "training": training_summary(
            read_csv(args.frozen / "bandha_fit_diagnostics.csv")
        ),
        "summaries": {
            part: {method: summary(rows) for method, rows in selected.items()}
            for part, selected in comparison.items()
        },
        "source_equal_T": {
            method: source_equal(rows) for method, rows in comparison["T"].items()
        },
        "shared_value_cap_T": matched_cap(comparison["T"]),
        "refinements": {
            part: refinements(moments, comparison[part], part) for part in ("C", "T")
        },
    }


def paper_passage(result):
    capture = result["summaries"]["T"]["levels_capture_Ccal"]
    value = result["summaries"]["T"]["levels_value_Ccal"]
    common = result["summaries"]["T"]["common"]
    refinements = result["refinements"]["T"]
    cap_new = refinements["levels_capture_Ccal"]["joint_all_defined"][
        "baseline_support_increases"
    ]
    value_new = refinements["levels_value_Ccal"]["joint_all_defined"][
        "baseline_support_increases"
    ]
    return (
        "% Generator: scripts/bandha_complete_level_results_20261117.py\n"
        "With the same learner and splits, we constrain nonincrease of both\n"
        "original groups' levels in count, value and loss. After mixture\n"
        "calibration on the tuning half, the capture objective attains both\n"
        f"business targets and all six level bounds in ${capture['joint_all_defined']}/240$\n"
        f"cells of $T$, versus common contraction's ${common['joint_all_defined']}$, at mean value\n"
        f"removal ${capture['mean_value_removal_percent']:.2f}\\%$ versus ${common['mean_value_removal_percent']:.2f}\\%$. The value-objection\n"
        f"objective attains ${value['joint_all_defined']}/240$, with mean removal ${value['mean_value_removal_percent']:.2f}\\%$ and\n"
        f"retained capture ${value['mean_capture_percent']:.2f}\\%$. Of those compliant capture- and\n"
        f"value-objective cells, ${cap_new}$ and ${value_new}$ respectively increase a value level\n"
        "after refinement by baseline support, $G'=(G,\\mathbf1(\\pi_0(x)>0))$.\n"
        "Attained bounds on the original groups therefore do not imply bounds\n"
        "on their refinements. We completed the value objective after examining\n"
        "the capture results; these follow-ups are descriptive.\n"
    )


def numerical_receipt(args, result):
    paths = {args.root / name for name in result["inputs"]}
    paths.update(path for path in args.frozen.iterdir() if path.is_file())
    paths.update(path for path in args.output.iterdir() if path.is_file())
    paths.add(Path(__file__))
    frozen = args.frozen.relative_to(args.root)
    readme = (
        "# Completed direct-level reductions receipt\n\n"
        "Both original objectives completed 240 cases, including T evaluation. "
        "The value continuation followed examination of the capture results. "
        "The archive preserves that timing and every resource failure.\n\n"
        "Extract the archive and run, using Python stdlib:\n\n"
        "```sh\npython3 scripts/bandha_complete_level_results_20261117.py "
        f"--root . --frozen {frozen} --output verification\n```\n\n"
        "The generated JSON and Markdown reproduce the complete comparison, "
        "both group-refinement checks, equal-source summaries and matched "
        "value-cap comparisons. Fitted models and original raw inputs remain "
        "in the experiment cache and are required for prediction reconstruction.\n"
    )
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        args.receipt, "w", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        for path in sorted(paths):
            archive.write(path, str(path.relative_to(args.root)))
        archive.writestr("README.md", readme)


def main():
    args = arguments()
    export = json.loads((args.frozen / "bandha_EXPORT.json").read_text())
    for name, expected in export["files"].items():
        if digest(args.frozen / name) != expected:
            raise ValueError("Frozen input checksum changed: " + name)
    result = build_result(args, export)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "bandha_results.json").write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    (args.output / "bandha_results.md").write_text(markdown(result))
    (args.output / "bandha_comparison.tex").write_text(paper_passage(result))
    print(markdown(result))
    print("Results:", args.output)
    if args.receipt:
        numerical_receipt(args, result)
        print("Numerical receipt:", args.receipt)


if __name__ == "__main__":
    main()
