# XGBoost runtime support

Exact, unchanged supporting sources used by the boosted fairness run. Extract into a fresh copy of the frozen data project, giving it a scripts/ directory. Original module names and source attribution are retained. MANIFEST.json binds every file; these are runtime dependencies, not a new experiment.
