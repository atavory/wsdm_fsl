"""Fit local selective keep cuts with a common empirical value factor.

Only observed fitting outcomes determine the LP coefficients. Frozen action
rules use the original ratio, group, criterion flag, and baseline parameters.
Group value equality is fitted; all-unit objection nonincrease is pointwise.
No existing generator main function is called and every output starts ultra_.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import logging
import math
import platform
import shlex
import sys
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import bandha_direct_constrained_selector as forecasts
import bandha_empirical_cut_selector as empirical
import bandha_fairness_group_outcomes as frozen
import bandha_objection_safe_selector as original
import numpy as np
import scipy
from numpy.typing import NDArray
from scipy.optimize import OptimizeResult, linprog
from scipy.sparse import csr_matrix, vstack


LOGGER: logging.Logger = logging.getLogger(__name__)
GENERATOR = "scripts/ultra_value_retention_selector_20261105.py"
EVALUATOR = "scripts/ultra_value_retention_evaluation_20261105.py"
PROTOCOL = "ultra_value_retention_protocol_20261105.md"
RHOS = (0.95, 0.98)
DESIGN_CAPS = (0.10, 0.095)
OPERATIONAL_FLOOR = 0.95
OPERATIONAL_CAP = 0.10
SOLVER_TOLERANCE = 1e-10
CHECK_TOLERANCE = 1e-8
EFFECT_TOLERANCE = 1e-10
FloatArray = NDArray[np.float64]
CellKey = tuple[str, str, str]


class PrototypeNumericalError(RuntimeError):
    """An original constraint or independent certificate does not hold."""


@dataclass
class Cell:
    scope: forecasts.Scope
    batch: empirical.ValidationBatch
    pi0: FloatArray
    totals: dict[str, Any]
    baseline: dict[str, Any]
    nonobjector_cost: float
    nonobjector_capture: float
    objector_values: tuple[float, float]
    raw_cuts: tuple[list[empirical.Cut], ...]
    hulls: tuple[list[empirical.Cut], ...]


@dataclass(frozen=True)
class Problem:
    cell: Cell
    rho: float
    cap: float
    capture_required: bool
    vertex_bucket: NDArray[np.int64]
    capture: FloatArray
    cost: FloatArray
    objective: FloatArray
    matrix: csr_matrix
    rhs: FloatArray
    coupling: csr_matrix
    equality: csr_matrix
    equality_rhs: FloatArray
    constant_objective: float


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            result.update(block)
    return result.hexdigest()


def identity(root: Path, path: str) -> dict[str, str]:
    return {"path": path, "sha256": digest(root / path)}


def implementation(root: Path) -> list[dict[str, str]]:
    names = (
        GENERATOR,
        EVALUATOR,
        empirical.GENERATOR,
        forecasts.GENERATOR,
        original.GENERATOR,
        "scripts/bandha_fairness_group_outcomes.py",
        "scripts/bandha_direct_selector_evaluation.py",
        "scripts/bandha_frozen_calibration_study.py",
        "scripts/bandha_matched_bank_study.py",
    )
    missing = [name for name in names if not (root / name).exists()]
    if missing:
        raise ValueError(f"Cannot seal an incomplete local implementation: {missing}")
    return [identity(root, name) for name in names]


def verify_identities(root: Path, items: Sequence[Mapping[str, Any]]) -> None:
    for item in items:
        if digest(root / item["path"]) != item["sha256"]:
            raise ValueError(f"Frozen local dependency changed: {item['path']}")


def totals(batch: empirical.ValidationBatch) -> dict[str, Any]:
    value, loss = math.fsum(batch.value), math.fsum(batch.loss)
    return {
        "value": value,
        "loss": loss,
        "value_scale": value if value > 0 else 1.0,
        "loss_scale": loss if loss > 0 else 1.0,
        "group_value": [math.fsum(batch.value[batch.group == g]) for g in (0, 1)],
    }


def baseline_probability(batch: Any, rule: Mapping[str, Any]) -> FloatArray:
    return ((batch.ratio >= rule["baseline_threshold"]) & (batch.ratio > 0.0)).astype(
        float
    ) * rule["baseline_alpha"]


def moments(
    batch: empirical.ValidationBatch, pi: FloatArray, population: Mapping[str, Any]
) -> dict[str, Any]:
    cost, captured = math.fsum(batch.value * pi), math.fsum(batch.loss * pi)
    objector = batch.value * batch.objectable * pi
    masses = [math.fsum(objector[batch.group == g]) for g in (0, 1)]
    rates = [
        (
            masses[g] / population["group_value"][g]
            if population["group_value"][g] > 0
            else None
        )
        for g in (0, 1)
    ]
    return {
        "blocked_value": cost,
        "blocked_value_fraction": (
            cost / population["value"] if population["value"] > 0 else None
        ),
        "captured_loss": captured,
        "normalized_capture": captured / population["loss_scale"],
        "objector_value": masses,
        "D0": rates[0],
        "D1": rates[1],
        "absolute_gap": (
            abs(rates[1] - rates[0]) if all(x is not None for x in rates) else None
        ),
    }


def bucket_mask(batch: empirical.ValidationBatch, bucket: int) -> NDArray[np.bool_]:
    return (
        ~batch.objectable
        if bucket == 0
        else batch.objectable & (batch.group == bucket - 1)
    )


def cut_points(
    cell: Cell, bucket: int, thresholds: Sequence[float | None] | None
) -> list[empirical.Cut]:
    batch = cell.batch
    mask = bucket_mask(batch, bucket)
    available = 1.0 - cell.pi0 if bucket == 0 else cell.pi0
    mask &= available > 0.0
    ratio = batch.ratio[mask]
    order = np.argsort(-ratio, kind="stable")
    ratio = ratio[order]
    costs = np.r_[0.0, np.cumsum((batch.value * available)[mask][order])]
    captures = np.r_[0.0, np.cumsum((batch.loss * available)[mask][order])]
    if thresholds is None:
        thresholds = [None, *np.unique(ratio).tolist(), cell.scope.baseline_threshold]
    result = []
    for threshold in dict.fromkeys(thresholds):
        count = (
            0
            if threshold is None
            else int(np.searchsorted(-ratio, -threshold, side="right"))
        )
        result.append(
            empirical.Cut(threshold, float(costs[count]), float(captures[count]), count)
        )
    return result


def build_cell(
    scope: forecasts.Scope,
    batch: empirical.ValidationBatch,
    threshold_sets: Sequence[Sequence[float | None]] | None = None,
) -> Cell:
    population = totals(batch)
    base = baseline_probability(
        batch,
        {
            "baseline_threshold": scope.baseline_threshold,
            "baseline_alpha": scope.baseline_alpha,
        },
    )
    q = batch.objectable
    non_cost = math.fsum((batch.value * base)[~q])
    non_capture = math.fsum((batch.loss * base)[~q])
    obj = tuple(math.fsum((batch.value * base)[q & (batch.group == g)]) for g in (0, 1))
    cell = Cell(
        scope,
        batch,
        base,
        population,
        moments(batch, base, population),
        non_cost,
        non_capture,
        obj,
        (),
        (),
    )
    raw = tuple(
        cut_points(
            cell, bucket, None if threshold_sets is None else threshold_sets[bucket]
        )
        for bucket in range(3)
    )
    scales = {**population, "value": population["value_scale"]}
    hulls = tuple(empirical.upper_hull(points, scales) for points in raw)
    for points, hull in zip(raw, hulls):
        empirical.hull_receipt(points, hull, scales)
    cell.raw_cuts, cell.hulls = raw, hulls
    return cell


def coupling_rows(
    cell: Cell, bucket: NDArray[np.int64], costs: FloatArray
) -> csr_matrix:
    rows = []
    for group in (0, 1):
        mass = cell.objector_values[group]
        row = np.zeros(len(costs))
        if mass > 0.0:
            row[bucket == group + 1] = costs[bucket == group + 1] / mass
            row[-1] = -1.0
        elif np.any(costs[bucket == group + 1] != 0.0):
            raise PrototypeNumericalError(
                "Zero baseline value group has a nonzero kept-value cut"
            )
        rows.append(row)
    return csr_matrix(np.asarray(rows))


def make_problem(
    cell: Cell, rho: float, cap: float, capture_required: bool = True
) -> Problem:
    bucket = np.asarray(
        [b for b, hull in enumerate(cell.hulls) for _ in hull] + [-1], dtype=np.int64
    )
    costs = np.asarray([point.cost for hull in cell.hulls for point in hull] + [0.0])
    capture = (
        np.asarray([point.capture for hull in cell.hulls for point in hull] + [0.0])
        / cell.totals["loss_scale"]
    )
    cost = costs / cell.totals["value_scale"]
    remaining = (
        cap * cell.totals["value"] / cell.totals["value_scale"]
        - cell.nonobjector_cost / cell.totals["value_scale"]
    )
    floor = (
        rho * cell.baseline["captured_loss"] - cell.nonobjector_capture
    ) / cell.totals["loss_scale"]
    matrix = csr_matrix(
        np.vstack((cost, -capture)) if capture_required else np.atleast_2d(cost)
    )
    rhs = np.asarray([remaining, -floor] if capture_required else [remaining])
    coupling = coupling_rows(cell, bucket, costs)
    simplex = csr_matrix(np.asarray([bucket == b for b in range(3)], dtype=float))
    objective = np.zeros(len(cost)) if capture_required else capture.copy()
    if capture_required:
        objective[-1] = -1.0
    constant = (
        0.0
        if capture_required
        else cell.nonobjector_capture / cell.totals["loss_scale"]
    )
    return Problem(
        cell,
        rho,
        cap,
        capture_required,
        bucket,
        capture,
        cost,
        objective,
        matrix,
        rhs,
        coupling,
        vstack((simplex, coupling)).tocsr(),
        np.r_[np.ones(3), np.zeros(2)],
        constant,
    )


def solve(problem: Problem) -> OptimizeResult:
    result = linprog(
        -problem.objective,
        A_ub=problem.matrix,
        b_ub=problem.rhs,
        A_eq=problem.equality,
        b_eq=problem.equality_rhs,
        bounds=[(0.0, None)] * (len(problem.objective) - 1) + [(0.0, 1.0)],
        method="highs-ipm",
        options={
            "presolve": False,
            "primal_feasibility_tolerance": SOLVER_TOLERANCE,
            "dual_feasibility_tolerance": SOLVER_TOLERANCE,
        },
    )
    if result.status == 2:
        return result
    if result.status != 0 or not np.isfinite(result.x).all():
        raise PrototypeNumericalError(
            f"Selective value LP failed: {result.status}, {result.message}"
        )
    return result


def simplex_weights(problem: Problem, raw: FloatArray) -> FloatArray:
    if np.min(raw) < -EFFECT_TOLERANCE:
        raise PrototypeNumericalError("Material negative raw simplex weight")
    weights = np.maximum(raw, 0.0)
    for bucket in range(3):
        mask = problem.vertex_bucket == bucket
        amount = math.fsum(weights[mask])
        if amount <= 0.0:
            raise PrototypeNumericalError(
                "A cut bucket has no positive probability mass"
            )
        weights[mask] /= amount
    if raw[-1] < -EFFECT_TOLERANCE or raw[-1] > 1.0 + EFFECT_TOLERANCE:
        raise PrototypeNumericalError(
            "Common fitted factor materially violates its box"
        )
    weights[-1] = min(1.0, max(0.0, float(raw[-1])))
    return weights


def compact_cut(hull: list[empirical.Cut], cost: float, scale: float) -> dict[str, Any]:
    outside = max(0.0, hull[0].cost - cost, cost - hull[-1].cost)
    if outside / scale > CHECK_TOLERANCE:
        raise PrototypeNumericalError(
            "A requested compact cut cost is outside its hull"
        )
    left, right, mix = empirical.interpolate(hull, cost)
    return {
        "thresholds": [hull[left].threshold, hull[right].threshold],
        "right_weight": mix,
        "hull_indices": [left, right],
        "hull_size": len(hull),
        "adjacent_or_same": right - left in (0, 1),
        "expected_cost": (1.0 - mix) * hull[left].cost + mix * hull[right].cost,
        "expected_capture": (1.0 - mix) * hull[left].capture
        + mix * hull[right].capture,
    }


def compact_rules(
    problem: Problem, raw: FloatArray
) -> tuple[list[dict[str, Any]], FloatArray]:
    weights = simplex_weights(problem, raw)
    s = float(weights[-1])
    compact = []
    canonical = np.zeros(len(weights))
    for bucket, hull in enumerate(problem.cell.hulls):
        mask = problem.vertex_bucket == bucket
        cost = math.fsum(w * point.cost for w, point in zip(weights[mask], hull))
        if bucket > 0:
            cost = s * problem.cell.objector_values[bucket - 1]
        rule = compact_cut(hull, cost, problem.cell.totals["value_scale"])
        positions = np.flatnonzero(mask)
        left, right = rule["hull_indices"]
        canonical[positions[left]] += 1.0 - rule["right_weight"]
        canonical[positions[right]] += rule["right_weight"]
        compact.append(rule)
    canonical[-1] = s
    return compact, canonical


def original_errors(problem: Problem, weights: FloatArray) -> dict[str, float]:
    return {
        "inequality_error": float(
            np.max(np.maximum(problem.matrix @ weights - problem.rhs, 0.0), initial=0.0)
        ),
        "equality_error": float(
            np.max(
                np.abs(problem.equality @ weights - problem.equality_rhs), initial=0.0
            )
        ),
        "negative_probability_error": float(np.max(-weights, initial=0.0)),
        "factor_box_error": max(0.0, float(weights[-1]) - 1.0),
    }


def dual_certificate(
    problem: Problem, result: OptimizeResult, weights: FloatArray
) -> dict[str, Any]:
    dual = -np.asarray(result.ineqlin.marginals)
    coupling = -np.asarray(result.eqlin.marginals[3:])
    if (
        not np.isfinite(dual).all()
        or not np.isfinite(coupling).all()
        or np.min(dual) < -CHECK_TOLERANCE
    ):
        raise PrototypeNumericalError("Invalid inequality/free-coupling multipliers")
    dual = np.maximum(dual, 0.0)
    profit = problem.objective - problem.matrix.T @ dual - problem.coupling.T @ coupling
    upper = problem.constant_objective + float(dual @ problem.rhs)
    upper += math.fsum(
        float(np.max(profit[problem.vertex_bucket == b])) for b in range(3)
    )
    upper += max(0.0, float(profit[-1]))
    objective = problem.constant_objective + float(problem.objective @ weights)
    errors = original_errors(problem, weights)
    errors["independent_two_sided_dual_gap"] = abs(upper - objective)
    if max(errors.values()) > CHECK_TOLERANCE:
        raise PrototypeNumericalError(
            f"Original selective value programme/certificate failed: {errors}"
        )
    return {
        **errors,
        "inequality_multipliers": dual.tolist(),
        "free_coupling_multipliers": coupling.tolist(),
        "independent_upper_bound": upper,
        "canonical_objective": objective,
        "raw_simplex_error": float(
            np.max(np.abs((problem.equality @ result.x)[:3] - 1.0), initial=0.0)
        ),
        "maximum_weight_correction": float(
            np.max(np.abs(weights - result.x), initial=0.0)
        ),
    }


def cut_probability(ratio: FloatArray | float, rule: Mapping[str, Any]) -> Any:
    left, right = rule["thresholds"]
    a = ratio >= left if left is not None else np.zeros_like(ratio, dtype=bool)
    b = ratio >= right if right is not None else np.zeros_like(ratio, dtype=bool)
    return (1.0 - rule["right_weight"]) * a + rule["right_weight"] * b


def probability(forecast: forecasts.Forecast, rule: Mapping[str, Any]) -> float:
    base = rule["baseline_alpha"] * float(
        forecast.ratio >= rule["baseline_threshold"] and forecast.ratio > 0.0
    )
    if not forecast.objectable:
        return float(
            base + (1.0 - base) * cut_probability(forecast.ratio, rule["q0_rule"])
        )
    return float(
        base * cut_probability(forecast.ratio, rule["objector_rules"][forecast.group])
    )


def batch_probability(batch: Any, rule: Mapping[str, Any]) -> FloatArray:
    base = baseline_probability(batch, rule)
    result = base + (1.0 - base) * cut_probability(batch.ratio, rule["q0_rule"])
    for group in (0, 1):
        mask = batch.objectable & (batch.group == group)
        result[mask] = base[mask] * cut_probability(
            batch.ratio[mask], rule["objector_rules"][group]
        )
    return result


def selector_identity(cell: Cell, rho: float, cap: float) -> dict[str, Any]:
    scope = cell.scope
    return {
        "kind": "selective_value_retention",
        "dataset": scope.key[0],
        "seed": scope.key[1],
        "source": scope.source,
        "input": scope.relative_input,
        "groups": list(scope.groups),
        "measurement_unit": "value",
        "rho": rho,
        "design_budget": cap,
        "margin": 0.0,
        "operational_floor": OPERATIONAL_FLOOR,
        "operational_value_cap": OPERATIONAL_CAP,
        "baseline_threshold": scope.baseline_threshold,
        "baseline_alpha": scope.baseline_alpha,
        "baseline_index": scope.baseline_index,
        "reference": cell.baseline,
        "baseline_objector_value": list(cell.objector_values),
    }


def empty_cut() -> dict[str, Any]:
    return {
        "thresholds": [None, None],
        "right_weight": 0.0,
        "hull_indices": None,
        "hull_size": 0,
        "expected_cost": 0.0,
        "expected_capture": 0.0,
    }


def resource_anchor(cell: Cell, rho: float, cap: float) -> dict[str, Any] | None:
    excess = cell.nonobjector_cost - cap * cell.totals["value"]
    if excess / cell.totals["value_scale"] <= EFFECT_TOLERANCE:
        return None
    return {
        **selector_identity(cell, rho, cap),
        "defined": True,
        "selection_feasible": False,
        "resource_infeasible": True,
        "capture_goal_infeasible": None,
        "support_status": "minimum_value_resource_infeasible_anchor",
        "solver_status": None,
        "value_retention_s": 0.0,
        "q0_rule": empty_cut(),
        "objector_rules": [empty_cut(), empty_cut()],
        "certificate": None,
    }


def replay_receipt(
    cell: Cell, rule: Mapping[str, Any], problem: Problem | None
) -> dict[str, Any]:
    pi = batch_probability(cell.batch, rule)
    actual = moments(cell.batch, pi, cell.totals)
    q = cell.batch.objectable
    errors = {
        "probability_bound_error": float(
            max(np.max(-pi, initial=0.0), np.max(pi - 1.0, initial=0.0))
        ),
        "objector_nonincrease_error": float(np.max(pi[q] - cell.pi0[q], initial=0.0)),
        "nonobjector_preservation_error": float(
            np.max(cell.pi0[~q] - pi[~q], initial=0.0)
        ),
    }
    retained = [
        (
            actual["objector_value"][g] / cell.objector_values[g]
            if cell.objector_values[g] > 0.0
            else None
        )
        for g in (0, 1)
    ]
    errors["fitted_value_factor_error"] = max(
        (abs(x - rule["value_retention_s"]) for x in retained if x is not None),
        default=0.0,
    )
    if problem is not None:
        errors.update(served_program_errors(cell, rule, actual, problem))
    if max(errors.values()) > CHECK_TOLERANCE:
        raise PrototypeNumericalError(
            f"Frozen compact action rule fails fitting replay: {errors}"
        )
    baseline = cell.baseline["captured_loss"]
    return {
        **actual,
        **errors,
        "retained_capture_fraction": (
            actual["captured_loss"] / baseline if baseline > 0.0 else None
        ),
        "group_value_retention": retained,
        "group_value_retention_defined": [x is not None for x in retained],
        "own_capture_target_met": actual["captured_loss"]
        >= (rule["rho"] - EFFECT_TOLERANCE) * baseline,
        "design_budget_met": actual["blocked_value"]
        <= rule["design_budget"] * cell.totals["value"]
        + EFFECT_TOLERANCE * cell.totals["value_scale"],
    }


def served_program_errors(
    cell: Cell, rule: Mapping[str, Any], actual: Mapping[str, Any], problem: Problem
) -> dict[str, float]:
    cost_error = (
        max(0.0, actual["blocked_value"] - problem.cap * cell.totals["value"])
        / cell.totals["value_scale"]
    )
    capture_error = (
        max(0.0, problem.rho * cell.baseline["captured_loss"] - actual["captured_loss"])
        / cell.totals["loss_scale"]
        if problem.capture_required
        else 0.0
    )
    objective = (
        -rule["value_retention_s"]
        if problem.capture_required
        else actual["normalized_capture"]
    )
    upper = rule["certificate"]["independent_upper_bound"]
    return {
        "served_budget_error": cost_error,
        "served_capture_error": capture_error,
        "served_independent_two_sided_objective_gap": abs(upper - objective),
    }


def fitted_rule(cell: Cell, problem: Problem, result: OptimizeResult) -> dict[str, Any]:
    compact, weights = compact_rules(problem, result.x)
    certificate = dual_certificate(problem, result, weights)
    rule = {
        **selector_identity(cell, problem.rho, problem.cap),
        "defined": True,
        "selection_feasible": problem.capture_required,
        "resource_infeasible": False,
        "capture_goal_infeasible": not problem.capture_required,
        "solver_status": 0 if problem.capture_required else 2,
        "fallback_solver_status": None if problem.capture_required else 0,
        "support_status": (
            "valid"
            if problem.capture_required
            else "capture_infeasible_best_capture_same_coupled_class"
        ),
        "value_retention_s": float(weights[-1]),
        "q0_rule": compact[0],
        "objector_rules": compact[1:],
        "certificate": certificate,
        "objective_kind": (
            "minimize_fitted_value_factor"
            if problem.capture_required
            else "maximize_capture_after_infeasible_goal"
        ),
    }
    rule["fitting"] = replay_receipt(cell, rule, problem)
    return rule


def fit_selector(cell: Cell, rho: float, cap: float) -> dict[str, Any]:
    try:
        anchor = resource_anchor(cell, rho, cap)
        if anchor is not None:
            anchor["fitting"] = replay_receipt(cell, anchor, None)
            return anchor
        problem = make_problem(cell, rho, cap)
        result = solve(problem)
        if result.status == 0:
            return fitted_rule(cell, problem, result)
        fallback_problem = make_problem(cell, rho, cap, False)
        fallback_result = solve(fallback_problem)
        if fallback_result.status != 0:
            raise PrototypeNumericalError(
                "Resource-feasible fallback unexpectedly fails"
            )
        fallback = fitted_rule(cell, fallback_problem, fallback_result)
        goal = rho * cell.baseline["captured_loss"] / cell.totals["loss_scale"]
        if fallback["fitting"]["normalized_capture"] >= goal - CHECK_TOLERANCE:
            raise PrototypeNumericalError(
                "Capture infeasibility contradicts a certified feasible capture witness"
            )
        return fallback
    except PrototypeNumericalError as error:
        raise PrototypeNumericalError(
            f"{cell.scope.key}, rho={rho}, cap={cap}: {error}"
        ) from error


def cell_manifest(cell: Cell) -> dict[str, Any]:
    return {
        "dataset": cell.scope.key[0],
        "seed": cell.scope.key[1],
        "input": cell.scope.relative_input,
        "groups": list(cell.scope.groups),
        "baseline": cell.baseline,
        "baseline_objector_value": list(cell.objector_values),
        "raw_cuts": [[asdict(point) for point in points] for points in cell.raw_cuts],
        "hulls": [[asdict(point) for point in points] for points in cell.hulls],
    }


def write_json(path: Path, value: Any) -> None:
    if not path.name.startswith("ultra_"):
        raise ValueError("Local output basename must start ultra_")
    text = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if path.suffix == ".gz":
        path.write_bytes(gzip.compress(text.encode(), mtime=0))
    else:
        path.write_text(text)


def selection_row(rule: Mapping[str, Any]) -> dict[str, Any]:
    names = (
        "kind",
        "dataset",
        "seed",
        "source",
        "rho",
        "design_budget",
        "defined",
        "selection_feasible",
        "resource_infeasible",
        "capture_goal_infeasible",
        "support_status",
        "value_retention_s",
        "solver_status",
    )
    row = {name: rule.get(name) for name in names}
    for name, value in rule["fitting"].items():
        row["fitting_" + name] = json.dumps(value) if isinstance(value, list) else value
    row["q0_rule_json"] = json.dumps(rule["q0_rule"], separators=(",", ":"))
    row["objector_rules_json"] = json.dumps(
        rule["objector_rules"], separators=(",", ":")
    )
    return row


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not path.name.startswith("ultra_"):
        raise ValueError("Local output basename must start ultra_")
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--input-revision", default="cc64c1d")
    parser.add_argument("--output-prefix", default="ultra_value_retention_20261105")
    parser.add_argument("--verification-only", action="store_true")
    parser.add_argument("--canary-cell", action="append", default=[])
    args = parser.parse_args()
    if not args.output_prefix.startswith("ultra_") or any(
        c not in "abcdefghijklmnopqrstuvwxyz0123456789_" for c in args.output_prefix
    ):
        raise ValueError("Invalid ultra-only output prefix")
    if args.canary_cell and not args.verification_only:
        raise ValueError("Canary scope must be marked verification-only")
    return args


def main() -> None:
    args = arguments()
    root = args.root.resolve()
    code = implementation(root)
    protocol = identity(root, PROTOCOL)
    revision = frozen.git_output(root, ["rev-parse", args.input_revision])
    scopes, inputs = forecasts.load_scopes(root, revision)
    if args.canary_cell:
        wanted = {tuple(x.rsplit(":", 1)) for x in args.canary_cell}
        scopes = {key: scope for key, scope in scopes.items() if key[:2] in wanted}
        if {key[:2] for key in scopes} != wanted:
            raise ValueError("Unknown canary cell")
    batches = empirical.load_validation(root, scopes)
    references = empirical.baseline_references(root)
    selectors = []
    manifests = []
    for key, scope in scopes.items():
        cell = build_cell(scope, batches[key])
        empirical.verify_baseline(cell, references[key])
        manifests.append(cell_manifest(cell))
        selectors.extend(
            fit_selector(cell, rho, cap) for rho in RHOS for cap in DESIGN_CAPS
        )
        LOGGER.info("Completed selective value V cell: %s", key)
    verify_identities(root, [*code, protocol, *inputs])
    if not args.verification_only and (len(scopes), len(selectors)) != (240, 960):
        raise ValueError("Full local V scope is incomplete")
    metadata = phase_header(args, revision, code, protocol, inputs)
    metadata.update(
        n_cells=len(scopes),
        n_selectors=len(selectors),
        cells=manifests,
        selectors=selectors,
    )
    csv_path = root / "results/csvs" / f"{args.output_prefix}_V_selections.csv"
    write_csv(csv_path, [selection_row(x) for x in selectors])
    metadata["outputs"] = [identity(root, str(csv_path.relative_to(root)))]
    write_json(
        root / "results/csvs" / f"{args.output_prefix}_V_freeze.json.gz", metadata
    )


def phase_header(
    args: argparse.Namespace, revision: str, code: Any, protocol: Any, inputs: Any
) -> dict[str, Any]:
    return {
        "generator": GENERATOR,
        "schema_version": 1,
        "phase": "select",
        "complete": True,
        "verification_only": args.verification_only,
        "input_revision": revision,
        "implementation": code,
        "protocol": protocol,
        "inputs": inputs,
        "rho_scope": list(RHOS),
        "design_cap_scope": list(DESIGN_CAPS),
        "primary_rho": 0.95,
        "primary_design_cap": 0.10,
        "operational_floor": 0.95,
        "operational_cap": 0.10,
        "solver_method": "highs-ipm",
        "solver_tolerance": SOLVER_TOLERANCE,
        "checked_tolerance": CHECK_TOLERANCE,
        "heldout_numeric_outcomes_parsed": False,
        "final_outcomes_used_for_selection": False,
        "scope": "local exploratory continuation on previously examined data; no commits or pushes",
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "command": [sys.executable, *sys.argv],
        "command_shell": shlex.join([sys.executable, *sys.argv]),
    }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    main()
