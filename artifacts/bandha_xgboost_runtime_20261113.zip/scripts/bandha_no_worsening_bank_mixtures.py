"""Optimize no-worsening mixtures of the existing frozen value-unit bank.

We use the primary 0.95 capture floor and every frozen value-unit cell.
We freeze validation selections before parsing any held-out outcomes. We then
replay the selected components with their original thresholds and thinning,
check the existing baseline and component outcomes, and report held-out
constraint violations. We do not fit predictors or extend the policy bank.
"""

from __future__ import annotations

import argparse
import csv
import json
import logging
import math
import platform
import shlex
import statistics
import sys
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import bandha_fairness_group_outcomes as outcomes
import numpy as np
import scipy
from numpy.typing import NDArray
from scipy.optimize import linprog, OptimizeResult


LOGGER: logging.Logger = logging.getLogger(__name__)
GENERATOR = "scripts/bandha_no_worsening_bank_mixtures.py"
HELPER = "scripts/bandha_fairness_group_outcomes.py"
CAPTURE_FLOOR = 0.95
VALUE_CAP = 0.10
TIE_TOLERANCE = 1e-9
CONSTRAINT_TOLERANCE = 1e-8
SOLVER_FEASIBILITY_TOLERANCE = 1e-10
EFFECT_TOLERANCE = 1e-10
UNIT = "value"
FloatArray = NDArray[np.float64]
CellKey = tuple[str, str, str]
Candidate = tuple[str, float, float, float, float, bool]


@dataclass
class Basis:
    key: CellKey
    case: Mapping[str, Any]
    source: str
    baseline_index: int
    baseline_levels: tuple[float, float]
    coefficients: FloatArray

    def gaps(self) -> FloatArray:
        return self.coefficients[:, 3] - self.coefficients[:, 2]


@dataclass
class PolicyAmounts:
    index: int
    threshold: float
    alpha: float
    penalties: tuple[float, float]
    selected: tuple[outcomes.StableSum, outcomes.StableSum] = field(
        default_factory=lambda: (outcomes.StableSum(), outcomes.StableSum())
    )
    complaint: tuple[outcomes.StableSum, outcomes.StableSum] = field(
        default_factory=lambda: (outcomes.StableSum(), outcomes.StableSum())
    )
    captured_loss: outcomes.StableSum = field(default_factory=outcomes.StableSum)

    def add(self, candidate: Candidate, group_index: int) -> None:
        score = outcomes.value_unit_score(candidate, self.penalties[group_index])
        if score < self.threshold or score <= 0.0:
            return
        self.selected[group_index].add(candidate[1])
        self.captured_loss.add(candidate[2])
        if candidate[5]:
            self.complaint[group_index].add(candidate[1])


@dataclass
class CellAmounts:
    groups: tuple[str, str]
    policies: dict[int, PolicyAmounts]
    total_value: tuple[outcomes.StableSum, outcomes.StableSum] = field(
        default_factory=lambda: (outcomes.StableSum(), outcomes.StableSum())
    )
    potential_value: tuple[outcomes.StableSum, outcomes.StableSum] = field(
        default_factory=lambda: (outcomes.StableSum(), outcomes.StableSum())
    )
    total_loss: outcomes.StableSum = field(default_factory=outcomes.StableSum)
    n_candidates: int = 0

    def add(self, candidate: Candidate) -> None:
        if candidate[0] not in self.groups:
            raise ValueError(f"Unexpected held-out group {candidate[0]!r}")
        group_index = self.groups.index(candidate[0])
        self.total_value[group_index].add(candidate[1])
        self.total_loss.add(candidate[2])
        if candidate[5]:
            self.potential_value[group_index].add(candidate[1])
        for policy in self.policies.values():
            policy.add(candidate, group_index)
        self.n_candidates += 1


def source_name(dataset: str) -> str:
    plain = dataset.split("[")[0]
    if plain.startswith("freMPL"):
        return "French portfolio"
    alternatives = {
        "beMTPL97": "Belgian MTPL",
        "norauto": "Norwegian auto",
        "swmotorcycle": "Swedish motorcycle",
    }
    return alternatives.get(plain, outcomes.legacy.source_name(plain))


def output_path(root: Path, name: str) -> Path:
    return root / "results/csvs" / f"bandha_no_worsening_{name}"


def write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"Empty output table: {path.name}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def primary_cases(frozen: Mapping[str, Any]) -> dict[CellKey, Mapping[str, Any]]:
    selected = {"cases": [case for case in frozen["cases"] if case["currency"] == UNIT]}
    cases = outcomes.index_cases(selected)
    if len(cases) != 240:
        raise ValueError(f"Primary scope requires 240 frozen cells; got {len(cases)}")
    if len({source_name(key[0]) for key in cases}) != 10:
        raise ValueError("Primary scope does not contain ten source families")
    return cases


def validation_levels(
    case: Mapping[str, Any], metrics: Mapping[str, Any]
) -> tuple[float, float]:
    masses = outcomes.ordered_masses(metrics["masses"], case["groups"])
    levels = outcomes.levels(masses)
    oriented_gap = levels[case["high"]] - levels[1 - case["high"]]
    if not math.isclose(oriented_gap, metrics["gap"], abs_tol=1e-11, rel_tol=1e-11):
        raise ValueError("Frozen signed gap disagrees with explicit group amounts")
    return levels


def check_point(
    case: Mapping[str, Any], point: Mapping[str, Any], integrity: outcomes.Integrity
) -> None:
    if point["family"] not in ("account", "group"):
        raise ValueError(f"Unexpected frozen bank family {point['family']!r}")
    if (
        not math.isfinite(point["threshold"])
        or not math.isfinite(point["lambda"])
        or point["lambda"] < 0.0
    ):
        raise ValueError("Invalid frozen threshold or multiplier")
    actual = outcomes.ordered_masses(point["validation"]["masses"], case["groups"])
    expected = outcomes.ordered_masses(case["baseline"]["masses"], case["groups"])
    names = outcomes.MASS_NAMES if point["lambda"] == 0.0 else outcomes.MASS_NAMES[:2]
    for mass, base in zip(actual, expected):
        for name in names:
            integrity.equal(float(mass[name]), float(base[name]), name, point["family"])
    alpha = point["validation"]["alpha"]
    if not math.isfinite(alpha) or not 0.0 <= alpha <= 1.0:
        raise ValueError("Invalid frozen component thinning probability")


def make_basis(
    key: CellKey, case: Mapping[str, Any], integrity: outcomes.Integrity
) -> Basis:
    baseline = case["baseline"]
    if not math.isfinite(baseline["capture"]) or baseline["capture"] <= 0.0:
        raise ValueError(f"Unavailable positive validation baseline capture: {key}")
    baseline_levels = validation_levels(case, baseline)
    baseline_point = outcomes.baseline_point(case)
    baseline_index = next(
        i for i, point in enumerate(case["bank"]) if point is baseline_point
    )
    rows = []
    for point in case["bank"]:
        check_point(case, point, integrity)
        metrics = point["validation"]
        levels = validation_levels(case, metrics)
        rows.append(
            (metrics["capture"] / baseline["capture"], metrics["budget"], *levels)
        )
        if point["lambda"] == 0.0:
            for name in ("capture", "budget", "gap", "alpha"):
                integrity.equal(
                    metrics[name], baseline[name], f"zero_penalty_{name}", key
                )
    coefficients = np.asarray(rows, dtype=np.float64)
    if not np.isfinite(coefficients).all():
        raise ValueError(f"Nonfinite validation LP coefficients: {key}")
    basis = Basis(
        key, case, source_name(key[0]), baseline_index, baseline_levels, coefficients
    )
    weights = np.zeros(len(rows))
    weights[baseline_index] = 1.0
    check_weights(basis, weights, "baseline", None, None)
    return basis


def original_constraints(basis: Basis) -> tuple[FloatArray, FloatArray]:
    values = basis.coefficients
    matrix = np.vstack(
        (
            basis.gaps(),
            -basis.gaps(),
            -values[:, 0],
            values[:, 1],
            values[:, 2],
            values[:, 3],
        )
    )
    rhs = np.asarray((0.0, 0.0, -CAPTURE_FLOOR, VALUE_CAP, *basis.baseline_levels))
    return matrix, rhs


def solve_lp(
    objective: FloatArray,
    matrix: FloatArray,
    rhs: FloatArray,
    equality: FloatArray,
    label: str,
) -> OptimizeResult:
    result = linprog(
        objective,
        A_ub=matrix,
        b_ub=rhs,
        A_eq=[equality],
        b_eq=[1.0],
        bounds=(0.0, None),
        method="highs-ds",
        options={
            "dual_feasibility_tolerance": SOLVER_FEASIBILITY_TOLERANCE,
            "primal_feasibility_tolerance": SOLVER_FEASIBILITY_TOLERANCE,
        },
    )
    if not result.success:
        raise RuntimeError(f"No-worsening LP failed for {label}: {result.message}")
    if not np.isfinite(result.x).all() or not math.isfinite(result.fun):
        raise RuntimeError("No-worsening LP produced nonfinite output")
    return result


def check_weights(
    basis: Basis,
    weights: FloatArray,
    stage: str,
    gap_limit: float | None,
    capture_limit: float | None,
) -> dict[str, Any]:
    capture, budget, d0, d1 = map(float, weights @ basis.coefficients)
    errors = {
        "weight_sum_error": abs(float(weights.sum()) - 1.0),
        "negative_weight_error": max(0.0, -float(weights.min())),
        "capture_floor_error": max(0.0, CAPTURE_FLOOR - capture),
        "value_cap_error": max(0.0, budget - VALUE_CAP),
        "group_0_no_worsening_error": max(0.0, d0 - basis.baseline_levels[0]),
        "group_1_no_worsening_error": max(0.0, d1 - basis.baseline_levels[1]),
        "gap_tie_error": (
            max(0.0, abs(d1 - d0) - gap_limit) if gap_limit is not None else 0.0
        ),
        "capture_tie_error": (
            max(0.0, capture_limit - capture) if capture_limit is not None else 0.0
        ),
    }
    if max(errors.values()) > CONSTRAINT_TOLERANCE or np.any(weights < 0.0):
        raise RuntimeError(
            f"Original validation constraints failed: {basis.key}, {stage}, {errors}"
        )
    return {
        "generator": GENERATOR,
        "dataset": basis.key[0],
        "seed": basis.key[1],
        "source": basis.source,
        "measurement_unit": UNIT,
        "capture_floor": CAPTURE_FLOOR,
        "stage": stage,
        "retained_capture_fraction": capture,
        "blocked_value_fraction": budget,
        "D0": d0,
        "D1": d1,
        "signed_gap": d1 - d0,
        "absolute_gap": abs(d1 - d0),
        "all_constraints_met": True,
        **errors,
    }


def select_mixture(basis: Basis) -> dict[str, Any]:
    matrix, rhs = original_constraints(basis)
    n = len(basis.coefficients)
    first = solve_lp(
        np.r_[np.zeros(n), 1.0],
        np.c_[matrix, (-1.0, -1.0, 0.0, 0.0, 0.0, 0.0)],
        rhs,
        np.r_[np.ones(n), 0.0],
        f"{basis.key}:minimum_gap",
    )
    gap_optimum = max(0.0, float(first.fun))
    receipts = [
        check_weights(basis, first.x[:n], "minimum_gap", float(first.x[-1]), None)
    ]
    gap_limit = gap_optimum + TIE_TOLERANCE
    rhs[:2] = gap_limit
    second = solve_lp(
        -basis.coefficients[:, 0],
        matrix,
        rhs,
        np.ones(n),
        f"{basis.key}:maximum_capture",
    )
    capture_optimum = float(second.x @ basis.coefficients[:, 0])
    receipts.append(check_weights(basis, second.x, "maximum_capture", gap_limit, None))
    capture_limit = capture_optimum - TIE_TOLERANCE
    third = solve_lp(
        basis.coefficients[:, 1],
        np.vstack((matrix, -basis.coefficients[:, 0])),
        np.r_[rhs, -capture_limit],
        np.ones(n),
        f"{basis.key}:minimum_spend",
    )
    receipts.append(
        check_weights(basis, third.x, "minimum_spend", gap_limit, capture_limit)
    )
    return selection_result(
        basis, third, gap_optimum, capture_optimum, gap_limit, capture_limit, receipts
    )


def checked_components(
    basis: Basis, weights: FloatArray, gap_limit: float, capture_limit: float
) -> list[tuple[int, float]]:
    components = [
        (index, float(weight)) for index, weight in enumerate(weights) if weight > 0.0
    ]
    retained_weights = np.zeros(len(weights))
    for index, weight in components:
        retained_weights[index] = weight
    check_weights(
        basis, retained_weights, "serialized_support", gap_limit, capture_limit
    )
    return components


def selection_result(
    basis: Basis,
    result: OptimizeResult,
    gap_optimum: float,
    capture_optimum: float,
    gap_limit: float,
    capture_limit: float,
    receipts: list[dict[str, Any]],
) -> dict[str, Any]:
    components = checked_components(basis, result.x, gap_limit, capture_limit)
    return {
        "dataset": basis.key[0],
        "seed": basis.key[1],
        "source": basis.source,
        "input": basis.case["input"],
        "measurement_unit": UNIT,
        "capture_floor": CAPTURE_FLOOR,
        "bank_size": len(basis.coefficients),
        "baseline_index": basis.baseline_index,
        "baseline_D0": basis.baseline_levels[0],
        "baseline_D1": basis.baseline_levels[1],
        "components": components,
        "primary_optimum_gap": gap_optimum,
        "secondary_optimum_retained_capture": capture_optimum,
        "tertiary_optimum_spend": float(result.fun),
        "receipts": [baseline_receipt(basis), *receipts],
        "uniform_baseline_diagnostic": uniform_validation(basis),
    }


def baseline_receipt(basis: Basis) -> dict[str, Any]:
    weights = np.zeros(len(basis.coefficients))
    weights[basis.baseline_index] = 1.0
    return check_weights(basis, weights, "baseline_feasibility", None, None)


def uniform_validation(basis: Basis) -> dict[str, Any]:
    baseline = basis.case["baseline"]
    point = basis.case["bank"][basis.baseline_index]
    return {
        "baseline_index": basis.baseline_index,
        "frozen_extra_thinning_multiplier": CAPTURE_FLOOR,
        "threshold": point["threshold"],
        "original_component_alpha": baseline["alpha"],
        "combined_alpha": baseline["alpha"] * CAPTURE_FLOOR,
        "validation_retained_capture_fraction": CAPTURE_FLOOR,
        "validation_capture": baseline["capture"] * CAPTURE_FLOOR,
        "validation_budget": baseline["budget"] * CAPTURE_FLOOR,
        "validation_D0": basis.baseline_levels[0] * CAPTURE_FLOOR,
        "validation_D1": basis.baseline_levels[1] * CAPTURE_FLOOR,
        "validation_absolute_gap": abs(
            basis.baseline_levels[1] - basis.baseline_levels[0]
        )
        * CAPTURE_FLOOR,
        "included_in_LP_basis": False,
    }


def component_rows(basis: Basis, selection: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for index, weight in selection["components"]:
        point = basis.case["bank"][index]
        rows.append(
            {
                "generator": GENERATOR,
                "dataset": basis.key[0],
                "seed": basis.key[1],
                "source": basis.source,
                "measurement_unit": UNIT,
                "capture_floor": CAPTURE_FLOOR,
                "input": basis.case["input"],
                "bank_index": index,
                "weight": weight,
                "family": point["family"],
                "lambda": point["lambda"],
                "threshold": point["threshold"],
                "component_alpha": point["validation"]["alpha"],
            }
        )
    return rows


def selection_row(selection: Mapping[str, Any]) -> dict[str, Any]:
    row = {"generator": GENERATOR}
    row.update(
        {
            name: value
            for name, value in selection.items()
            if name not in ("components", "receipts", "uniform_baseline_diagnostic")
        }
    )
    row["components_json"] = json.dumps(selection["components"], separators=(",", ":"))
    row.update(
        {
            f"validation_{name}": value
            for name, value in selection["receipts"][-1].items()
            if name
            not in (
                "generator",
                "dataset",
                "seed",
                "source",
                "measurement_unit",
                "capture_floor",
                "stage",
            )
        }
    )
    row.update(
        {
            "uniform_" + name: value
            for name, value in selection["uniform_baseline_diagnostic"].items()
        }
    )
    return row


def script_identities(root: Path) -> list[dict[str, Any]]:
    return [
        {"path": relative, "sha256": outcomes.digest(root / relative)}
        for relative in (GENERATOR, HELPER)
    ]


def freeze_selections(
    root: Path,
    revision: str,
    manifests: list[dict[str, Any]],
    bases: Mapping[CellKey, Basis],
) -> dict[CellKey, dict[str, Any]]:
    selections = {}
    for key, basis in sorted(bases.items()):
        selections[key] = select_mixture(basis)
        if len(selections) % 60 == 0:
            LOGGER.info(
                "Optimized validation mixtures: %s/%s", len(selections), len(bases)
            )
    metadata = freeze_metadata(root, revision, manifests, selections)
    write_json(output_path(root, "validation_freeze.json"), metadata)
    write_csv(
        output_path(root, "validation_selection.csv"),
        [selection_row(value) for value in selections.values()],
    )
    write_csv(
        output_path(root, "validation_components.csv"),
        [
            row
            for key, selection in selections.items()
            for row in component_rows(bases[key], selection)
        ],
    )
    write_csv(
        output_path(root, "validation_constraints.csv"),
        [row for selection in selections.values() for row in selection["receipts"]],
    )
    LOGGER.info("Wrote all validation selections before held-out outcome parsing")
    return selections


def freeze_metadata(
    root: Path,
    revision: str,
    manifests: list[dict[str, Any]],
    selections: Mapping[CellKey, Mapping[str, Any]],
) -> dict[str, Any]:
    return {
        "generator": GENERATOR,
        "schema_version": 1,
        "input_revision": revision,
        "inputs": manifests,
        "implementation": script_identities(root),
        "command": shlex.join(sys.argv),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "solver": "highs-ds",
        "selection": "minimum_absolute_gap_then_maximum_capture_then_minimum_spend",
        "bank": "union_of_existing_frozen_account_and_group_policies",
        "capture_floor": CAPTURE_FLOOR,
        "value_cap": VALUE_CAP,
        "gap_and_capture_tie_tolerance": TIE_TOLERANCE,
        "constraint_tolerance": CONSTRAINT_TOLERANCE,
        "solver_primal_feasibility_tolerance": SOLVER_FEASIBILITY_TOLERANCE,
        "solver_dual_feasibility_tolerance": SOLVER_FEASIBILITY_TOLERANCE,
        "heldout_outcomes_parsed": False,
        "selections": list(selections.values()),
    }


def reference_components(
    case: Mapping[str, Any], family: str
) -> list[tuple[int, float]]:
    if family == "lp":
        mixture = case["lp"][str(CAPTURE_FLOOR)]
        if mixture is None:
            raise ValueError("The frozen primary common-penalty mixture is unavailable")
        return [(int(index), float(weight)) for index, weight in mixture["components"]]
    index = case["selected"][f"{CAPTURE_FLOOR}:{family}"]
    if index is None:
        raise ValueError(f"The frozen primary {family} policy is unavailable")
    return [(int(index), 1.0)]


def policy_amounts(case: Mapping[str, Any], index: int) -> PolicyAmounts:
    point = case["bank"][index]
    price, rates = point["lambda"], case["rates"]
    if min(rates) <= 0.0:
        raise ValueError("The frozen penalty normalization is nonpositive")
    if point["family"] == "account":
        coefficients = (price / sum(rates), price / sum(rates))
    else:
        coefficients = tuple(
            price / rates[g] if g == case["high"] else -price / rates[g]
            for g in range(2)
        )
    return PolicyAmounts(
        index, point["threshold"], point["validation"]["alpha"], coefficients
    )


def cell_amounts(basis: Basis, selection: Mapping[str, Any]) -> CellAmounts:
    indices = {basis.baseline_index, *(index for index, _ in selection["components"])}
    for family in ("account", "group", "lp"):
        indices.update(index for index, _ in reference_components(basis.case, family))
    policies = {index: policy_amounts(basis.case, index) for index in sorted(indices)}
    return CellAmounts(tuple(basis.case["groups"]), policies)


def replay_test(
    root: Path,
    bases: Mapping[CellKey, Basis],
    selections: Mapping[CellKey, Mapping[str, Any]],
) -> dict[CellKey, CellAmounts]:
    amounts = {
        key: cell_amounts(basis, selections[key]) for key, basis in bases.items()
    }
    by_input: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for key, basis in bases.items():
        by_input[basis.case["input"]].add(key[:2])
    for relative, keys in sorted(by_input.items()):
        for key, candidate in outcomes.iter_test_candidates(root / relative, keys):
            amounts[(*key, UNIT)].add(candidate)
        LOGGER.info("Replayed primary held-out candidates: %s", relative)
    if any(value.n_candidates == 0 for value in amounts.values()):
        raise ValueError("A primary cell has no matching held-out candidates")
    return amounts


def policy_masses(amounts: CellAmounts, policy: PolicyAmounts) -> list[dict[str, Any]]:
    return [
        {
            "group": group,
            "total_mass": amounts.total_value[g].value(),
            "potential_mass": amounts.potential_value[g].value(),
            "selected_mass": policy.selected[g].value() * policy.alpha,
            "complaint_mass": policy.complaint[g].value() * policy.alpha,
        }
        for g, group in enumerate(amounts.groups)
    ]


def mixture_metrics(
    amounts: CellAmounts, chosen: Iterable[tuple[int, float]]
) -> dict[str, Any]:
    components = [(amounts.policies[index], weight) for index, weight in chosen]
    total_value = math.fsum(value.value() for value in amounts.total_value)
    total_loss = amounts.total_loss.value()
    if total_value <= 0.0 or total_loss <= 0.0:
        raise ValueError("Unavailable positive held-out value/loss denominator")
    blocked = [
        math.fsum(
            policy.selected[g].value() * policy.alpha * weight
            for policy, weight in components
        )
        for g in range(2)
    ]
    complaint = [
        math.fsum(
            policy.complaint[g].value() * policy.alpha * weight
            for policy, weight in components
        )
        for g in range(2)
    ]
    captured = math.fsum(
        policy.captured_loss.value() * policy.alpha * weight
        for policy, weight in components
    )
    levels = [complaint[g] / amounts.total_value[g].value() for g in range(2)]
    return {
        "capture": captured / total_loss,
        "budget": math.fsum(blocked) / total_value,
        "D0": levels[0],
        "D1": levels[1],
        "signed_gap": levels[1] - levels[0],
        "absolute_gap": abs(levels[1] - levels[0]),
        "captured_loss": captured,
        "blocked_value": math.fsum(blocked),
        "complaint_mass": math.fsum(complaint),
        "group_0_complaint_mass": complaint[0],
        "group_1_complaint_mass": complaint[1],
    }


def check_component(
    basis: Basis,
    amounts: CellAmounts,
    index: int,
    points: Mapping[tuple[str, str, str, int, str], list[dict[str, Any]]],
    integrity: outcomes.Integrity,
) -> None:
    for split in ("validation", "test"):
        key = (*basis.key, index, split)
        if key not in points:
            continue
        expected = outcomes.ordered_masses(points[key], amounts.groups)
        point = basis.case["bank"][index]
        actual = (
            point["validation"]["masses"]
            if split == "validation"
            else policy_masses(amounts, amounts.policies[index])
        )
        actual = outcomes.ordered_masses(actual, amounts.groups)
        if any(
            mass["family"] != point["family"] or mass["lambda"] != point["lambda"]
            for mass in expected
        ):
            raise ValueError(f"Existing component identity differs: {key}")
        for actual_group, expected_group in zip(actual, expected):
            for name in outcomes.MASS_NAMES:
                integrity.equal(
                    float(actual_group[name]),
                    float(expected_group[name]),
                    f"component_{split}_{name}",
                    key,
                )


def check_existing(
    basis: Basis,
    amounts: CellAmounts,
    comparison: Mapping[str, str],
    points: Mapping[tuple[str, str, str, int, str], list[dict[str, Any]]],
    integrity: outcomes.Integrity,
) -> None:
    base = mixture_metrics(amounts, [(basis.baseline_index, 1.0)])
    if comparison["source"] != basis.source:
        raise ValueError(f"Source identity differs for {basis.key}")
    integrity.equal(
        base["capture"],
        float(comparison["baseline_test_capture"]),
        "baseline_capture",
        basis.key,
    )
    integrity.equal(
        base["absolute_gap"],
        float(comparison["baseline_test_gap"]),
        "baseline_gap",
        basis.key,
    )
    for index in amounts.policies:
        check_component(basis, amounts, index, points, integrity)
    for family in ("account", "group", "lp"):
        chosen = reference_components(basis.case, family)
        if any((*basis.key, index, "test") not in points for index, _ in chosen):
            raise ValueError(
                f"Missing frozen selected component outcomes: {basis.key}, {family}"
            )
        actual = mixture_metrics(amounts, chosen)
        integrity.equal(
            actual["absolute_gap"],
            float(comparison[f"{family}_test_gap"]),
            f"{family}_gap",
            basis.key,
        )
        integrity.equal(
            actual["budget"],
            float(comparison[f"{family}_test_value_budget"]),
            f"{family}_budget",
            basis.key,
        )
        if base["capture"] > 0.0:
            integrity.equal(
                actual["capture"] / base["capture"],
                float(comparison[f"{family}_test_capture_fraction"]),
                f"{family}_capture",
                basis.key,
            )


def test_identity_row(basis: Basis, amounts: CellAmounts) -> dict[str, Any]:
    return {
        "generator": GENERATOR,
        "input": basis.case["input"],
        "source": basis.source,
        "dataset": basis.key[0],
        "seed": basis.key[1],
        "measurement_unit": UNIT,
        "capture_floor": CAPTURE_FLOOR,
        "group_0": amounts.groups[0],
        "group_1": amounts.groups[1],
        "validation_high_group": amounts.groups[basis.case["high"]],
        "test_n_candidates": amounts.n_candidates,
        "test_total_value": math.fsum(value.value() for value in amounts.total_value),
        "test_total_loss": amounts.total_loss.value(),
        "group_0_total_value": amounts.total_value[0].value(),
        "group_1_total_value": amounts.total_value[1].value(),
        "group_0_potential_value": amounts.potential_value[0].value(),
        "group_1_potential_value": amounts.potential_value[1].value(),
    }


def test_effects(
    base: Mapping[str, float], mixed: Mapping[str, float]
) -> dict[str, Any]:
    delta0, delta1 = mixed["D0"] - base["D0"], mixed["D1"] - base["D1"]
    reduced = base["absolute_gap"] - mixed["absolute_gap"] > EFFECT_TOLERANCE
    no_worsening = max(delta0, delta1) <= EFFECT_TOLERANCE
    retained = mixed["capture"] / base["capture"] if base["capture"] > 0.0 else None
    capture_met = (
        retained >= CAPTURE_FLOOR - EFFECT_TOLERANCE
        if retained is not None
        else mixed["capture"] >= 0.0
    )
    value_met = mixed["budget"] <= VALUE_CAP + EFFECT_TOLERANCE
    return {
        "delta_D0": delta0,
        "delta_D1": delta1,
        "absolute_gap_reduction": base["absolute_gap"] - mixed["absolute_gap"],
        "aggregate_objection_mass_change": mixed["complaint_mass"]
        - base["complaint_mass"],
        "retained_loss_capture_fraction": retained,
        "baseline_capture_zero": base["capture"] == 0.0,
        "baseline_gap_zero": base["absolute_gap"] <= EFFECT_TOLERANCE,
        "test_gap_reduced": reduced,
        "test_no_group_worsening": no_worsening,
        "test_capture_floor_met": capture_met,
        "test_value_cap_met": value_met,
        "test_all_constraints_met": no_worsening and capture_met and value_met,
        "test_gap_reduced_with_all_constraints": reduced
        and no_worsening
        and capture_met
        and value_met,
        "test_group_0_no_worsening_error": max(0.0, delta0),
        "test_group_1_no_worsening_error": max(0.0, delta1),
        "test_absolute_capture_floor_error": max(
            0.0, CAPTURE_FLOOR * base["capture"] - mixed["capture"]
        ),
        "test_value_cap_error": max(0.0, mixed["budget"] - VALUE_CAP),
    }


def test_row(
    basis: Basis, amounts: CellAmounts, selection: Mapping[str, Any]
) -> dict[str, Any]:
    base = mixture_metrics(amounts, [(basis.baseline_index, 1.0)])
    mixed = mixture_metrics(amounts, selection["components"])
    row = test_identity_row(basis, amounts)
    row.update({f"baseline_{name}": value for name, value in base.items()})
    row.update({f"mixture_{name}": value for name, value in mixed.items()})
    row.update(test_effects(base, mixed))
    uniform = mixture_metrics(amounts, [(basis.baseline_index, CAPTURE_FLOOR)])
    row.update(uniform_test_effects(base, mixed, uniform))
    row["components_json"] = json.dumps(selection["components"], separators=(",", ":"))
    return row


def uniform_test_effects(
    base: Mapping[str, float], mixed: Mapping[str, float], uniform: Mapping[str, float]
) -> dict[str, Any]:
    row = {"uniform_" + name: value for name, value in uniform.items()}
    effects = test_effects(base, uniform)
    row.update({"uniform_" + name: value for name, value in effects.items()})
    gap_improvement = uniform["absolute_gap"] - mixed["absolute_gap"]
    capture_difference = mixed["capture"] - uniform["capture"]
    gap_better = gap_improvement > EFFECT_TOLERANCE
    capture_no_lower = capture_difference >= -EFFECT_TOLERANCE
    mixed_effects = test_effects(base, mixed)
    joint = (
        effects["test_all_constraints_met"]
        and mixed_effects["test_all_constraints_met"]
    )
    row.update(
        gap_improvement_vs_uniform=gap_improvement,
        capture_difference_vs_uniform=capture_difference,
        value_budget_difference_vs_uniform=mixed["budget"] - uniform["budget"],
        test_gap_better_than_uniform=gap_better,
        test_capture_no_lower_than_uniform=capture_no_lower,
        test_improves_uniform_capture_gap_tradeoff=gap_better and capture_no_lower,
        test_improves_uniform_tradeoff_with_all_constraints=gap_better
        and capture_no_lower
        and joint,
        uniform_and_mixture_test_constraints_met=joint,
    )
    return row


def test_component_rows(basis: Basis, amounts: CellAmounts) -> list[dict[str, Any]]:
    rows = []
    for index, policy in sorted(amounts.policies.items()):
        point = basis.case["bank"][index]
        for mass in policy_masses(amounts, policy):
            rows.append(
                {
                    "generator": GENERATOR,
                    "dataset": basis.key[0],
                    "seed": basis.key[1],
                    "source": basis.source,
                    "measurement_unit": UNIT,
                    "capture_floor": CAPTURE_FLOOR,
                    "bank_index": index,
                    "family": point["family"],
                    "lambda": point["lambda"],
                    "threshold": point["threshold"],
                    "component_alpha": policy.alpha,
                    "split": "test",
                    **mass,
                }
            )
    return rows


def build_test_rows(
    root: Path,
    bases: Mapping[CellKey, Basis],
    selections: Mapping[CellKey, Mapping[str, Any]],
    integrity: outcomes.Integrity,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    comparisons = outcomes.load_comparison(root)
    expected = {(*key, CAPTURE_FLOOR) for key in bases}
    primary = {key for key in comparisons if key[2] == UNIT and key[3] == CAPTURE_FLOOR}
    if primary != expected:
        raise ValueError("The frozen comparison and primary validation scope differ")
    points = outcomes.load_mass_rows(root)
    amounts = replay_test(root, bases, selections)
    rows, mass_rows = [], []
    for key, basis in sorted(bases.items()):
        check_existing(
            basis, amounts[key], comparisons[(*key, CAPTURE_FLOOR)], points, integrity
        )
        rows.append(test_row(basis, amounts[key], selections[key]))
        mass_rows.extend(test_component_rows(basis, amounts[key]))
    return rows, mass_rows


def summary_row(source: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    flags = (
        "test_gap_reduced",
        "test_no_group_worsening",
        "test_capture_floor_met",
        "test_value_cap_met",
        "test_all_constraints_met",
        "test_gap_reduced_with_all_constraints",
        "test_gap_better_than_uniform",
        "test_improves_uniform_capture_gap_tradeoff",
        "test_improves_uniform_tradeoff_with_all_constraints",
        "uniform_and_mixture_test_constraints_met",
    )
    names = (
        "baseline_absolute_gap",
        "mixture_absolute_gap",
        "uniform_absolute_gap",
        "absolute_gap_reduction",
        "gap_improvement_vs_uniform",
        "capture_difference_vs_uniform",
        "mixture_budget",
        "uniform_budget",
    )
    row = {
        "generator": GENERATOR,
        "source": source,
        "measurement_unit": UNIT,
        "capture_floor": CAPTURE_FLOOR,
        "n_cells": len(rows),
    }
    row.update(
        {name + "_cells": sum(bool(value[name]) for value in rows) for name in flags}
    )
    row.update(
        {
            "median_" + name: statistics.median(float(value[name]) for value in rows)
            for name in names
        }
    )
    retained = [
        value["retained_loss_capture_fraction"]
        for value in rows
        if value["retained_loss_capture_fraction"] is not None
    ]
    row["median_retained_loss_capture_fraction"] = (
        statistics.median(retained) if retained else None
    )
    return row


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["source"]].append(row)
    return [
        summary_row(source, values) for source, values in sorted(grouped.items())
    ] + [summary_row("ALL", rows)]


def seal_report(
    root: Path, revision: str, rows: list[dict[str, Any]], integrity: outcomes.Integrity
) -> None:
    freeze = json.loads(output_path(root, "validation_freeze.json").read_text())
    if freeze["implementation"] != script_identities(root):
        raise ValueError("Generator or replay helper changed during execution")
    for item in freeze["inputs"]:
        if outcomes.digest(root / item["path"]) != item["sha256"]:
            raise ValueError(f"Frozen input changed during execution: {item['path']}")
    names = (
        "validation_freeze.json",
        "validation_selection.csv",
        "validation_components.csv",
        "validation_constraints.csv",
        "heldout_cells.csv",
        "heldout_components.csv",
        "source_summary.csv",
    )
    outputs = [
        {
            "path": str(output_path(root, name).relative_to(root)),
            "sha256": outcomes.digest(output_path(root, name)),
        }
        for name in names
    ]
    report = {
        "generator": GENERATOR,
        "schema_version": 1,
        "input_revision": revision,
        "validation_selection_preceded_heldout_parsing": True,
        "inputs": freeze["inputs"],
        "implementation": freeze["implementation"],
        "outputs": outputs,
        "n_cells": len(rows),
        "n_sources": len({row["source"] for row in rows}),
        "integrity_comparisons": integrity.comparisons,
        "maximum_consistency_errors": integrity.maximum_absolute_errors,
        "constraint_tolerance": CONSTRAINT_TOLERANCE,
        "effect_tolerance": EFFECT_TOLERANCE,
        "summary": summarize(rows),
        "p_values": "not_computed",
    }
    write_json(output_path(root, "provenance.json"), report)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--input-revision", default="HEAD")
    arguments = parser.parse_args()
    root = arguments.root.resolve()
    revision = outcomes.git_output(root, ["rev-parse", arguments.input_revision])
    frozen, manifests = outcomes.load_inputs(root, revision)
    cases = primary_cases(frozen)
    integrity = outcomes.Integrity(relative_tolerance=1e-11, absolute_tolerance=1e-8)
    bases = {
        key: make_basis(key, case, integrity) for key, case in sorted(cases.items())
    }
    selections = freeze_selections(root, revision, manifests, bases)
    rows, mass_rows = build_test_rows(root, bases, selections, integrity)
    write_csv(output_path(root, "heldout_cells.csv"), rows)
    write_csv(output_path(root, "heldout_components.csv"), mass_rows)
    write_csv(output_path(root, "source_summary.csv"), summarize(rows))
    seal_report(root, revision, rows, integrity)
    LOGGER.info("Completed primary no-worsening comparison: %s", summarize(rows)[-1])


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    main()
